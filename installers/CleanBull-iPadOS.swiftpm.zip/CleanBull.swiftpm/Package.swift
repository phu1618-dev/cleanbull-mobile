// swift-tools-version: 5.9
import PackageDescription

#if canImport(AppleProductTypes)
import AppleProductTypes

let productsList: [Product] = [
    .iOSApplication(
        name: "CleanBull",
        targets: ["AppModule"],
        bundleIdentifier: "com.cleanbull.mobile.ipados",
        teamIdentifier: "",
        displayVersion: "2.0.0",
        bundleVersion: "1",
        appIcon: .asset("AppIcon"),
        accentColor: .presetColor(.teal),
        supportedDeviceFamilies: [
            .pad,
            .phone
        ],
        supportedInterfaceOrientations: [
            .portrait,
            .landscapeRight,
            .landscapeLeft,
            .portraitUpsideDown(.when(deviceFamilies: [.pad]))
        ],
        capabilities: [
            .outgoingNetworkConnections()
        ]
    )
]
#else
let productsList: [Product] = [
    .executable(name: "CleanBull", targets: ["AppModule"])
]
#endif

let package = Package(
    name: "CleanBull",
    defaultLocalization: "vi",
    platforms: [
        .iOS("17.0"),
        .macOS("14.0")
    ],
    products: productsList,
    targets: [
        .target(
            name: "CleanBullCore",
            path: "Sources/CleanBullCore"
        ),
        .target(
            name: "CleanBullVPN",
            dependencies: ["CleanBullCore"],
            path: "Sources/CleanBullVPN"
        ),
        .target(
            name: "CleanBullUI",
            dependencies: ["CleanBullCore"],
            path: "Sources/CleanBullUI"
        ),
        .executableTarget(
            name: "AppModule",
            dependencies: ["CleanBullCore", "CleanBullVPN", "CleanBullUI"],
            path: "Sources/AppModule",
            resources: [
                .process("Resources")
            ]
        )
    ]
)
