import SwiftUI
import CleanBullCore
import CleanBullUI

@main
struct CleanBullApp: App {
    var body: some Scene {
        WindowGroup {
            CleanBullRootView()
        }
    }
}
