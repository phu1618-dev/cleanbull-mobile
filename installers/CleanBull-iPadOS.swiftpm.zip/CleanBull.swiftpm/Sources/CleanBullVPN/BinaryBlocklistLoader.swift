import Foundation
import Darwin

/// Bộ nạp tệp nhị phân blocklist.bin qua mmap(MAP_SHARED) - Clean Memory không bị tính vào dirty memory limit của Jetsam
public final class BinaryBlocklistLoader: @unchecked Sendable {
    private var mappedPointer: UnsafeMutableRawPointer? = nil
    private var mappedSize: Int = 0
    private var fileDescriptor: Int32 = -1
    private let lock = NSLock()

    public init() {}

    deinit {
        unload()
    }

    /// Nạp tệp nhị phân blocklist qua mmap(MAP_SHARED)
    public func load(fileURL: URL) -> Bool {
        lock.lock()
        defer { lock.unlock() }

        unloadInternal()

        let fd = open(fileURL.path, O_RDONLY)
        guard fd >= 0 else { return false }
        self.fileDescriptor = fd

        var statInfo = stat()
        guard fstat(fd, &statInfo) == 0, statInfo.st_size > 0 else {
            close(fd)
            self.fileDescriptor = -1
            return false
        }

        let size = Int(statInfo.st_size)
        // Mmap chỉ đọc, MAP_SHARED để kernel ánh xạ trực tiếp trang từ ổ đĩa
        let ptr = mmap(nil, size, PROT_READ, MAP_SHARED, fd, 0)
        guard ptr != MAP_FAILED, let validPtr = ptr else {
            close(fd)
            self.fileDescriptor = -1
            return false
        }

        self.mappedPointer = validPtr
        self.mappedSize = size
        return true
    }

    /// Tháo gỡ vùng nhớ mmap
    public func unload() {
        lock.lock()
        defer { lock.unlock() }
        unloadInternal()
    }

    private func unloadInternal() {
        if let ptr = mappedPointer, mappedSize > 0 {
            munmap(ptr, mappedSize)
            mappedPointer = nil
            mappedSize = 0
        }
        if fileDescriptor >= 0 {
            close(fileDescriptor)
            fileDescriptor = -1
        }
    }

    /// Đọc kích thước vùng nhớ đã mmap
    public var currentMappedSize: Int {
        lock.lock()
        defer { lock.unlock() }
        return mappedSize
    }

    /// Kiểm tra trạng thái nạp
    public var isLoaded: Bool {
        lock.lock()
        defer { lock.unlock() }
        return mappedPointer != nil
    }
}
