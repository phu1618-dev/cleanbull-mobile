import Foundation

/// Bộ đệm vòng tròn (Ring Buffer) 512KB xử lý gói tin Zero-Copy, không phân bổ bộ nhớ động trên từng gói tin.
public final class RingBufferPacketFlow: @unchecked Sendable {
    public static let bufferCapacity: Int = 512 * 1024 // 512 KB cố định
    private let rawBuffer: UnsafeMutableRawPointer
    private var writeHead: Int = 0
    private var readHead: Int = 0
    private let lock = NSLock()

    public init() {
        // Cấp phát bộ đệm căn chỉnh địa chỉ trang (Page-aligned memory)
        var ptr: UnsafeMutableRawPointer? = nil
        let alignment = 4096
        let res = posix_memalign(&ptr, alignment, RingBufferPacketFlow.bufferCapacity)
        if res == 0, let validPtr = ptr {
            self.rawBuffer = validPtr
        } else {
            self.rawBuffer = UnsafeMutableRawPointer.allocate(byteCount: RingBufferPacketFlow.bufferCapacity, alignment: alignment)
        }
    }

    deinit {
        free(rawBuffer)
    }

    /// Dung lượng khả dụng còn trống trong bộ đệm (bytes)
    public var availableWriteSpace: Int {
        lock.lock()
        defer { lock.unlock() }
        if writeHead >= readHead {
            return RingBufferPacketFlow.bufferCapacity - (writeHead - readHead) - 1
        } else {
            return readHead - writeHead - 1
        }
    }

    /// Dung lượng dữ liệu đang chờ đọc trong bộ đệm (bytes)
    public var availableReadBytes: Int {
        lock.lock()
        defer { lock.unlock() }
        if writeHead >= readHead {
            return writeHead - readHead
        } else {
            return RingBufferPacketFlow.bufferCapacity - (readHead - writeHead)
        }
    }

    /// Ghi gói tin thô vào Ring Buffer không sinh heap fragmentation
    public func writePacket(bytes: UnsafeRawPointer, count: Int) -> Bool {
        guard count > 0 && count <= 65535 else { return false }
        lock.lock()
        defer { lock.unlock() }

        let space = (writeHead >= readHead)
            ? RingBufferPacketFlow.bufferCapacity - (writeHead - readHead) - 1
            : readHead - writeHead - 1

        // Cần lưu 2 bytes độ dài + count bytes nội dung
        let totalNeeded = count + 2
        guard space >= totalNeeded else {
            return false // Bộ đệm đầy, drop gói tin bảo vệ trần RAM
        }

        // Ghi độ dài (UInt16)
        var len = UInt16(count)
        writeRawBytes(&len, count: 2)

        // Ghi dữ liệu gói tin
        writeRawBytes(bytes, count: count)
        return true
    }

    /// Đọc gói tin tiếp theo từ Ring Buffer
    public func readPacket(into destination: UnsafeMutableRawPointer, maxDestinationCount: Int) -> Int? {
        lock.lock()
        defer { lock.unlock() }

        let currentDataBytes = (writeHead >= readHead)
            ? writeHead - readHead
            : RingBufferPacketFlow.bufferCapacity - (readHead - writeHead)

        guard currentDataBytes >= 2 else { return nil }

        // Đọc 2 bytes độ dài
        var len: UInt16 = 0
        readRawBytes(into: &len, count: 2)
        let packetSize = Int(len)

        guard packetSize <= maxDestinationCount else {
            // Không đủ chỗ chứa, nhảy qua gói tin
            skipBytes(packetSize)
            return nil
        }

        readRawBytes(into: destination, count: packetSize)
        return packetSize
    }

    /// Xóa toàn bộ dữ liệu trong bộ đệm khẩn cấp
    public func reset() {
        lock.lock()
        defer { lock.unlock() }
        writeHead = 0
        readHead = 0
    }

    // MARK: - Internal Pointer Arithmetic

    private func writeRawBytes(_ source: UnsafeRawPointer, count: Int) {
        let firstChunk = min(count, RingBufferPacketFlow.bufferCapacity - writeHead)
        rawBuffer.advanced(by: writeHead).copyMemory(from: source, byteCount: firstChunk)

        let remaining = count - firstChunk
        if remaining > 0 {
            rawBuffer.copyMemory(from: source.advanced(by: firstChunk), byteCount: remaining)
            writeHead = remaining
        } else {
            writeHead = (writeHead + firstChunk) % RingBufferPacketFlow.bufferCapacity
        }
    }

    private func readRawBytes(into destination: UnsafeMutableRawPointer, count: Int) {
        let firstChunk = min(count, RingBufferPacketFlow.bufferCapacity - readHead)
        destination.copyMemory(from: rawBuffer.advanced(by: readHead), byteCount: firstChunk)

        let remaining = count - firstChunk
        if remaining > 0 {
            destination.advanced(by: firstChunk).copyMemory(from: rawBuffer, byteCount: remaining)
            readHead = remaining
        } else {
            readHead = (readHead + firstChunk) % RingBufferPacketFlow.bufferCapacity
        }
    }

    private func skipBytes(_ count: Int) {
        readHead = (readHead + count) % RingBufferPacketFlow.bufferCapacity
    }
}
