import Foundation
import Darwin
import MachO

/// Cơ chế Giám sát Bộ nhớ Thường trực (Memory Watchdog) kiểm soát trần RAM <35MB trong Network Extension
public final class MemoryWatchdog: @unchecked Sendable {
    public static let warningThresholdMB: Double = 22.0
    public static let emergencyThresholdMB: Double = 28.0
    public static let hardCapLimitMB: Double = 35.0

    public var onWarning: (@Sendable () -> Void)?
    public var onEmergency: (@Sendable () -> Void)?

    private var isRunning: Bool = false
    private let lock = NSLock()

    public init() {}

    /// Đọc dung lượng RAM Resident thực tế của tiến trình hiện tại (MB)
    public func getCurrentResidentMemoryMB() -> Double {
        var info = mach_task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / 4)
        let kerr = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
            }
        }
        if kerr == KERN_SUCCESS {
            return Double(info.resident_size) / (1024.0 * 1024.0)
        }
        return 0.0
    }

    /// Thẩm định áp lực bộ nhớ và thực hiện giải phóng khẩn cấp nếu cần
    @discardableResult
    public func checkMemoryPressure(simulatedResidentMB: Double? = nil) -> (residentMB: Double, actionTaken: String) {
        let resident = simulatedResidentMB ?? getCurrentResidentMemoryMB()

        if resident >= MemoryWatchdog.emergencyThresholdMB {
            // Ngưỡng khẩn cấp: Xả toàn bộ bộ đệm và gọi thu hồi vùng nhớ
            onEmergency?()
            malloc_zone_pressure_relief(malloc_default_zone(), 0)
            return (resident, "EMERGENCY_PURGE: Đã giải phóng bộ đệm vòng tròn và xả cache khẩn cấp để giữ RAM <35MB")
        } else if resident >= MemoryWatchdog.warningThresholdMB {
            // Ngưỡng cảnh báo: Xóa bộ đệm DNS tạm
            onWarning?()
            return (resident, "WARNING_PURGE: Đã dọn dẹp bộ nhớ đệm DNS tạm thời")
        }

        return (resident, "NORMAL: Dung lượng trong ngưỡng an toàn (\(String(format: "%.1f", resident)) MB < 35MB)")
    }
}
