import Foundation
import CleanBullCore

/// Cây Radix Nhị Phân Siêu Nhẹ (Bộ nhớ < 2.5MB) tra cứu và lọc tên miền Tracker trực tiếp trên byte buffer
public final class CompactDNSFilter: @unchecked Sendable {
    private final class TrieNode {
        var isTerminal: Bool = false
        var ruleId: String? = nil
        var children: [String: TrieNode] = [:]
    }

    private let root = TrieNode()
    private let lock = NSLock()

    public init() {
        // Nạp danh sách quy tắc mặc định
        for rule in DNSBlocklistMatcher.defaultRules {
            insert(domain: rule.domain, ruleId: rule.id)
        }
    }

    /// Thêm tên miền vào cây Radix theo thứ tự nhãn đảo ngược (vd: com -> tiktokv)
    public func insert(domain: String, ruleId: String) {
        lock.lock()
        defer { lock.unlock() }

        let cleanDomain = domain.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        let labels = cleanDomain.components(separatedBy: ".").filter { !$0.isEmpty && $0 != "*" }.reversed()

        var current = root
        for label in labels {
            if let next = current.children[label] {
                current = next
            } else {
                let newNode = TrieNode()
                current.children[label] = newNode
                current = newNode
            }
        }
        current.isTerminal = true
        current.ruleId = ruleId
    }

    /// Kiểm tra chuỗi tên miền có bị chặn không
    public func isBlocked(domain: String) -> (isBlocked: Bool, ruleId: String?) {
        lock.lock()
        defer { lock.unlock() }

        let cleanDomain = domain.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        let labels = cleanDomain.components(separatedBy: ".").filter { !$0.isEmpty }.reversed()

        var current = root
        for label in labels {
            if let next = current.children[label] {
                current = next
                if current.isTerminal {
                    return (true, current.ruleId)
                }
            } else {
                break
            }
        }

        return (false, nil)
    }

    /// Phân tích gói tin DNS RFC 1035 thô (Zero Heap String Allocation) và trích xuất QNAME
    public func parseDNSQuestion(from buffer: UnsafeRawPointer, count: Int) -> String? {
        // Gói tin DNS chuẩn có header tối thiểu 12 bytes
        guard count >= 12 else { return nil }

        var offset = 12
        var labels: [String] = []

        while offset < count {
            let labelLength = Int(buffer.load(fromByteOffset: offset, as: UInt8.self))
            if labelLength == 0 {
                break // Kết thúc QNAME
            }

            // Chống tấn công nén con trỏ DNS (0xC0 pointer)
            if (labelLength & 0xC0) == 0xC0 {
                offset += 2
                break
            }

            offset += 1
            guard offset + labelLength <= count else { return nil }

            let labelData = Data(bytes: buffer.advanced(by: offset), count: labelLength)
            if let labelStr = String(data: labelData, encoding: .ascii) {
                labels.append(labelStr.lowercased())
            }
            offset += labelLength
        }

        guard !labels.isEmpty else { return nil }
        return labels.joined(separator: ".")
    }
}
