import Foundation
import CleanBullCore

/// Lớp điều phối gói tin và kiểm soát tài nguyên độc lập (CleanBullTunnelEngine)
/// Tách biệt hoàn toàn khỏi vòng đời NEPacketTunnelProvider để phục vụ kiểm thử và hoạt động an toàn
public final class CleanBullTunnelEngine: @unchecked Sendable {
    public let ringBuffer = RingBufferPacketFlow()
    public let dnsFilter = CompactDNSFilter()
    public let blocklistLoader = BinaryBlocklistLoader()
    public let memoryWatchdog = MemoryWatchdog()

    public private(set) var isTunnelActive = false

    public init() {
        setupWatchdog()
    }

    public func setupWatchdog() {
        memoryWatchdog.onWarning = { [weak self] in
            // Xả bộ đệm tạm thời khi chạm ngưỡng cảnh báo (22MB)
            _ = self
        }
        memoryWatchdog.onEmergency = { [weak self] in
            // Xả toàn bộ Ring Buffer khi chạm ngưỡng khẩn cấp (28MB) để ngăn ngừa Jetsam kill
            self?.ringBuffer.reset()
        }
    }

    public func startEngine() {
        isTunnelActive = true
    }

    public func stopEngine() {
        isTunnelActive = false
        ringBuffer.reset()
        blocklistLoader.unload()
    }

    /// Xử lý gói tin IP, bóc tách truy vấn DNS và chặn các tracker trong danh sách
    public func processIncomingPacket(data: Data) -> (isBlocked: Bool, qname: String?) {
        let count = data.count
        guard count > 0 else { return (false, nil) }

        // Ghi vào Ring Buffer zero-copy
        let written = data.withUnsafeBytes { rawPtr in
            guard let baseAddress = rawPtr.baseAddress else { return false }
            return ringBuffer.writePacket(bytes: baseAddress, count: count)
        }
        guard written else {
            return (false, nil) // Drop packet nếu buffer đầy, giữ trần RAM <35MB
        }

        // Bóc tách DNS Question
        let parsedDomain = data.withUnsafeBytes { rawPtr -> String? in
            guard let baseAddress = rawPtr.baseAddress else { return nil }
            return dnsFilter.parseDNSQuestion(from: baseAddress, count: count)
        }

        if let domain = parsedDomain {
            let (blocked, _) = dnsFilter.isBlocked(domain: domain)
            return (blocked, domain)
        }

        return (false, nil)
    }
}

#if canImport(NetworkExtension) && os(iOS) && !targetEnvironment(simulator)
@preconcurrency import NetworkExtension

/// Trình triển khai Network Extension Packet Tunnel Provider thực thụ cho iPadOS/iOS Daemon
open class CleanBullPacketTunnelProvider: NEPacketTunnelProvider, @unchecked Sendable {
    public let engine = CleanBullTunnelEngine()

    public var ringBuffer: RingBufferPacketFlow { engine.ringBuffer }
    public var dnsFilter: CompactDNSFilter { engine.dnsFilter }
    public var blocklistLoader: BinaryBlocklistLoader { engine.blocklistLoader }
    public var memoryWatchdog: MemoryWatchdog { engine.memoryWatchdog }
    public var isTunnelActive: Bool { engine.isTunnelActive }

    public override init() {
        super.init()
        // Phòng vệ an toàn: Trì hoãn cấu hình watchdog và các thao tác tài nguyên hệ thống
        // cho tới khi startTunnel được gọi chính thức từ tiến trình daemon của hệ điều hành
    }

    open override func startTunnel(options: [String : NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        engine.startEngine()
        engine.setupWatchdog()

        let networkSettings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "127.0.0.1")
        let dnsSettings = NEDNSSettings(servers: ["1.1.1.1", "1.0.0.1"])
        dnsSettings.matchDomains = [""] // Split-DNS
        networkSettings.dnsSettings = dnsSettings

        setTunnelNetworkSettings(networkSettings) { [weak self] error in
            if error == nil {
                self?.startPacketProcessingLoop()
            }
            completionHandler(error)
        }
    }

    open override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        engine.stopEngine()
        completionHandler()
    }

    /// Vòng lặp xử lý gói tin với zero-copy qua Ring Buffer
    private func startPacketProcessingLoop() {
        guard engine.isTunnelActive else { return }

        packetFlow.readPackets { [weak self] packets, protocols in
            guard let self = self, self.engine.isTunnelActive else { return }

            for packet in packets {
                _ = self.engine.processIncomingPacket(data: packet)
            }

            // Kiểm tra áp lực bộ nhớ định kỳ sau mỗi lô gói tin
            self.engine.memoryWatchdog.checkMemoryPressure()

            // Tiếp tục vòng lặp
            self.startPacketProcessingLoop()
        }
    }

    public func processIncomingPacket(data: Data) -> (isBlocked: Bool, qname: String?) {
        return engine.processIncomingPacket(data: data)
    }
}

#else

/// Trình triển khai độc lập / Dev & Test Harness của Packet Tunnel Provider
/// Cho phép khởi tạo và kiểm thử an toàn trên macOS CLI, iOS Simulator, và các test runners mà không bị EXC_BAD_ACCESS
open class CleanBullPacketTunnelProvider: @unchecked Sendable {
    public let engine = CleanBullTunnelEngine()

    public var ringBuffer: RingBufferPacketFlow { engine.ringBuffer }
    public var dnsFilter: CompactDNSFilter { engine.dnsFilter }
    public var blocklistLoader: BinaryBlocklistLoader { engine.blocklistLoader }
    public var memoryWatchdog: MemoryWatchdog { engine.memoryWatchdog }
    public var isTunnelActive: Bool { engine.isTunnelActive }

    public init() {
        engine.setupWatchdog()
    }

    open func startTunnel(options: [String : NSObject]? = nil, completionHandler: @escaping ((any Error)?) -> Void = { _ in }) {
        engine.startEngine()
        engine.setupWatchdog()
        completionHandler(nil)
    }

    open func stopTunnel(completionHandler: @escaping () -> Void = {}) {
        engine.stopEngine()
        completionHandler()
    }

    public func processIncomingPacket(data: Data) -> (isBlocked: Bool, qname: String?) {
        return engine.processIncomingPacket(data: data)
    }
}
#endif
