import Foundation

/// Dịch vụ Trợ lý câu lệnh: Phân tích ngôn ngữ tự nhiên tiếng Việt cục bộ trên thiết bị và thực thi quét mục tiêu.
public final class AIAssistantService: @unchecked Sendable {
    public let homeDirectory: URL
    public let safetyFilter: SafetyFilterService
    public let scanner: FileScannerActor

    public init(
        homeDirectory: URL = FileManager.default.homeDirectoryForCurrentUser,
        safetyFilter: SafetyFilterService? = nil,
        scanner: FileScannerActor = FileScannerActor()
    ) {
        self.homeDirectory = homeDirectory
        self.safetyFilter = safetyFilter ?? SafetyFilterService(homeDirectory: homeDirectory)
        self.scanner = scanner
    }

    /// Phân tích câu hỏi tiếng Việt và trích xuất tham số quét hoặc điều khiển VPN
    public func parseQueryIntent(_ query: String) -> AIScanIntent {
        let lower = query.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        let home = homeDirectory

        var targetDirs: [URL] = []
        var extensions: [String] = []
        var minSize: Int64 = 0
        var minAge: Int = 0
        var keywords: [String] = []
        var desc = "Dọn dẹp tùy biến theo yêu cầu"
        var vpnAction: VPNIntentAction? = nil

        // 1. Phân tích lệnh điều khiển VPN Shield
        if lower.contains("bật vpn") || lower.contains("kết nối vpn") || lower.contains("bật khiên") {
            vpnAction = .enable
            desc = "Kích hoạt Khiên VPN bảo vệ mạng"
        } else if lower.contains("tắt vpn") || lower.contains("ngắt vpn") || lower.contains("tắt khiên") || lower.contains("ngắt khiên") || lower.contains("ngắt kết nối") {
            vpnAction = .disable
            desc = "Ngắt kết nối Khiên VPN"
        } else if lower.contains("chống theo dõi") || lower.contains("chặn quảng cáo") || lower.contains("chế độ 1") {
            vpnAction = .switchMode(1)
            desc = "Chuyển sang Chế độ 1: Khiên Chống Theo Dõi Cục Bộ"
        } else if lower.contains("warp") || lower.contains("cloudflare") || lower.contains("chế độ 2") {
            vpnAction = .switchMode(2)
            desc = "Chuyển sang Chế độ 2: VPN Cloudflare WARP Miễn Phí"
        } else if lower.contains("custom") || lower.contains("tùy chỉnh") || lower.contains("chế độ 3") {
            vpnAction = .switchMode(3)
            desc = "Chuyển sang Chế độ 3: Cấu Hình Tùy Chỉnh & Máy Chủ Riêng"
        } else if lower.contains("kiểm tra tên miền") || lower.contains("check domain") {
            let parts = lower.components(separatedBy: " ")
            if let domain = parts.last, domain.contains(".") {
                vpnAction = .checkDomain(domain)
                desc = "Kiểm tra tên miền '\(domain)' trong danh sách chặn"
            }
        }

        // 2. Phân tích Thư mục mục tiêu
        if lower.contains("download") || lower.contains("tải về") {
            targetDirs.append(home.appendingPathComponent("Downloads", isDirectory: true))
        }
        if lower.contains("cache") || lower.contains("bộ nhớ đệm") {
            targetDirs.append(home.appendingPathComponent("Library/Caches", isDirectory: true))
        }
        if lower.contains("log") || lower.contains("nhật ký") {
            targetDirs.append(home.appendingPathComponent("Library/Logs", isDirectory: true))
        }
        if lower.contains("xcode") || lower.contains("deriveddata") {
            targetDirs.append(home.appendingPathComponent("Library/Developer/Xcode/DerivedData", isDirectory: true))
            keywords.append("xcode")
        }

        if targetDirs.isEmpty && vpnAction == nil {
            targetDirs = [
                home.appendingPathComponent("Downloads", isDirectory: true),
                home.appendingPathComponent("Library/Caches", isDirectory: true),
                home.appendingPathComponent("Library/Logs", isDirectory: true)
            ]
        }

        // 3. Phân tích Dung lượng
        if lower.contains("1gb") || lower.contains("1 gb") {
            minSize = 1024 * 1024 * 1024
        } else if lower.contains("500mb") || lower.contains("500 mb") {
            minSize = 500 * 1024 * 1024
        } else if lower.contains("200mb") || lower.contains("200 mb") {
            minSize = 200 * 1024 * 1024
        } else if lower.contains("100mb") || lower.contains("100 mb") {
            minSize = 100 * 1024 * 1024
        } else if lower.contains("50mb") || lower.contains("50 mb") {
            minSize = 50 * 1024 * 1024
        } else if lower.contains("lớn") || lower.contains("nặng") {
            minSize = 100 * 1024 * 1024
        }

        // 4. Phân tích Loại tệp (Extensions)
        if lower.contains("video") || lower.contains("phim") || lower.contains("clip") {
            extensions.append(contentsOf: ["mp4", "mov", "mkv", "avi", "webm"])
            desc = "Tìm kiếm các tệp video"
        }
        if lower.contains("ảnh") || lower.contains("hình") || lower.contains("photo") {
            extensions.append(contentsOf: ["png", "jpg", "jpeg", "heic", "gif", "webp", "psd"])
            desc = "Tìm kiếm các tệp hình ảnh"
        }
        if lower.contains("dmg") || lower.contains("cài đặt") || lower.contains("installer") || lower.contains("zip") {
            extensions.append(contentsOf: ["dmg", "pkg", "zip", "tar.gz", "iso"])
            desc = "Tìm kiếm các bộ cài và tệp nén"
        }
        if lower.contains("tài liệu") || lower.contains("doc") || lower.contains("pdf") {
            extensions.append(contentsOf: ["pdf", "docx", "xlsx", "pptx", "txt"])
            desc = "Tìm kiếm các tệp tài liệu"
        }

        // 5. Phân tích Thời gian cũ
        if lower.contains("1 năm") || lower.contains("365 ngày") {
            minAge = 365
        } else if lower.contains("6 tháng") {
            minAge = 180
        } else if lower.contains("3 tháng") || lower.contains("90 ngày") {
            minAge = 90
        } else if lower.contains("2 tháng") || lower.contains("60 ngày") {
            minAge = 60
        } else if lower.contains("1 tháng") || lower.contains("30 ngày") {
            minAge = 30
        } else if lower.contains("cũ") || lower.contains("lâu") {
            minAge = 60
        }

        // 6. Từ khóa chuyên biệt
        if lower.contains("docker") { keywords.append("docker") }
        if lower.contains("chrome") { keywords.append("chrome") }
        if lower.contains("simulator") { keywords.append("simulator") }
        if lower.contains("node_modules") { keywords.append("node_modules") }

        return AIScanIntent(
            targetDirectories: targetDirs,
            fileExtensions: extensions,
            minSizeBytes: minSize,
            minAgeDays: minAge,
            keywords: keywords,
            intentDescription: desc,
            vpnAction: vpnAction
        )
    }

    /// Thực thi quét tệp theo ý định đã trích xuất
    public func executeAIScan(intent: AIScanIntent) async -> [EvidenceCardModel] {
        var results: [EvidenceCardModel] = []
        let now = Date()

        for dir in intent.targetDirectories {
            guard FileManager.default.fileExists(atPath: dir.path) else { continue }

            let rawItems = await scanner.scan(rootURLs: [dir])

            for raw in rawItems {
                let url = raw.url
                let path = url.path

                // Kiểm tra Safety Filter
                let safety = safetyFilter.isSafeToProcess(url: url)
                guard safety.isSafe else { continue }

                // Kiểm tra Extension nếu có yêu cầu
                if !intent.fileExtensions.isEmpty {
                    let ext = url.pathExtension.lowercased()
                    guard intent.fileExtensions.contains(ext) else { continue }
                }

                // Kiểm tra dung lượng tối thiểu
                if intent.minSizeBytes > 0 {
                    guard raw.fileSize >= intent.minSizeBytes else { continue }
                }

                // Kiểm tra độ cũ (ngày)
                if intent.minAgeDays > 0 {
                    let refDate = raw.lastAccessedDate < raw.lastModifiedDate ? raw.lastAccessedDate : raw.lastModifiedDate
                    let days = Calendar.current.dateComponents([.day], from: refDate, to: now).day ?? 0
                    guard days >= intent.minAgeDays else { continue }
                }

                // Kiểm tra từ khóa nếu có
                if !intent.keywords.isEmpty {
                    let pathLower = path.lowercased()
                    let matchesKeyword = intent.keywords.contains { pathLower.contains($0) }
                    guard matchesKeyword else { continue }
                }

                let ext = url.pathExtension.uppercased()
                let typeName = ext.isEmpty ? "Tệp Tin" : "Tệp .\(ext)"
                let explanation = "Phù hợp với yêu cầu: '\(intent.intentDescription)' (Kích thước: \(ByteCountFormatter.string(fromByteCount: raw.fileSize, countStyle: .file)))"
                let impact = "Chuyển vào Cách ly giúp giải phóng dung lượng ổ đĩa. Bạn luôn có thể hoàn tác bất kỳ lúc nào."

                let card = EvidenceCardModel(
                    path: path,
                    fileSize: raw.fileSize,
                    fileType: typeName,
                    owner: raw.owner,
                    lastModifiedDate: raw.lastModifiedDate,
                    lastAccessedDate: raw.lastAccessedDate,
                    confidenceScore: 90,
                    riskLevel: .medium,
                    explanationText: explanation,
                    potentialImpactText: impact
                )
                results.append(card)
            }
        }

        return Array(results.sorted { $0.fileSize > $1.fileSize }.prefix(50))
    }
}
