import Foundation
#if canImport(UIKit)
import UIKit
#endif

/// Trạng thái nhiệt độ của thiết bị
public enum DeviceThermalLevel: String, Codable, Sendable, CaseIterable {
    case nominal = "nominal"
    case fair = "fair"
    case serious = "serious"
    case critical = "critical"

    public var localizedTitle: String {
        switch self {
        case .nominal: return "Mát mẻ (Bình thường)"
        case .fair: return "Hơi ấm (Tải nhẹ)"
        case .serious: return "Nóng (Đang hạ xung)"
        case .critical: return "Quá nhiệt (Nghiêm trọng)"
        }
    }

    public var badgeColor: String {
        switch self {
        case .nominal: return "emerald"
        case .fair: return "sky"
        case .serious: return "amber"
        case .critical: return "rose"
        }
    }
}

/// Bản chụp trạng thái nhiệt độ và pin
public struct BatteryThermalSnapshot: Sendable, Equatable {
    public let thermalLevel: DeviceThermalLevel
    public let batteryLevel: Float? // 0.0 .. 1.0, or nil if unavailable
    public let isCharging: Bool
    public let timestamp: Date

    public init(
        thermalLevel: DeviceThermalLevel,
        batteryLevel: Float? = nil,
        isCharging: Bool = false,
        timestamp: Date = Date()
    ) {
        self.thermalLevel = thermalLevel
        self.batteryLevel = batteryLevel
        self.isCharging = isCharging
        self.timestamp = timestamp
    }

    public var formattedBatteryPercent: String {
        guard let level = batteryLevel, level >= 0 else {
            return "—"
        }
        return "\(Int(level * 100))%"
    }
}

/// Dịch vụ giám sát nhiệt độ và pin
public final class BatteryThermalMonitor: Sendable {
    public init() {}

    /// Lấy bản chụp trạng thái nhiệt độ và pin tức thời
    public func getSnapshot() -> BatteryThermalSnapshot {
        let thermal = ProcessInfo.processInfo.thermalState
        let level: DeviceThermalLevel
        switch thermal {
        case .nominal: level = .nominal
        case .fair: level = .fair
        case .serious: level = .serious
        case .critical: level = .critical
        @unknown default: level = .nominal
        }

        #if os(iOS) && canImport(UIKit)
        UIDevice.current.isBatteryMonitoringEnabled = true
        let rawBattery = UIDevice.current.batteryLevel
        let battery = rawBattery >= 0 ? rawBattery : nil
        let state = UIDevice.current.batteryState
        let isCharging = (state == .charging || state == .full)
        return BatteryThermalSnapshot(thermalLevel: level, batteryLevel: battery, isCharging: isCharging)
        #else
        return BatteryThermalSnapshot(thermalLevel: level, batteryLevel: nil, isCharging: false)
        #endif
    }
}
