import Foundation
import Darwin
import MachO

/// Dịch vụ giám sát sức khỏe bộ nhớ sử dụng Darwin Mach VM và sysctl C-APIs (Dữ liệu thật 100%, không fake RAM).
public final class MemoryPressureMonitor: @unchecked Sendable {
    private var pressureSource: (any DispatchSourceMemoryPressure)?
    private var currentPressureLevel: MemoryPressureLevel = .normal
    private let lock = NSLock()

    public init() {}

    deinit {
        stopMonitoring()
    }

    /// Đọc thông số bộ nhớ tức thời thực tế từ Mach Kernel và sysctl.
    public func getMemorySnapshot() -> MemorySnapshot {
        let totalPhysical = ProcessInfo.processInfo.physicalMemory

        var pageSize: vm_size_t = 0
        let hostPort = mach_host_self()
        _ = host_page_size(hostPort, &pageSize)
        if pageSize == 0 {
            pageSize = vm_size_t(getpagesize())
        }

        var vmStat = vm_statistics64()
        var count = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)

        let result = withUnsafeMutablePointer(to: &vmStat) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { intPtr in
                host_statistics64(hostPort, HOST_VM_INFO64, intPtr, &count)
            }
        }

        let wired: UInt64
        let active: UInt64
        let inactive: UInt64
        let compressed: UInt64
        let free: UInt64

        if result == KERN_SUCCESS {
            let uPageSize = UInt64(pageSize)
            wired = UInt64(vmStat.wire_count) * uPageSize
            active = UInt64(vmStat.active_count) * uPageSize
            inactive = UInt64(vmStat.inactive_count) * uPageSize
            compressed = UInt64(vmStat.compressor_page_count) * uPageSize
            free = UInt64(vmStat.free_count) * uPageSize
        } else {
            wired = 0
            active = 0
            inactive = 0
            compressed = 0
            free = 0
        }

        let appMemory = active + compressed

        // Đọc Swap Usage qua sysctl `vm.swapusage`
        var swapUsage = xsw_usage()
        var swapSize = MemoryLayout<xsw_usage>.size
        let swapResult = sysctlbyname("vm.swapusage", &swapUsage, &swapSize, nil, 0)

        let swapTotal: UInt64
        let swapUsed: UInt64
        if swapResult == 0 {
            swapTotal = UInt64(swapUsage.xsu_total)
            swapUsed = UInt64(swapUsage.xsu_used)
        } else {
            swapTotal = 0
            swapUsed = 0
        }

        lock.lock()
        let level = currentPressureLevel
        lock.unlock()

        return MemorySnapshot(
            totalPhysicalBytes: totalPhysical,
            appMemoryBytes: appMemory,
            wiredBytes: wired,
            activeBytes: active,
            inactiveBytes: inactive,
            compressedBytes: compressed,
            freeBytes: free,
            swapTotalBytes: swapTotal,
            swapUsedBytes: swapUsed,
            pressureLevel: level
        )
    }

    /// Bắt đầu lắng nghe sự kiện thay đổi áp lực bộ nhớ từ Darwin Dispatch Source.
    public func startMonitoring(onUpdate: @escaping @Sendable (MemorySnapshot) -> Void) {
        stopMonitoring()

        let source = DispatchSource.makeMemoryPressureSource(
            eventMask: [.normal, .warning, .critical],
            queue: DispatchQueue.global(qos: .utility)
        )

        source.setEventHandler { [weak self, weak source] in
            guard let self = self, let source = source else { return }

            let event = source.data
            let newLevel: MemoryPressureLevel
            if event.contains(.critical) {
                newLevel = .critical
            } else if event.contains(.warning) {
                newLevel = .warning
            } else {
                newLevel = .normal
            }

            self.lock.lock()
            self.currentPressureLevel = newLevel
            self.lock.unlock()

            let snapshot = self.getMemorySnapshot()
            onUpdate(snapshot)
        }

        source.resume()
        self.pressureSource = source

        let initialSnapshot = getMemorySnapshot()
        onUpdate(initialSnapshot)
    }

    /// Dừng lắng nghe sự kiện áp lực bộ nhớ.
    public func stopMonitoring() {
        if let source = pressureSource {
            source.cancel()
            pressureSource = nil
        }
    }
}
