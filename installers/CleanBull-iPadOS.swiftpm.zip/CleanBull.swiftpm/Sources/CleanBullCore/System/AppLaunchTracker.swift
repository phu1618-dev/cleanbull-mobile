import Foundation
#if os(macOS)
import AppKit
#endif

/// Bản ghi thống kê mức độ sử dụng của một ứng dụng.
public struct AppUsageRecord: Identifiable, Codable, Sendable, Equatable {
    public var id: String { bundleIdentifier }
    public let bundleIdentifier: String
    public var appName: String
    public var launchCount: Int
    public var totalForegroundSeconds: TimeInterval
    public var firstTrackedDate: Date
    public var lastLaunchedDate: Date
    public var lastTerminatedDate: Date?

    public init(
        bundleIdentifier: String,
        appName: String,
        launchCount: Int = 1,
        totalForegroundSeconds: TimeInterval = 0,
        firstTrackedDate: Date = Date(),
        lastLaunchedDate: Date = Date(),
        lastTerminatedDate: Date? = nil
    ) {
        self.bundleIdentifier = bundleIdentifier
        self.appName = appName
        self.launchCount = launchCount
        self.totalForegroundSeconds = totalForegroundSeconds
        self.firstTrackedDate = firstTrackedDate
        self.lastLaunchedDate = lastLaunchedDate
        self.lastTerminatedDate = lastTerminatedDate
    }
}

/// Dịch vụ quan sát việc mở/đóng ứng dụng và tổng hợp dữ liệu sử dụng thật trên macOS.
public final class AppLaunchTracker: @unchecked Sendable {
    public static let shared = AppLaunchTracker()

    private var records: [String: AppUsageRecord] = [:]
    private var activeSessions: [String: Date] = [:]
    private var observers: [NSObjectProtocol] = []
    private let lock = NSLock()
    private let primaryStorageURL: URL
    private let legacyStorageURL: URL

    public init(storageDirectory: URL? = nil) {
        let home = FileManager.default.homeDirectoryForCurrentUser
        if let dir = storageDirectory {
            self.primaryStorageURL = dir.appendingPathComponent("app_usage.json")
            self.legacyStorageURL = dir.appendingPathComponent("app_usage.json")
        } else {
            self.primaryStorageURL = home
                .appendingPathComponent(".local/share/CleanBull/app_usage.json")
            self.legacyStorageURL = home
                .appendingPathComponent(".local/share/CleanGiabull/app_usage.json")
        }
        loadRecordsFromDisk()
    }

    deinit {
        stopTracking()
    }

    public func startTracking() {
        #if os(macOS)
        stopTracking()
        let center = NSWorkspace.shared.notificationCenter

        let launchObserver = center.addObserver(
            forName: NSWorkspace.didLaunchApplicationNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self,
                  let app = notification.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication,
                  let bundleId = app.bundleIdentifier else { return }
            let appName = app.localizedName ?? bundleId
            self.handleAppLaunch(bundleId: bundleId, appName: appName)
        }

        let terminateObserver = center.addObserver(
            forName: NSWorkspace.didTerminateApplicationNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self,
                  let app = notification.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication,
                  let bundleId = app.bundleIdentifier else { return }
            self.handleAppTermination(bundleId: bundleId)
        }

        observers = [launchObserver, terminateObserver]
        #endif
    }

    public func stopTracking() {
        #if os(macOS)
        let center = NSWorkspace.shared.notificationCenter
        for observer in observers {
            center.removeObserver(observer)
        }
        observers.removeAll()
        #endif
    }

    public func handleAppLaunch(bundleId: String, appName: String, date: Date = Date()) {
        lock.lock()
        defer {
            lock.unlock()
            saveRecordsToDisk()
        }

        activeSessions[bundleId] = date
        if var record = records[bundleId] {
            record.appName = appName
            record.launchCount += 1
            record.lastLaunchedDate = date
            records[bundleId] = record
        } else {
            records[bundleId] = AppUsageRecord(
                bundleIdentifier: bundleId,
                appName: appName,
                launchCount: 1,
                totalForegroundSeconds: 0,
                firstTrackedDate: date,
                lastLaunchedDate: date
            )
        }
    }

    public func handleAppTermination(bundleId: String, date: Date = Date()) {
        lock.lock()
        defer {
            lock.unlock()
            saveRecordsToDisk()
        }

        guard let startTime = activeSessions.removeValue(forKey: bundleId) else { return }
        let duration = max(0, date.timeIntervalSince(startTime))
        if var record = records[bundleId] {
            record.totalForegroundSeconds += duration
            record.lastTerminatedDate = date
            records[bundleId] = record
        }
    }

    public func getAllUsageRecords() -> [AppUsageRecord] {
        lock.lock()
        defer { lock.unlock() }
        return Array(records.values).sorted { $0.launchCount > $1.launchCount }
    }

    public func getUsageRecord(bundleId: String) -> AppUsageRecord? {
        lock.lock()
        defer { lock.unlock() }
        return records[bundleId]
    }

    private func saveRecordsToDisk() {
        let dir = primaryStorageURL.deletingLastPathComponent()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601

        if let data = try? encoder.encode(Array(records.values)) {
            try? data.write(to: primaryStorageURL, options: .atomic)
            // Đồng bộ sang cả legacyStorageURL nếu thư mục cũ tồn tại
            if FileManager.default.fileExists(atPath: legacyStorageURL.deletingLastPathComponent().path) {
                try? data.write(to: legacyStorageURL, options: .atomic)
            }
        }
    }

    private func loadRecordsFromDisk() {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601

        for url in [legacyStorageURL, primaryStorageURL] {
            guard FileManager.default.fileExists(atPath: url.path),
                  let data = try? Data(contentsOf: url),
                  let loaded = try? decoder.decode([AppUsageRecord].self, from: data) else { continue }
            for rec in loaded {
                if let existing = records[rec.bundleIdentifier] {
                    if rec.launchCount >= existing.launchCount {
                        records[rec.bundleIdentifier] = rec
                    }
                } else {
                    records[rec.bundleIdentifier] = rec
                }
            }
        }
    }

    private static let sizeCacheLock = NSLock()
    private nonisolated(unsafe) static var bundleSizeCache: [String: Int64] = [:]

    /// Tính toán dung lượng thực tế của một gói ứng dụng (.app) trên ổ đĩa (có bộ nhớ đệm chống nghẽn I/O)
    public static func calculateBundleSize(at appURL: URL) -> Int64 {
        let pathKey = appURL.path
        sizeCacheLock.lock()
        if let cached = bundleSizeCache[pathKey] {
            sizeCacheLock.unlock()
            return cached
        }
        sizeCacheLock.unlock()

        let fm = FileManager.default
        let keys: [URLResourceKey] = [.isRegularFileKey, .fileAllocatedSizeKey, .totalFileAllocatedSizeKey, .fileSizeKey]
        guard let enumerator = fm.enumerator(
            at: appURL,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles]
        ) else {
            return 0
        }

        var totalBytes: Int64 = 0
        var fileCount = 0
        for case let fileURL as URL in enumerator {
            fileCount += 1
            if fileCount > 200 { break }
            guard let values = try? fileURL.resourceValues(forKeys: Set(keys)),
                  values.isRegularFile == true else { continue }
            let size = values.totalFileAllocatedSize ?? values.fileAllocatedSize ?? values.fileSize ?? 0
            totalBytes += Int64(size)
        }

        sizeCacheLock.lock()
        bundleSizeCache[pathKey] = totalBytes
        sizeCacheLock.unlock()

        return totalBytes
    }
}
