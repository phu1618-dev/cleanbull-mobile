import Foundation

/// Trạng thái của một phiên cách ly.
public enum QuarantineSessionStatus: String, Codable, Sendable, CaseIterable {
    case quarantined = "quarantined"
    case restored = "restored"
    case partiallyRestored = "partially_restored"
    case purged = "purged"

    public var localizedTitle: String {
        switch self {
        case .quarantined:
            return "Đang cách ly"
        case .restored:
            return "Đã hoàn tác 100%"
        case .partiallyRestored:
            return "Hoàn tác một phần"
        case .purged:
            return "Đã xoá vĩnh viễn"
        }
    }
}

/// Phiên cách ly chứa tập hợp các bản ghi tệp cùng thời điểm.
public struct QuarantineSession: Identifiable, Codable, Sendable, Equatable, Hashable {
    /// Định danh phiên cách ly
    public let id: UUID

    /// Ngày tạo phiên
    public let dateCreated: Date

    /// Danh sách các tệp đã được đưa vào cách ly
    public var records: [ManifestRecord]

    /// Tổng dung lượng của phiên (bytes)
    public let totalSize: Int64

    /// Trạng thái phiên
    public var status: QuarantineSessionStatus

    public init(
        id: UUID = UUID(),
        dateCreated: Date = Date(),
        records: [ManifestRecord],
        totalSize: Int64,
        status: QuarantineSessionStatus = .quarantined
    ) {
        self.id = id
        self.dateCreated = dateCreated
        self.records = records
        self.totalSize = totalSize
        self.status = status
    }

    enum CodingKeys: String, CodingKey {
        case id = "session_id"
        case dateCreated = "date_created"
        case records
        case totalSize = "total_size"
        case status
    }
}

/// Thông tin lỗi khi khôi phục một bản ghi.
public struct RestoreFailure: Identifiable, Codable, Sendable, Equatable {
    public var id: UUID { record.id }
    public let record: ManifestRecord
    public let errorMessage: String

    public init(record: ManifestRecord, errorMessage: String) {
        self.record = record
        self.errorMessage = errorMessage
    }
}

/// Kết quả của quá trình hoàn tác một phiên cách ly.
public struct RestoreResult: Sendable, Equatable {
    public let sessionId: UUID
    public let restoredRecords: [ManifestRecord]
    public let failedRecords: [RestoreFailure]
    public let isFullyRestored: Bool

    public init(
        sessionId: UUID,
        restoredRecords: [ManifestRecord],
        failedRecords: [RestoreFailure]
    ) {
        self.sessionId = sessionId
        self.restoredRecords = restoredRecords
        self.failedRecords = failedRecords
        self.isFullyRestored = failedRecords.isEmpty && !restoredRecords.isEmpty
    }

    public var summaryMessage: String {
        if isFullyRestored {
            return "Hoàn tác thành công toàn bộ \(restoredRecords.count) tệp về vị trí gốc."
        } else if restoredRecords.isEmpty {
            return "Hoàn tác thất bại. Không có tệp nào được khôi phục."
        } else {
            return "Hoàn tác \(restoredRecords.count) tệp thành công, \(failedRecords.count) tệp gặp lỗi."
        }
    }
}
