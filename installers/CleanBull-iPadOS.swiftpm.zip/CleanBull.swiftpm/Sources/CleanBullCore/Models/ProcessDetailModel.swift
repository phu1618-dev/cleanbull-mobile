import Foundation

/// 5 nhóm phân loại rủi ro của tiến trình hệ thống.
public enum ProcessRiskCategory: String, Codable, Sendable, CaseIterable, Equatable {
    case orphan = "Tiến trình mồ côi"
    case headlessHog = "Ngốn RAM không cửa sổ"
    case launchAgent = "Chạy ngầm tự khởi động"
    case normalApp = "Ứng dụng thông thường"
    case protectedSystem = "Tiến trình Hệ thống"
}

/// Mô hình chi tiết của một tiến trình đang chạy trên hệ thống.
public struct ProcessDetailModel: Identifiable, Sendable, Equatable, Hashable {
    public let id: pid_t
    public let pid: pid_t
    public let name: String
    public let executablePath: String
    public let memoryBytes: UInt64
    public let cpuPercent: Double
    public let parentPid: pid_t
    public let isSystemProcess: Bool
    public let isGUIApp: Bool
    public let isOrphan: Bool
    public let riskCategory: ProcessRiskCategory
    public let explanation: String
    public let recommendation: String

    public init(
        id: pid_t,
        pid: pid_t,
        name: String,
        executablePath: String,
        memoryBytes: UInt64,
        cpuPercent: Double,
        parentPid: pid_t,
        isSystemProcess: Bool,
        isGUIApp: Bool,
        isOrphan: Bool,
        riskCategory: ProcessRiskCategory,
        explanation: String,
        recommendation: String
    ) {
        self.id = id
        self.pid = pid
        self.name = name
        self.executablePath = executablePath
        self.memoryBytes = memoryBytes
        self.cpuPercent = cpuPercent
        self.parentPid = parentPid
        self.isSystemProcess = isSystemProcess
        self.isGUIApp = isGUIApp
        self.isOrphan = isOrphan
        self.riskCategory = riskCategory
        self.explanation = explanation
        self.recommendation = recommendation
    }

    public var memoryFormatted: String {
        ByteCountFormatter.string(fromByteCount: Int64(memoryBytes), countStyle: .memory)
    }
}
