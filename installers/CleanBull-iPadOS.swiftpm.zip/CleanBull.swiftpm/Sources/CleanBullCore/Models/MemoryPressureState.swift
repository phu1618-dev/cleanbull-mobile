import Foundation

/// Trạng thái áp lực bộ nhớ theo chuẩn Darwin / Mach VM.
public enum MemoryPressureLevel: String, Codable, Sendable, CaseIterable {
    case normal = "normal"
    case warning = "warning"
    case critical = "critical"

    public var localizedTitle: String {
        switch self {
        case .normal:
            return "Bình thường"
        case .warning:
            return "Cảnh báo"
        case .critical:
            return "Nghiêm trọng"
        }
    }

    public var localizedDescription: String {
        switch self {
        case .normal:
            return "Bộ nhớ vận hành mượt mà. Hệ thống đang tận dụng tối đa RAM làm bộ đệm tệp (file cache) để tăng tốc độ phản hồi."
        case .warning:
            return "Áp lực bộ nhớ đang tăng. Cơ chế nén RAM (compressed memory) đang hoạt động tích cực để tránh sử dụng ổ đĩa."
        case .critical:
            return "Áp lực bộ nhớ ở mức cao! Hệ thống đang tráo đổi trang (swap) liên tục vào ổ cứng, gây giảm hiệu năng."
        }
    }

    public var badgeColor: String {
        switch self {
        case .normal:
            return "emerald"
        case .warning:
            return "amber"
        case .critical:
            return "rose"
        }
    }
}

/// Bản chụp trạng thái bộ nhớ chi tiết tại một thời điểm.
public struct MemorySnapshot: Sendable, Equatable {
    public let totalPhysicalBytes: UInt64
    public let appMemoryBytes: UInt64
    public let wiredBytes: UInt64
    public let activeBytes: UInt64
    public let inactiveBytes: UInt64
    public let compressedBytes: UInt64
    public let freeBytes: UInt64
    public let swapTotalBytes: UInt64
    public let swapUsedBytes: UInt64
    public let pressureLevel: MemoryPressureLevel
    public let timestamp: Date

    public init(
        totalPhysicalBytes: UInt64,
        appMemoryBytes: UInt64,
        wiredBytes: UInt64,
        activeBytes: UInt64,
        inactiveBytes: UInt64,
        compressedBytes: UInt64,
        freeBytes: UInt64,
        swapTotalBytes: UInt64,
        swapUsedBytes: UInt64,
        pressureLevel: MemoryPressureLevel,
        timestamp: Date = Date()
    ) {
        self.totalPhysicalBytes = totalPhysicalBytes
        self.appMemoryBytes = appMemoryBytes
        self.wiredBytes = wiredBytes
        self.activeBytes = activeBytes
        self.inactiveBytes = inactiveBytes
        self.compressedBytes = compressedBytes
        self.freeBytes = freeBytes
        self.swapTotalBytes = swapTotalBytes
        self.swapUsedBytes = swapUsedBytes
        self.pressureLevel = pressureLevel
        self.timestamp = timestamp
    }

    public var formattedTotalPhysical: String {
        ByteCountFormatter.string(fromByteCount: Int64(totalPhysicalBytes), countStyle: .memory)
    }

    public var formattedAppMemory: String {
        ByteCountFormatter.string(fromByteCount: Int64(appMemoryBytes), countStyle: .memory)
    }

    public var formattedWired: String {
        ByteCountFormatter.string(fromByteCount: Int64(wiredBytes), countStyle: .memory)
    }

    public var formattedCompressed: String {
        ByteCountFormatter.string(fromByteCount: Int64(compressedBytes), countStyle: .memory)
    }

    public var formattedInactive: String {
        ByteCountFormatter.string(fromByteCount: Int64(inactiveBytes), countStyle: .memory)
    }

    public var formattedFree: String {
        ByteCountFormatter.string(fromByteCount: Int64(freeBytes), countStyle: .memory)
    }

    public var formattedSwapUsed: String {
        ByteCountFormatter.string(fromByteCount: Int64(swapUsedBytes), countStyle: .memory)
    }

    public var formattedSwapTotal: String {
        ByteCountFormatter.string(fromByteCount: Int64(swapTotalBytes), countStyle: .memory)
    }

    /// Tỷ lệ bộ nhớ đã sử dụng (%)
    public var memoryUsagePercentage: Double {
        guard totalPhysicalBytes > 0 else { return 0.0 }
        let usedBytes = appMemoryBytes + wiredBytes + compressedBytes
        return min(100.0, max(0.0, (Double(usedBytes) / Double(totalPhysicalBytes)) * 100.0))
    }

    /// Lời giải thích trực quan minh bạch bằng tiếng Việt
    public var explanationText: String {
        switch pressureLevel {
        case .normal:
            return "Hệ thống chủ động lưu trữ dữ liệu tệp vào bộ nhớ đệm (Inactive: \(formattedInactive)) để tăng tốc mở ứng dụng. RAM trống thấp là hoàn toàn bình thường."
        case .warning:
            return "Hệ thống đang nén \(formattedCompressed) dữ liệu trong RAM. Hiệu năng vẫn đảm bảo nhưng nên đóng các tiến trình không dùng."
        case .critical:
            return "Bộ nhớ hoán đổi Swap đang chiếm \(formattedSwapUsed). Hãy kiểm tra và đóng các ứng dụng chiếm dụng RAM bất thường."
        }
    }
}
