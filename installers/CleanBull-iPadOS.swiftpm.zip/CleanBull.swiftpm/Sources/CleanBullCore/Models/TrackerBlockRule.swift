import Foundation

/// Phân loại hệ sinh thái Tracker / Quảng cáo
public enum TrackerCategory: String, Codable, Sendable, CaseIterable {
    case bytedanceTikTok = "bytedance_tiktok"
    case metaGraph = "meta_graph"
    case googleTracking = "google_tracking"
    case attribution = "mobile_attribution"
    case inAppAds = "in_app_ads"
    case other = "other"

    public var localizedTitle: String {
        switch self {
        case .bytedanceTikTok: return "ByteDance / TikTok Telemetry"
        case .metaGraph: return "Meta / Facebook Graph & Pixel"
        case .googleTracking: return "Google DoubleClick & Firebase Analytics"
        case .attribution: return "Attribution (AppsFlyer, Adjust, Branch)"
        case .inAppAds: return "Mạng quảng cáo trong ứng dụng (Unity, Vungle)"
        case .other: return "Theo dõi & Thu thập dữ liệu khác"
        }
    }
}

/// Quy tắc chặn một tên miền hoặc tiền tố miền
public struct TrackerBlockRule: Identifiable, Codable, Sendable, Equatable {
    public let id: String
    public let category: TrackerCategory
    public let domain: String
    public let isWildcard: Bool
    public let note: String

    public init(
        id: String,
        category: TrackerCategory,
        domain: String,
        isWildcard: Bool = true,
        note: String = ""
    ) {
        self.id = id
        self.category = category
        self.domain = domain.lowercased()
        self.isWildcard = isWildcard
        self.note = note
    }
}
