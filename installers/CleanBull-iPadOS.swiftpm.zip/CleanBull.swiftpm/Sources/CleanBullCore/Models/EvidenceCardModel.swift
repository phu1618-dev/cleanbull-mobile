import Foundation

/// Mức độ rủi ro khi dọn dẹp hoặc cách ly một mục tệp tin.
public enum RiskLevel: String, Codable, Sendable, CaseIterable {
    case low = "low"
    case medium = "medium"
    case high = "high"

    /// Tên hiển thị bằng tiếng Việt
    public var localizedTitle: String {
        switch self {
        case .low:
            return "Rủi ro thấp"
        case .medium:
            return "Rủi ro trung bình"
        case .high:
            return "Rủi ro cao"
        }
    }

    /// Mô tả chi tiết mức độ rủi ro
    public var localizedDescription: String {
        switch self {
        case .low:
            return "Tệp tạm thời, cache hoặc log có thể tạo lại tự động mà không ảnh hưởng đến ứng dụng."
        case .medium:
            return "Tệp tải về hoặc dữ liệu ứng dụng cũ, cần xác nhận trước khi cách ly."
        case .high:
            return "Tệp cấu hình hoặc tệp có liên kết quan trọng, khuyến nghị sao lưu trước khi xử lý."
        }
    }

    /// Tên màu sắc gợi ý trong hệ thống giao diện
    public var colorName: String {
        switch self {
        case .low:
            return "emerald"
        case .medium:
            return "amber"
        case .high:
            return "rose"
        }
    }
}

/// Data Model đại diện cho "Thẻ Bằng Chứng" (Evidence Card) giải thích minh bạch ngữ cảnh từng tệp/thư mục.
public struct EvidenceCardModel: Identifiable, Codable, Sendable, Hashable, Equatable {
    /// Định danh duy nhất của mục
    public let id: UUID

    /// Đường dẫn tuyệt đối của tệp hoặc thư mục
    public let path: String

    /// Dung lượng tệp tính bằng bytes
    public let fileSize: Int64

    /// Loại tệp (ví dụ: "App Cache", "System Log", "Download File", "App Leftover",...)
    public let fileType: String

    /// Chủ sở hữu tệp (User hoặc Process Owner)
    public let owner: String

    /// Thời điểm sửa đổi gần nhất
    public let lastModifiedDate: Date

    /// Thời điểm truy cập gần nhất
    public let lastAccessedDate: Date

    /// Điểm độ tin cậy từ 0 đến 100 (Càng cao càng an toàn để dọn)
    public let confidenceScore: Int

    /// Mức độ rủi ro (Low / Medium / High)
    public let riskLevel: RiskLevel

    /// Lời giải thích rõ ràng bằng tiếng Việt: Đây là gì? Vì sao nên xem xét?
    public let explanationText: String

    /// Cảnh báo tác động bằng tiếng Việt: Nếu xoá thì có rủi ro gì?
    public let potentialImpactText: String

    public init(
        id: UUID = UUID(),
        path: String,
        fileSize: Int64,
        fileType: String,
        owner: String = ProcessInfo.processInfo.environment["USER"] ?? "User",
        lastModifiedDate: Date = Date(),
        lastAccessedDate: Date = Date(),
        confidenceScore: Int,
        riskLevel: RiskLevel,
        explanationText: String,
        potentialImpactText: String
    ) {
        self.id = id
        self.path = path
        self.fileSize = fileSize
        self.fileType = fileType
        self.owner = owner
        self.lastModifiedDate = lastModifiedDate
        self.lastAccessedDate = lastAccessedDate
        self.confidenceScore = max(0, min(100, confidenceScore))
        self.riskLevel = riskLevel
        self.explanationText = explanationText
        self.potentialImpactText = potentialImpactText
    }

    /// URL tương ứng với đường dẫn
    public var url: URL {
        URL(fileURLWithPath: path)
    }

    /// Tên tệp tin
    public var fileName: String {
        url.lastPathComponent
    }

    /// Định dạng dung lượng dễ đọc cho con người (VD: "245.8 MB", "1.2 GB")
    public var formattedFileSize: String {
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useBytes, .useKB, .useMB, .useGB]
        formatter.countStyle = .file
        return formatter.string(fromByteCount: fileSize)
    }

    /// Đánh giá độ tin cậy theo phân cấp
    public var isHighConfidence: Bool {
        confidenceScore >= 85
    }
}
