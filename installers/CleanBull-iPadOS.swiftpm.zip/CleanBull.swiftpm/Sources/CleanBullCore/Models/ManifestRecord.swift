import Foundation

/// Bản ghi chi tiết của từng tệp tin trong danh mục cách ly `manifest.json`.
public struct ManifestRecord: Identifiable, Codable, Sendable, Equatable, Hashable {
    /// Định danh duy nhất của bản ghi
    public let id: UUID

    /// Đường dẫn gốc tuyệt đối trước khi bị cách ly
    public let originalPath: String

    /// Tên hoặc đường dẫn tệp trong kho lưu trữ cách ly
    public let quarantinePath: String

    /// Mã băm SHA-256 xác thực tính toàn vẹn của tệp
    public let sha256Checksum: String

    /// Quyền truy cập POSIX (chmod: ví dụ 0o644, 0o755)
    public let posixPermissions: UInt16

    /// Thời điểm thực hiện cách ly
    public let dateQuarantined: Date

    /// Mã quy tắc nhận diện đã phát hiện mục này
    public let ruleId: String

    /// Kích thước tệp tin tại thời điểm cách ly
    public let fileSize: Int64

    /// Loại tệp tin
    public let fileType: String

    /// Thời điểm sửa đổi gốc của tệp
    public let originalModificationDate: Date?

    public init(
        id: UUID = UUID(),
        originalPath: String,
        quarantinePath: String,
        sha256Checksum: String,
        posixPermissions: UInt16,
        dateQuarantined: Date = Date(),
        ruleId: String,
        fileSize: Int64,
        fileType: String,
        originalModificationDate: Date? = nil
    ) {
        self.id = id
        self.originalPath = originalPath
        self.quarantinePath = quarantinePath
        self.sha256Checksum = sha256Checksum
        self.posixPermissions = posixPermissions
        self.dateQuarantined = dateQuarantined
        self.ruleId = ruleId
        self.fileSize = fileSize
        self.fileType = fileType
        self.originalModificationDate = originalModificationDate
    }

    enum CodingKeys: String, CodingKey {
        case id = "file_id"
        case originalPath = "original_path"
        case quarantinePath = "quarantine_path"
        case sha256Checksum = "sha256_checksum"
        case posixPermissions = "posix_permissions"
        case dateQuarantined = "date_quarantined"
        case ruleId = "rule_id"
        case fileSize = "file_size"
        case fileType = "file_type"
        case originalModificationDate = "original_modification_date"
    }
}
