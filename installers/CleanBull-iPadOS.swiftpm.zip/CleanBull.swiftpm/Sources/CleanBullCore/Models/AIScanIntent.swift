import Foundation

/// Hành động điều khiển VPN từ câu lệnh tiếng Việt
public enum VPNIntentAction: Sendable, Equatable {
    case enable
    case disable
    case switchMode(Int)
    case checkDomain(String)
}

/// Cấu trúc mục tiêu quét sau khi AI phân tích ý định người dùng.
public struct AIScanIntent: Sendable, Equatable {
    public var targetDirectories: [URL]
    public var fileExtensions: [String]
    public var minSizeBytes: Int64
    public var minAgeDays: Int
    public var keywords: [String]
    public var intentDescription: String
    public var vpnAction: VPNIntentAction?

    public init(
        targetDirectories: [URL] = [],
        fileExtensions: [String] = [],
        minSizeBytes: Int64 = 0,
        minAgeDays: Int = 0,
        keywords: [String] = [],
        intentDescription: String = "Quét tệp theo nhu cầu cá nhân",
        vpnAction: VPNIntentAction? = nil
    ) {
        self.targetDirectories = targetDirectories
        self.fileExtensions = fileExtensions
        self.minSizeBytes = minSizeBytes
        self.minAgeDays = minAgeDays
        self.keywords = keywords
        self.intentDescription = intentDescription
        self.vpnAction = vpnAction
    }
}
