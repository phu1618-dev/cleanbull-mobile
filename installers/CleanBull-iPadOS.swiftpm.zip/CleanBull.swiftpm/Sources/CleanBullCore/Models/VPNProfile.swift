import Foundation

/// 3 Chế độ hoạt động của Unified VPN Shield (1 khe cắm hệ thống)
public enum VPNMode: Int, Codable, Sendable, CaseIterable {
    case localDNS = 1
    case cloudflareWarp = 2
    case customPro = 3

    public var title: String {
        switch self {
        case .localDNS:
            return "Chế độ 1: Khiên Chống Theo Dõi Cục Bộ"
        case .cloudflareWarp:
            return "Chế độ 2: VPN Mã Hóa Đa Quốc Gia (WARP+ / BBR)"
        case .customPro:
            return "Chế độ 3: Cấu Hình Tùy Chỉnh & Máy Chủ Riêng"
        }
    }

    public var subtitle: String {
        switch self {
        case .localDNS:
            return "Chặn quảng cáo, telemetry và tên miền theo dõi trực tiếp trên thiết bị, tiết kiệm pin."
        case .cloudflareWarp:
            return "Chuyển đổi vùng lãnh thổ/quốc gia, mã hóa lưu lượng với WireGuard/AmneziaWG & tăng tốc BBR."
        case .customPro:
            return "Hỗ trợ WireGuard, AmneziaWG (chống DPI), Sing-box JSON và VPS riêng."
        }
    }
}

/// Danh sách 8 Vùng Lãnh Thổ / Quốc Gia Máy Chủ VPN
public enum VPNRegion: String, Codable, Sendable, CaseIterable, Identifiable {
    case singapore = "SG"
    case japan = "JP"
    case hongKong = "HK"
    case korea = "KR"
    case germany = "DE"
    case usa = "US"
    case uk = "UK"
    case autoOptimal = "AUTO"

    public var id: String { rawValue }
    public var code: String { rawValue }

    public var countryNameVi: String {
        switch self {
        case .singapore: return "Singapore (SG)"
        case .japan: return "Nhật Bản (JP)"
        case .hongKong: return "Hồng Kông (HK)"
        case .korea: return "Hàn Quốc (KR)"
        case .germany: return "Đức (DE)"
        case .usa: return "Hoa Kỳ (US)"
        case .uk: return "Anh Quốc (UK)"
        case .autoOptimal: return "Tự động tối ưu (AUTO)"
        }
    }

    public var cityVi: String {
        switch self {
        case .singapore: return "Singapore — Đông Nam Á (Equinix SG1)"
        case .japan: return "Tokyo — Đông Bắc Á (Equinix TY2)"
        case .hongKong: return "Hong Kong — Á Châu (HKG1)"
        case .korea: return "Seoul — Đông Bắc Á (KR-ICN1)"
        case .germany: return "Frankfurt — Châu Âu (DE-CIX FRA1)"
        case .usa: return "Los Angeles — Bắc Mỹ (US-West LAX1)"
        case .uk: return "London — Tây Âu (LON1)"
        case .autoOptimal: return "Trạm Anycast gần nhất"
        }
    }

    public var host: String {
        switch self {
        case .singapore: return "162.159.192.1"
        case .japan: return "188.114.96.1"
        case .hongKong: return "188.114.97.1"
        case .korea: return "188.114.97.2"
        case .germany: return "162.159.193.1"
        case .usa: return "162.159.195.1"
        case .uk: return "188.114.98.1"
        case .autoOptimal: return "162.159.192.2"
        }
    }

    public var tunnelIPv4: String {
        switch self {
        case .singapore: return "10.88.1.2"
        case .japan: return "10.88.4.2"
        case .hongKong: return "10.88.5.2"
        case .korea: return "10.88.7.2"
        case .germany: return "10.88.2.2"
        case .usa: return "10.88.3.2"
        case .uk: return "10.88.6.2"
        case .autoOptimal: return "172.16.0.2"
        }
    }

    public var dnsServers: [String] {
        switch self {
        case .germany, .uk:
            return ["1.1.1.1", "94.140.14.14"]
        default:
            return ["1.1.1.1", "1.0.0.1"]
        }
    }

    public var optimalMtu: Int {
        switch self {
        case .germany, .usa, .uk:
            return 1400
        default:
            return 1420
        }
    }

    public var distanceFactor: Double {
        switch self {
        case .autoOptimal: return 1.00
        case .hongKong: return 0.99
        case .singapore: return 0.98
        case .korea: return 0.95
        case .japan: return 0.94
        case .usa: return 0.88
        case .germany: return 0.86
        case .uk: return 0.85
        }
    }
}

/// Cấu hình tăng tốc băng thông khi chuyển vùng quốc gia
public enum TunnelSpeedProfile: String, Codable, Sendable, CaseIterable, Identifiable {
    case turboBBR = "turbo_bbr"
    case balanced = "balanced"
    case antiDPI = "anti_dpi"

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .turboBBR: return "1. Tối ưu tốc độ (BBR)"
        case .balanced: return "2. Cân Bằng Đa Mạng"
        case .antiDPI: return "3. Vượt chặn mạng (Anti-DPI)"
        }
    }

    public func subtitle(for region: VPNRegion) -> String {
        switch self {
        case .turboBBR:
            return "MTU \(region.optimalMtu) • Cổng 443 • BBR"
        case .balanced:
            return "MTU 1400 • Cổng 500 • Chuyển vùng mượt"
        case .antiDPI:
            return "MTU 1280 • AmneziaWG Jc=4, Jmax=70"
        }
    }

    public func effectiveMtu(for region: VPNRegion) -> Int {
        switch self {
        case .turboBBR: return region.optimalMtu
        case .balanced: return 1400
        case .antiDPI: return 1280
        }
    }

    public var effectiveKeepalive: Int {
        switch self {
        case .turboBBR: return 15
        case .balanced: return 20
        case .antiDPI: return 25
        }
    }
}

/// Cổng UDP tối ưu vượt bóp băng thông quốc tế
public enum TunnelPortOption: Int, Codable, Sendable, CaseIterable, Identifiable {
    case quic443 = 443
    case ipsec500 = 500
    case warp2408 = 2408

    public var id: Int { rawValue }

    public var label: String {
        switch self {
        case .quic443: return ":443 (QUIC)"
        case .ipsec500: return ":500 (IPSec)"
        case .warp2408: return ":2408 (WARP)"
        }
    }
}

/// Thông tin IP công khai và trạm kết nối thực tế từ Cloudflare Trace
public struct ClientNetworkTrace: Codable, Sendable, Equatable {
    public var ip: String?
    public var colo: String?
    public var loc: String?
    public var warp: String?
    public var httpRttMs: Int?

    public init(
        ip: String? = nil,
        colo: String? = nil,
        loc: String? = nil,
        warp: String? = nil,
        httpRttMs: Int? = nil
    ) {
        self.ip = ip
        self.colo = colo
        self.loc = loc
        self.warp = warp
        self.httpRttMs = httpRttMs
    }
}

/// Trạng thái kết nối VPN
public enum VPNStatus: Codable, Sendable, Equatable {
    case disconnected
    case connecting
    case connected
    case disconnecting
    case error(String)

    public var title: String {
        switch self {
        case .disconnected: return "Đã ngắt kết nối"
        case .connecting: return "Đang kết nối..."
        case .connected: return "Đang bảo vệ"
        case .disconnecting: return "Đang ngắt kết nối..."
        case .error(let msg): return "Lỗi: \(msg)"
        }
    }

    public var isConnected: Bool {
        if case .connected = self { return true }
        return false
    }
}

/// Tham số xáo trộn gói tin chống kiểm duyệt DPI của AmneziaWG
public struct AmneziaParams: Codable, Sendable, Equatable {
    public var jc: Int
    public var jmin: Int
    public var jmax: Int
    public var s1: Int
    public var s2: Int
    public var h1: UInt32
    public var h2: UInt32
    public var h3: UInt32
    public var h4: UInt32

    public init(
        jc: Int = 4,
        jmin: Int = 40,
        jmax: Int = 70,
        s1: Int = 15,
        s2: Int = 30,
        h1: UInt32 = 1,
        h2: UInt32 = 2,
        h3: UInt32 = 3,
        h4: UInt32 = 4
    ) {
        self.jc = jc
        self.jmin = jmin
        self.jmax = jmax
        self.s1 = s1
        self.s2 = s2
        self.h1 = h1
        self.h2 = h2
        self.h3 = h3
        self.h4 = h4
    }
}

/// Cấu hình hồ sơ VPN
public struct VPNProfile: Identifiable, Codable, Sendable, Equatable {
    public let id: UUID
    public var name: String
    public var mode: VPNMode
    public var region: VPNRegion
    public var speedProfile: TunnelSpeedProfile
    public var mtu: Int
    public var serverAddress: String
    public var serverPort: Int
    public var privateKey: String
    public var publicKey: String
    public var peerPublicKey: String
    public var presharedKey: String?
    public var assignedIPv4: String
    public var assignedIPv6: String?
    public var dnsServers: [String]
    public var amneziaParams: AmneziaParams?
    public var reservedBytes: [UInt8]?

    public init(
        id: UUID = UUID(),
        name: String,
        mode: VPNMode,
        region: VPNRegion = .singapore,
        speedProfile: TunnelSpeedProfile = .turboBBR,
        mtu: Int = 1420,
        serverAddress: String = "162.159.192.1",
        serverPort: Int = 443,
        privateKey: String = "",
        publicKey: String = "",
        peerPublicKey: String = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=",
        presharedKey: String? = nil,
        assignedIPv4: String = "172.16.0.2",
        assignedIPv6: String? = nil,
        dnsServers: [String] = ["1.1.1.1", "1.0.0.1"],
        amneziaParams: AmneziaParams? = nil,
        reservedBytes: [UInt8]? = nil
    ) {
        self.id = id
        self.name = name
        self.mode = mode
        self.region = region
        self.speedProfile = speedProfile
        self.mtu = mtu
        self.serverAddress = serverAddress
        self.serverPort = serverPort
        self.privateKey = privateKey
        self.publicKey = publicKey
        self.peerPublicKey = peerPublicKey
        self.presharedKey = presharedKey
        self.assignedIPv4 = assignedIPv4
        self.assignedIPv6 = assignedIPv6
        self.dnsServers = dnsServers
        self.amneziaParams = amneziaParams
        self.reservedBytes = reservedBytes
    }
}

/// Mục nhật ký chặn theo dõi (truy vấn thời gian thực)
public struct LiveRadarEntry: Identifiable, Codable, Sendable, Equatable {
    public let id: UUID
    public let timestamp: Date
    public let domain: String
    public let blocked: Bool
    public let category: String
    public let clientApp: String

    public init(
        id: UUID = UUID(),
        timestamp: Date = Date(),
        domain: String,
        blocked: Bool,
        category: String,
        clientApp: String = "Hệ thống"
    ) {
        self.id = id
        self.timestamp = timestamp
        self.domain = domain
        self.blocked = blocked
        self.category = category
        self.clientApp = clientApp
    }
}
