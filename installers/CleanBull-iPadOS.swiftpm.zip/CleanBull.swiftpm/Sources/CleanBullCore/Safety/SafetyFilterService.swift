import Foundation

/// Dịch vụ kiểm tra và thẩm định mức độ an toàn của đường dẫn trước mọi tác vụ quét/cách ly/dọn dẹp.
public struct SafetyFilterService: Sendable {
    public let homeDirectory: URL

    /// Khởi tạo dịch vụ với Home Directory tùy chọn
    public init(homeDirectory: URL = FileManager.default.homeDirectoryForCurrentUser) {
        self.homeDirectory = homeDirectory
    }

    /// Thẩm định đường dẫn URL xem có an toàn để thao tác hay không.
    /// - Parameter url: Đường dẫn tệp hoặc thư mục cần kiểm tra.
    /// - Returns: Tuple gồm `isSafe` (True nếu an toàn) và `reason` (Lý do chi tiết bằng tiếng Việt).
    public func isSafeToProcess(url: URL) -> (isSafe: Bool, reason: String) {
        let rawPath = url.path
        let standardizedPath = (rawPath as NSString).standardizingPath
        let resolvedURL = url.resolvingSymlinksInPath()
        let resolvedPath = (resolvedURL.path as NSString).standardizingPath

        // 1. Kiểm tra đường dẫn rỗng hoặc là thư mục gốc "/"
        if standardizedPath.isEmpty || standardizedPath == "/" || resolvedPath == "/" {
            return (false, "Đường dẫn không hợp lệ hoặc là thư mục gốc của hệ thống.")
        }

        let homePath = (homeDirectory.path as NSString).standardizingPath
        let resolvedHomePath = (homeDirectory.resolvingSymlinksInPath().path as NSString).standardizingPath

        let isInsideHome = standardizedPath == homePath ||
                           standardizedPath.hasPrefix(homePath + "/") ||
                           resolvedPath == resolvedHomePath ||
                           resolvedPath.hasPrefix(resolvedHomePath + "/")

        let isTempLocation = standardizedPath == "/tmp" ||
                             standardizedPath.hasPrefix("/tmp/") ||
                             standardizedPath == "/private/tmp" ||
                             standardizedPath.hasPrefix("/private/tmp/") ||
                             standardizedPath.hasPrefix("/var/folders/") ||
                             standardizedPath.hasPrefix("/private/var/folders/")

        // 2. Thẩm định vùng cấm hệ thống
        for sysSub in ProtectedPaths.sensitiveSystemSubpaths {
            if standardizedPath == sysSub || standardizedPath.hasPrefix(sysSub + "/") {
                return (false, "Đây là thư mục hệ thống quan trọng (\(sysSub)), được bảo vệ bất khả xâm phạm.")
            }
            if (resolvedPath == sysSub || resolvedPath.hasPrefix(sysSub + "/")) && !isTempLocation {
                return (false, "Đích đến thực tế của liên kết tượng trưng (Symlink) trỏ vào thư mục hệ thống (\(sysSub)).")
            }
        }

        for root in ProtectedPaths.systemRoots {
            if (standardizedPath == root || standardizedPath.hasPrefix(root + "/")) && !isInsideHome && !isTempLocation {
                return (false, "Đây là thư mục hệ thống quan trọng (\(root)), được bảo vệ bất khả xâm phạm.")
            }
            if (resolvedPath == root || resolvedPath.hasPrefix(root + "/")) && !isInsideHome && !isTempLocation {
                return (false, "Đích đến thực tế của liên kết tượng trưng (Symlink) trỏ vào thư mục hệ thống (\(root)).")
            }
        }

        // 3. Kiểm tra các thư mục nhạy cảm của người dùng (tính từ Home Directory)
        for pattern in ProtectedPaths.sensitiveUserPaths {
            let expandedPath: String
            let expandedResolvedPath: String
            if pattern.hasPrefix("~/") {
                let subPath = String(pattern.dropFirst(2))
                expandedPath = (homePath as NSString).appendingPathComponent(subPath)
                expandedResolvedPath = (resolvedHomePath as NSString).appendingPathComponent(subPath)
            } else {
                expandedPath = (pattern as NSString).standardizingPath
                expandedResolvedPath = expandedPath
            }

            if standardizedPath == expandedPath || standardizedPath.hasPrefix(expandedPath + "/") ||
               standardizedPath == expandedResolvedPath || standardizedPath.hasPrefix(expandedResolvedPath + "/") {
                return (false, "Đường dẫn thuộc khu vực dữ liệu cá nhân nhạy cảm (\(pattern)), không được phép tác động.")
            }
            if resolvedPath == expandedPath || resolvedPath.hasPrefix(expandedPath + "/") ||
               resolvedPath == expandedResolvedPath || resolvedPath.hasPrefix(expandedResolvedPath + "/") {
                return (false, "Đích đến của liên kết thuộc khu vực dữ liệu cá nhân nhạy cảm (\(pattern)).")
            }
        }

        // 4. Kiểm tra từng thành phần đường dẫn (Path components)
        let pathComponents = url.pathComponents
        for component in pathComponents {
            if ProtectedPaths.criticalFileNames.contains(component) {
                return (false, "Đường dẫn chứa thành phần cấu hình hoặc dự án nhạy cảm: '\(component)'.")
            }

            let compExtension = (component as NSString).pathExtension.lowercased()
            if ProtectedPaths.criticalExtensions.contains(compExtension) {
                return (false, "Đường dẫn chứa thành phần mang định dạng được bảo vệ: '.\(compExtension)' (\(component)).")
            }
        }

        // 5. Kiểm tra phần mở rộng của tệp tin
        let fileExtension = url.pathExtension.lowercased()
        if ProtectedPaths.criticalExtensions.contains(fileExtension) {
            return (false, "Định dạng tệp (.\(fileExtension)) là tệp dự án hoặc chứng chỉ/khóa bảo mật quan trọng.")
        }

        // 6. Kiểm tra tên tệp tin (Last path component)
        let fileName = url.lastPathComponent
        if ProtectedPaths.criticalFileNames.contains(fileName) {
            return (false, "Tệp '\(fileName)' là tệp cấu hình hệ thống hoặc khoá bảo mật quan trọng.")
        }

        // 7. Chặn tác động đệ quy vào chính thư mục Quarantine của CleanBull / CleanGiabull
        let quarantinePathCleanBull = (homePath as NSString).appendingPathComponent(".local/share/CleanBull/Quarantine")
        let quarantinePathCleanGiabull = (homePath as NSString).appendingPathComponent(".local/share/CleanGiabull/Quarantine")
        for qPath in [quarantinePathCleanBull, quarantinePathCleanGiabull] {
            if standardizedPath == qPath || standardizedPath.hasPrefix(qPath + "/") ||
               resolvedPath == qPath || resolvedPath.hasPrefix(qPath + "/") {
                return (false, "Tệp/thư mục đang nằm trong khu vực cách ly.")
            }
        }

        // 8. Nếu là Symbolic Link, kiểm tra tính hợp lệ và đích đến
        let fileManager = FileManager.default
        if let attrs = try? fileManager.attributesOfItem(atPath: standardizedPath),
           let fileType = attrs[.type] as? FileAttributeType,
           fileType == .typeSymbolicLink {
            let destination = (try? fileManager.destinationOfSymbolicLink(atPath: standardizedPath)) ?? ""
            if destination.isEmpty {
                return (false, "Liên kết tượng trưng (Symlink) không hợp lệ hoặc đã hỏng.")
            }
            let destURL = URL(fileURLWithPath: destination, relativeTo: url).standardized
            let destCheck = isSafeToProcess(url: destURL)
            if !destCheck.isSafe {
                return (false, "Liên kết tượng trưng (Symlink) trỏ tới vị trí không an toàn: \(destCheck.reason)")
            }
        }

        return (true, "Đường dẫn an toàn để xử lý.")
    }
}
