import Foundation

/// Danh mục các đường dẫn, định dạng và tệp tin bất khả xâm phạm trên iPadOS/macOS.
public struct ProtectedPaths: Sendable {
    /// 12 Thư mục gốc hệ thống được bảo vệ tuyệt đối
    public static let systemRoots: Set<String> = [
        "/System",
        "/usr",
        "/bin",
        "/sbin",
        "/var",
        "/etc",
        "/private",
        "/Library",
        "/dev",
        "/Volumes",
        "/cores",
        "/opt"
    ]

    /// Thư mục con hệ thống nhạy cảm trong /private và /var
    public static let sensitiveSystemSubpaths: Set<String> = [
        "/private/etc",
        "/private/var/db",
        "/private/var/root",
        "/private/var/vm",
        "/private/var/audit",
        "/private/var/log",
        "/var/root",
        "/var/db",
        "/var/vm",
        "/var/audit",
        "/var/log"
    ]

    /// 13 Thư mục nhạy cảm của người dùng (tính từ Home directory)
    public static let sensitiveUserPaths: [String] = [
        "~/.ssh",
        "~/.gnupg",
        "~/.aws",
        "~/.config",
        "~/.local/share/keyrings",
        "~/Library/Keychains",
        "~/Library/IdentityServices",
        "~/Library/Accounts",
        "~/Library/Mobile Documents", // iCloud Drive
        "~/Library/Mail",
        "~/Library/Messages",
        "~/Library/Safari",
        "~/Library/Cookies",
        "~/Library/Containers/com.apple.mail"
    ]

    /// 7 Phần mở rộng tệp tin quan trọng không bao giờ được phép xoá hoặc cách ly tự động
    public static let criticalExtensions: Set<String> = [
        "keychain",
        "keychain-db",
        "xcodeproj",
        "xcworkspace",
        "git",
        "xcuserdatad",
        "identityservice"
    ]

    /// 21+ Tên các tệp tin cấu hình hoặc khóa bảo mật nhạy cảm
    public static let criticalFileNames: Set<String> = [
        ".git",
        ".gitignore",
        ".gitmodules",
        ".github",
        ".ssh",
        ".gnupg",
        ".aws",
        ".zshrc",
        ".bashrc",
        ".bash_profile",
        ".profile",
        ".zprofile",
        "id_rsa",
        "id_ed25519",
        "id_ecdsa",
        "id_dsa",
        "known_hosts",
        "authorized_keys",
        "sudoers",
        "hosts",
        "passwd",
        "shadow",
        "master.passwd"
    ]
}
