import Foundation

/// Dịch vụ so khớp tên miền với danh sách quy tắc Tracker / Quảng cáo
public final class DNSBlocklistMatcher: Sendable {
    public let rules: [TrackerBlockRule]
    private let domainMap: [String: TrackerBlockRule]
    private let wildcardSuffixes: [(suffix: String, rule: TrackerBlockRule)]

    public init(customRules: [TrackerBlockRule]? = nil) {
        let activeRules = customRules ?? DNSBlocklistMatcher.defaultRules
        self.rules = activeRules

        var map: [String: TrackerBlockRule] = [:]
        var wildcards: [(String, TrackerBlockRule)] = []

        for rule in activeRules {
            let lower = rule.domain.lowercased()
            if rule.isWildcard || lower.hasPrefix("*.") {
                let cleanSuffix = lower.hasPrefix("*.") ? String(lower.dropFirst(2)) : lower
                wildcards.append((cleanSuffix, rule))
                map[cleanSuffix] = rule
            } else {
                map[lower] = rule
            }
        }

        self.domainMap = map
        self.wildcardSuffixes = wildcards
    }

    /// Kiểm tra xem một tên miền có nằm trong danh sách đen bị chặn hay không
    public func matchDomain(_ domain: String) -> (isBlocked: Bool, rule: TrackerBlockRule?) {
        let cleanDomain = domain.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()

        // 1. Khớp chính xác
        if let directRule = domainMap[cleanDomain] {
            return (true, directRule)
        }

        // 2. Khớp hậu tố tên miền (Wildcard / Subdomain)
        for item in wildcardSuffixes {
            if cleanDomain == item.suffix || cleanDomain.hasSuffix("." + item.suffix) {
                return (true, item.rule)
            }
        }

        return (false, nil)
    }

    /// Danh sách quy tắc mặc định theo 5 hệ sinh thái mục tiêu
    public static var defaultRules: [TrackerBlockRule] {
        return [
            // ByteDance / TikTok
            TrackerBlockRule(id: "tt_01", category: .bytedanceTikTok, domain: "byteoversea.com", isWildcard: true, note: "ByteDance Global Telemetry"),
            TrackerBlockRule(id: "tt_02", category: .bytedanceTikTok, domain: "ibytedtos.com", isWildcard: true, note: "ByteDance Tracker CDN"),
            TrackerBlockRule(id: "tt_03", category: .bytedanceTikTok, domain: "musical.ly", isWildcard: true, note: "Musical.ly Analytics"),
            TrackerBlockRule(id: "tt_04", category: .bytedanceTikTok, domain: "tiktokv.com", isWildcard: true, note: "TikTok Telemetry Domain"),
            TrackerBlockRule(id: "tt_05", category: .bytedanceTikTok, domain: "tiktokcdn.com", isWildcard: true, note: "TikTok Tracking CDN"),
            TrackerBlockRule(id: "tt_06", category: .bytedanceTikTok, domain: "analytics.tiktok.com", isWildcard: false, note: "TikTok Business Analytics"),

            // Meta / Facebook
            TrackerBlockRule(id: "fb_01", category: .metaGraph, domain: "graph.facebook.com", isWildcard: false, note: "Meta Graph User Telemetry"),
            TrackerBlockRule(id: "fb_02", category: .metaGraph, domain: "pixel.facebook.com", isWildcard: false, note: "Facebook Conversion Pixel"),
            TrackerBlockRule(id: "fb_03", category: .metaGraph, domain: "an.facebook.com", isWildcard: false, note: "Facebook Audience Network"),
            TrackerBlockRule(id: "fb_04", category: .metaGraph, domain: "b-graph.facebook.com", isWildcard: false, note: "Facebook Batch Graph API"),

            // Google Tracking
            TrackerBlockRule(id: "gg_01", category: .googleTracking, domain: "adservice.google.com", isWildcard: false, note: "Google Ad Service"),
            TrackerBlockRule(id: "gg_02", category: .googleTracking, domain: "pagead2.googlesyndication.com", isWildcard: false, note: "Google DoubleClick PageAd"),
            TrackerBlockRule(id: "gg_03", category: .googleTracking, domain: "app-measurement.com", isWildcard: true, note: "Firebase / Google App Measurement"),
            TrackerBlockRule(id: "gg_04", category: .googleTracking, domain: "googleads.g.doubleclick.net", isWildcard: false, note: "Google DoubleClick Network"),

            // Mobile Attribution
            TrackerBlockRule(id: "attr_01", category: .attribution, domain: "appsflyer.com", isWildcard: true, note: "AppsFlyer Mobile Attribution"),
            TrackerBlockRule(id: "attr_02", category: .attribution, domain: "adjust.com", isWildcard: true, note: "Adjust Mobile Analytics"),
            TrackerBlockRule(id: "attr_03", category: .attribution, domain: "branch.io", isWildcard: true, note: "Branch Metrics Deep Link Telemetry"),
            TrackerBlockRule(id: "attr_04", category: .attribution, domain: "kochava.com", isWildcard: true, note: "Kochava Device Fingerprinting"),

            // In-app Ad Networks
            TrackerBlockRule(id: "ad_01", category: .inAppAds, domain: "unityads.unity3d.com", isWildcard: true, note: "Unity Ads Tracking"),
            TrackerBlockRule(id: "ad_02", category: .inAppAds, domain: "vungle.com", isWildcard: true, note: "Vungle Ad Network"),
            TrackerBlockRule(id: "ad_03", category: .inAppAds, domain: "inmobi.com", isWildcard: true, note: "InMobi Mobile Advertising"),
            TrackerBlockRule(id: "ad_04", category: .inAppAds, domain: "ironsrc.com", isWildcard: true, note: "ironSource Ad Network")
        ]
    }
}
