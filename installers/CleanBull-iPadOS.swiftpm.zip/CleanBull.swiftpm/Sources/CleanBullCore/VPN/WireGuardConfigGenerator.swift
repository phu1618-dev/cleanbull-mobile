import Foundation

/// Trình sinh cấu hình WireGuard, AmneziaWG (chống DPI), Sing-box JSON và Apple DNS Profile (.mobileconfig)
public final class WireGuardConfigGenerator: Sendable {
    public init() {}

    /// Sinh cấu hình WireGuard chuẩn .conf theo vùng quốc gia và chế độ tăng tốc BBR
    public func generateWireGuardConfig(profile: VPNProfile) -> String {
        let dnsString = profile.dnsServers.joined(separator: ", ")
        let keepalive = profile.speedProfile.effectiveKeepalive

        let modeComment: String
        switch profile.speedProfile {
        case .turboBBR:
            modeComment = "# Chế độ: Turbo Băng Thông Tối Đa (BBR + MTU \(profile.mtu) + UDP \(profile.serverPort) Zero-Junk)"
        case .balanced:
            modeComment = "# Chế độ: Cân Bằng Đa Mạng (MTU \(profile.mtu) + Roaming 4G/5G)"
        case .antiDPI:
            modeComment = "# Chế độ: Xuyên Tường Lửa Chống DPI (AmneziaWG Jc=4, Jmin=40, Jmax=70)"
        }

        var config = """
        [Interface]
        # CleanBull Unified VPN — Vùng: \(profile.region.countryNameVi) (\(profile.region.cityVi))
        \(modeComment)
        PrivateKey = \(profile.privateKey)
        Address = \(profile.assignedIPv4)/32
        """

        if let v6 = profile.assignedIPv6, !v6.isEmpty {
            config += ", \(v6)/128"
        }

        config += "\nDNS = \(dnsString)"
        config += "\nMTU = \(profile.mtu)\n"

        config += """

        [Peer]
        PublicKey = \(profile.peerPublicKey)
        Endpoint = \(profile.serverAddress):\(profile.serverPort)
        AllowedIPs = 0.0.0.0/0, ::/0
        """

        if let psk = profile.presharedKey, !psk.isEmpty {
            config += "\nPresharedKey = \(psk)"
        }

        config += "\nPersistentKeepalive = \(keepalive)\n"
        return config
    }

    /// Sinh cấu hình AmneziaWG .conf kèm tham số xáo trộn DPI và thông tin vùng lãnh thổ
    public func generateAmneziaWGConfig(profile: VPNProfile) -> String {
        let params = profile.amneziaParams ?? AmneziaParams()
        let dnsString = profile.dnsServers.joined(separator: ", ")
        let keepalive = profile.speedProfile.effectiveKeepalive

        var config = """
        [Interface]
        # CleanBull AmneziaWG — Vùng: \(profile.region.countryNameVi) (\(profile.region.cityVi))
        PrivateKey = \(profile.privateKey)
        Address = \(profile.assignedIPv4)/32
        """

        if let v6 = profile.assignedIPv6, !v6.isEmpty {
            config += ", \(v6)/128"
        }

        config += "\nDNS = \(dnsString)"
        config += "\nMTU = \(profile.mtu)"
        config += "\nJc = \(params.jc)"
        config += "\nJmin = \(params.jmin)"
        config += "\nJmax = \(params.jmax)"
        config += "\nS1 = \(params.s1)"
        config += "\nS2 = \(params.s2)"
        config += "\nH1 = \(params.h1)"
        config += "\nH2 = \(params.h2)"
        config += "\nH3 = \(params.h3)"
        config += "\nH4 = \(params.h4)\n"

        config += """

        [Peer]
        PublicKey = \(profile.peerPublicKey)
        Endpoint = \(profile.serverAddress):\(profile.serverPort)
        AllowedIPs = 0.0.0.0/0, ::/0
        """

        if let psk = profile.presharedKey, !psk.isEmpty {
            config += "\nPresharedKey = \(psk)"
        }

        config += "\nPersistentKeepalive = \(keepalive)\n"
        return config
    }

    /// Sinh cấu hình Sing-box JSON v1.8+ theo vùng quốc gia
    public func generateSingBoxConfig(profile: VPNProfile) -> String {
        let isAmnezia = profile.amneziaParams != nil
        let params = profile.amneziaParams ?? AmneziaParams()

        var endpointDict: [String: Any] = [
            "type": isAmnezia ? "amneziawg" : "wireguard",
            "tag": "cleanbull-out-\(profile.region.code.lowercased())",
            "server": profile.serverAddress,
            "server_port": profile.serverPort,
            "mtu": profile.mtu,
            "local_address": [
                "\(profile.assignedIPv4)/32"
            ],
            "private_key": profile.privateKey,
            "peer_public_key": profile.peerPublicKey,
            "reserved": profile.reservedBytes ?? [0, 0, 0]
        ]

        if isAmnezia {
            endpointDict["jc"] = params.jc
            endpointDict["jmin"] = params.jmin
            endpointDict["jmax"] = params.jmax
            endpointDict["s1"] = params.s1
            endpointDict["s2"] = params.s2
            endpointDict["h1"] = params.h1
            endpointDict["h2"] = params.h2
            endpointDict["h3"] = params.h3
            endpointDict["h4"] = params.h4
        }

        let fullConfig: [String: Any] = [
            "log": [
                "level": "warn",
                "timestamp": true
            ],
            "dns": [
                "servers": [
                    [
                        "tag": "dns-remote",
                        "address": profile.dnsServers.first ?? "1.1.1.1",
                        "detour": "cleanbull-out-\(profile.region.code.lowercased())"
                    ]
                ]
            ],
            "inbounds": [
                [
                    "type": "tun",
                    "tag": "tun-in",
                    "interface_name": "utun88",
                    "inet4_address": "172.19.0.1/30",
                    "auto_route": true,
                    "strict_route": true,
                    "stack": "system",
                    "sniff": true
                ]
            ],
            "outbounds": [
                endpointDict,
                [
                    "type": "direct",
                    "tag": "direct-out"
                ],
                [
                    "type": "block",
                    "tag": "block-out"
                ]
            ]
        ]

        if let jsonData = try? JSONSerialization.data(withJSONObject: fullConfig, options: [.prettyPrinted, .sortedKeys]),
           let jsonString = String(data: jsonData, encoding: .utf8) {
            return jsonString
        }

        return "{}"
    }

    /// Sinh cấu hình Apple Configuration Profile (.mobileconfig) cho macOS / iPadOS
    public func generateDnsShieldMobileConfig(region: VPNRegion) -> String {
        return """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
          <key>PayloadContent</key>
          <array>
            <dict>
              <key>DNSSettings</key>
              <dict>
                <key>DNSProtocol</key>
                <string>HTTPS</string>
                <key>ServerURL</key>
                <string>https://dns.adguard-dns.com/dns-query</string>
                <key>ServerAddresses</key>
                <array>
                  <string>\(region.dnsServers.first ?? "1.1.1.1")</string>
                  <string>\(region.dnsServers.last ?? "1.0.0.1")</string>
                </array>
              </dict>
              <key>PayloadDescription</key>
              <string>Khiên Chặn Quảng Cáo &amp; Tracker DNS-over-HTTPS CleanBull (\(region.countryNameVi))</string>
              <key>PayloadDisplayName</key>
              <string>CleanBull DNS Shield — \(region.countryNameVi)</string>
              <key>PayloadIdentifier</key>
              <string>com.cleanbull.dnsshield.\(region.code.lowercased()).payload</string>
              <key>PayloadType</key>
              <string>com.apple.dnsSettings.managed</string>
              <key>PayloadUUID</key>
              <string>8A9B2C3D-4E5F-4A1B-9C8D-7E6F5A4B3C2D</string>
              <key>PayloadVersion</key>
              <integer>1</integer>
            </dict>
          </array>
          <key>PayloadDescription</key>
          <string>Hồ sơ Khiên Chống Theo Dõi &amp; Quảng Cáo Cấp Hệ Thống cho macOS &amp; iPadOS (Vùng: \(region.countryNameVi))</string>
          <key>PayloadDisplayName</key>
          <string>CleanBull DNS Shield (\(region.code))</string>
          <key>PayloadIdentifier</key>
          <string>com.cleanbull.dnsshield.\(region.code.lowercased())</string>
          <key>PayloadOrganization</key>
          <string>CleanBull Security</string>
          <key>PayloadRemovalDisallowed</key>
          <false/>
          <key>PayloadType</key>
          <string>Configuration</string>
          <key>PayloadUUID</key>
          <string>1F2E3D4C-5B6A-4987-8F9E-0D1C2B3A4F5E</string>
          <key>PayloadVersion</key>
          <integer>1</integer>
        </dict>
        </plist>
        """
    }
}
