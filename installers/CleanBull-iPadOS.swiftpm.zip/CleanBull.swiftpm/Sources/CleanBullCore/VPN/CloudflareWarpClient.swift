import Foundation
import CryptoKit

/// Lỗi trong quá trình tạo khóa và đăng ký Cloudflare WARP
public enum WarpClientError: LocalizedError, Sendable, Equatable {
    case networkError(String)
    case invalidServerResponse
    case registrationFailed(String)

    public var errorDescription: String? {
        switch self {
        case .networkError(let msg): return "Lỗi mạng khi kết nối Cloudflare WARP API: \(msg)"
        case .invalidServerResponse: return "Phản hồi từ máy chủ Cloudflare không hợp lệ."
        case .registrationFailed(let msg): return "Đăng ký tài khoản WARP thất bại: \(msg)"
        }
    }
}

/// Trình tạo khóa Curve25519 bằng CryptoKit và đăng ký cấu hình Cloudflare WARP
public final class CloudflareWarpClient: Sendable {
    public init() {}

    /// Sinh cặp khóa Curve25519 (X25519) thực tế chuẩn 32 byte Base64
    public func generateKeyPair() -> (privateKey: String, publicKey: String) {
        let privateKey = Curve25519.KeyAgreement.PrivateKey()
        let privBase64 = privateKey.rawRepresentation.base64EncodedString()
        let pubBase64 = privateKey.publicKey.rawRepresentation.base64EncodedString()
        return (privBase64, pubBase64)
    }

    /// Đăng ký tài khoản Cloudflare WARP qua Live API
    public func registerWarpAccount() async throws -> VPNProfile {
        let (privKey, pubKey) = generateKeyPair()

        guard let regURL = URL(string: "https://api.cloudflareclient.com/v0a3371/reg") else {
            throw WarpClientError.networkError("URL đăng ký không hợp lệ")
        }

        var request = URLRequest(url: regURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("okhttp/3.12.1", forHTTPHeaderField: "User-Agent")

        let payload: [String: Any] = [
            "key": pubKey,
            "install_id": "",
            "fcm_token": "",
            "tos": ISO8601DateFormatter().string(from: Date()),
            "model": "iPadOS Native",
            "serial_number": "",
            "locale": "vi_VN"
        ]

        let httpBody: Data
        do {
            httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            throw WarpClientError.registrationFailed("Không thể mã hóa payload")
        }
        request.httpBody = httpBody

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw WarpClientError.networkError(error.localizedDescription)
        }

        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            let errorText = String(data: data, encoding: .utf8) ?? "Mã lỗi không xác định"
            throw WarpClientError.registrationFailed(errorText)
        }

        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let result = json["result"] as? [String: Any] else {
            throw WarpClientError.invalidServerResponse
        }

        var assignedIPv4 = "172.16.0.2"
        var assignedIPv6: String? = nil
        var peerPubKey = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="
        var endpointHost = "162.159.192.1"
        var endpointPort = 2408

        if let config = result["config"] as? [String: Any] {
            if let interface = config["interface"] as? [String: Any],
               let addresses = interface["addresses"] as? [String: Any] {
                if let v4 = addresses["v4"] as? String { assignedIPv4 = v4 }
                if let v6 = addresses["v6"] as? String { assignedIPv6 = v6 }
            }

            if let peers = config["peers"] as? [[String: Any]], let firstPeer = peers.first {
                if let pk = firstPeer["public_key"] as? String { peerPubKey = pk }
                if let endpoint = firstPeer["endpoint"] as? [String: Any] {
                    if let host = endpoint["host"] as? String { endpointHost = host }
                    if let port = endpoint["port"] as? Int { endpointPort = port }
                }
            }
        }

        let amnezia = AmneziaParams(
            jc: 4,
            jmin: 40,
            jmax: 70,
            s1: 15,
            s2: 30,
            h1: 1,
            h2: 2,
            h3: 3,
            h4: 4
        )

        return VPNProfile(
            name: "Cloudflare WARP (Auto-Registered)",
            mode: .cloudflareWarp,
            serverAddress: endpointHost,
            serverPort: endpointPort,
            privateKey: privKey,
            publicKey: pubKey,
            peerPublicKey: peerPubKey,
            assignedIPv4: assignedIPv4,
            assignedIPv6: assignedIPv6,
            dnsServers: ["1.1.1.1", "1.0.0.1"],
            amneziaParams: amnezia,
            reservedBytes: [90, 139, 204]
        )
    }
}
