import Foundation
import CryptoKit

/// Các lỗi phát sinh trong quá trình cách ly và khôi phục dữ liệu.
public enum QuarantineError: LocalizedError, Sendable, Equatable {
    case unsafePath(path: String, reason: String)
    case fileNotFound(path: String)
    case cannotEnumerateDirectory(path: String)
    case sessionNotFound(sessionId: UUID)
    case checksumMismatch(path: String, expected: String, actual: String)
    case manifestCorrupted(reason: String)
    case permissionDenied(path: String)
    case itemAlreadyExistsAtOriginalPath(path: String)
    case systemError(String)

    public var errorDescription: String? {
        switch self {
        case .unsafePath(let path, let reason):
            return "Đường dẫn không an toàn để xử lý (\(path)): \(reason)"
        case .fileNotFound(let path):
            return "Không tìm thấy tệp tin tại đường dẫn: \(path)"
        case .cannotEnumerateDirectory(let path):
            return "Không thể duyệt thư mục: \(path)"
        case .sessionNotFound(let sessionId):
            return "Không tìm thấy phiên cách ly với ID: \(sessionId.uuidString)"
        case .checksumMismatch(let path, let expected, let actual):
            return "Sai lệch mã băm SHA-256 tại '\(path)'. Kỳ vọng: \(expected), Thực tế: \(actual)"
        case .manifestCorrupted(let reason):
            return "Tệp manifest.json bị lỗi hoặc không thể đọc: \(reason)"
        case .permissionDenied(let path):
            return "Không có quyền POSIX phù hợp để thao tác trên tệp: \(path)"
        case .itemAlreadyExistsAtOriginalPath(let path):
            return "Đã tồn tại tệp tin khác tại đường dẫn gốc: \(path)"
        case .systemError(let message):
            return "Lỗi hệ thống: \(message)"
        }
    }
}

/// Swift Actor quản lý toàn bộ chu trình Cách ly (Quarantine), Hoàn tác (Restore) và Xoá vĩnh viễn (Purge).
public actor QuarantineManager {
    /// Thư mục gốc chứa toàn bộ các phiên cách ly
    public let baseQuarantineDirectory: URL

    /// Thư mục cách ly thế hệ cũ để tương thích ngược (nếu dùng thư mục mặc định)
    public let legacyQuarantineDirectory: URL?

    /// Bộ lọc an toàn kiểm tra đường dẫn
    public let safetyFilter: SafetyFilterService

    private let fileManager = FileManager.default

    /// Khởi tạo QuarantineManager
    /// - Parameters:
    ///   - customBaseDirectory: Thư mục cách ly tuỳ chỉnh (mặc định là `~/.local/share/CleanBull/Quarantine`)
    ///   - safetyFilter: Dịch vụ kiểm tra an toàn
    public init(
        customBaseDirectory: URL? = nil,
        safetyFilter: SafetyFilterService = SafetyFilterService()
    ) {
        if let customDir = customBaseDirectory {
            self.baseQuarantineDirectory = customDir
            self.legacyQuarantineDirectory = nil
        } else {
            let home = FileManager.default.homeDirectoryForCurrentUser
            self.baseQuarantineDirectory = home
                .appendingPathComponent(".local", isDirectory: true)
                .appendingPathComponent("share", isDirectory: true)
                .appendingPathComponent("CleanBull", isDirectory: true)
                .appendingPathComponent("Quarantine", isDirectory: true)
            self.legacyQuarantineDirectory = home
                .appendingPathComponent(".local", isDirectory: true)
                .appendingPathComponent("share", isDirectory: true)
                .appendingPathComponent("CleanGiabull", isDirectory: true)
                .appendingPathComponent("Quarantine", isDirectory: true)
        }
        self.safetyFilter = safetyFilter
    }

    private func resolveExistingSessionDirectory(sessionId: UUID) -> URL? {
        let primaryDir = baseQuarantineDirectory.appendingPathComponent(sessionId.uuidString, isDirectory: true)
        if fileManager.fileExists(atPath: primaryDir.appendingPathComponent("manifest.json").path) {
            return primaryDir
        }
        if let legacyBase = legacyQuarantineDirectory {
            let legacyDir = legacyBase.appendingPathComponent(sessionId.uuidString, isDirectory: true)
            if fileManager.fileExists(atPath: legacyDir.appendingPathComponent("manifest.json").path) {
                return legacyDir
            }
        }
        return nil
    }

    // MARK: - Quản lý Phiên Cách ly (Quarantine)

    /// Đưa danh sách các mục EvidenceCardModel vào khu vực cách ly an toàn theo một phiên mới.
    public func quarantineItems(
        items: [EvidenceCardModel],
        ruleId: String = "rule_default"
    ) async throws -> QuarantineSession {
        guard !items.isEmpty else {
            throw QuarantineError.systemError("Danh sách tệp cách ly trống.")
        }

        let sessionId = UUID()
        let sessionDir = baseQuarantineDirectory.appendingPathComponent(sessionId.uuidString, isDirectory: true)
        let itemsDir = sessionDir.appendingPathComponent("items", isDirectory: true)

        // 1. Tạo các thư mục phiên cách ly
        try createDirectoryIfNeeded(at: itemsDir)

        var records: [ManifestRecord] = []
        var totalSize: Int64 = 0

        for item in items {
            let sourceURL = item.url
            let rawPath = item.path

            // 2. Thẩm định an toàn nghiêm ngặt
            let safetyCheck = safetyFilter.isSafeToProcess(url: sourceURL)
            guard safetyCheck.isSafe else {
                throw QuarantineError.unsafePath(path: rawPath, reason: safetyCheck.reason)
            }

            guard fileManager.fileExists(atPath: rawPath) else {
                throw QuarantineError.fileNotFound(path: rawPath)
            }

            // 3. Đọc thuộc tính POSIX và kích thước thực tế
            let attributes = try? fileManager.attributesOfItem(atPath: rawPath)
            let posixPermissions = (attributes?[.posixPermissions] as? NSNumber)?.uint16Value ?? 0o644
            let modDate = attributes?[.modificationDate] as? Date

            // 4. Tính toán mã băm SHA-256 của tệp/thư mục gốc trước khi di chuyển (Hash A)
            let sourceChecksum = try calculateSHA256(for: sourceURL)

            // 5. Chuẩn bị đích đến trong kho cách ly
            let destinationFileName = "\(item.id.uuidString)_\(sourceURL.lastPathComponent)"
            let destinationURL = itemsDir.appendingPathComponent(destinationFileName)

            // 6. Thực hiện di chuyển tệp an toàn (Atomic Move)
            try fileManager.moveItem(at: sourceURL, to: destinationURL)

            // 7. Kiểm tra mã băm SHA-256 tại vị trí cách ly mới để khẳng định di chuyển nguyên vẹn
            let quarantinedChecksum = try calculateSHA256(for: destinationURL)
            guard sourceChecksum == quarantinedChecksum else {
                // Phục hồi lại nếu sai lệch
                try? fileManager.moveItem(at: destinationURL, to: sourceURL)
                throw QuarantineError.checksumMismatch(
                    path: destinationURL.path,
                    expected: sourceChecksum,
                    actual: quarantinedChecksum
                )
            }

            totalSize += item.fileSize

            let record = ManifestRecord(
                id: item.id,
                originalPath: rawPath,
                quarantinePath: destinationFileName,
                sha256Checksum: sourceChecksum,
                posixPermissions: posixPermissions,
                dateQuarantined: Date(),
                ruleId: ruleId,
                fileSize: item.fileSize,
                fileType: item.fileType,
                originalModificationDate: modDate
            )
            records.append(record)
        }

        // 8. Ghi file manifest.json nếu có ít nhất 1 bản ghi thành công
        guard !records.isEmpty else {
            throw QuarantineError.systemError("Không có tệp nào được chuyển vào cách ly thành công.")
        }

        let session = QuarantineSession(
            id: sessionId,
            dateCreated: Date(),
            records: records,
            totalSize: totalSize,
            status: .quarantined
        )

        try saveManifest(session: session, at: sessionDir)
        return session
    }

    /// Xóa vĩnh viễn danh sách tệp trực tiếp khỏi ổ đĩa (luôn kiểm tra nghiêm ngặt Safety Filter)
    public func permanentlyDeleteItems(items: [EvidenceCardModel]) async throws -> (deletedCount: Int, freedBytes: Int64, errors: [String]) {
        guard !items.isEmpty else {
            return (0, 0, [])
        }

        var deletedCount = 0
        var freedBytes: Int64 = 0
        var errors: [String] = []

        for item in items {
            let sourceURL = item.url
            let rawPath = item.path

            let safetyCheck = safetyFilter.isSafeToProcess(url: sourceURL)
            guard safetyCheck.isSafe else {
                errors.append("Bảo vệ an toàn: Không thể xoá '\(item.fileName)' (\(safetyCheck.reason))")
                continue
            }

            guard fileManager.fileExists(atPath: rawPath) else {
                deletedCount += 1
                freedBytes += item.fileSize
                continue
            }

            do {
                try fileManager.removeItem(at: sourceURL)
                deletedCount += 1
                freedBytes += item.fileSize
            } catch {
                errors.append("Lỗi xoá '\(item.fileName)': \(error.localizedDescription)")
            }
        }

        return (deletedCount, freedBytes, errors)
    }

    // MARK: - Hoàn tác Phiên (Session Restore)

    /// Hoàn tác một phiên cách ly, trả toàn bộ tệp về vị trí ban đầu và đối soát SHA-256 100% (Hash A == Hash B).
    public func restoreSession(sessionId: UUID) async throws -> RestoreResult {
        guard let sessionDir = resolveExistingSessionDirectory(sessionId: sessionId) else {
            throw QuarantineError.sessionNotFound(sessionId: sessionId)
        }
        let manifestURL = sessionDir.appendingPathComponent("manifest.json")

        guard fileManager.fileExists(atPath: manifestURL.path) else {
            throw QuarantineError.sessionNotFound(sessionId: sessionId)
        }

        var session = try loadManifest(from: manifestURL)
        let itemsDir = sessionDir.appendingPathComponent("items", isDirectory: true)

        var restoredRecords: [ManifestRecord] = []
        var failedRecords: [RestoreFailure] = []

        for record in session.records {
            let quarantineFileURL = itemsDir.appendingPathComponent(record.quarantinePath)
            let originalURL = URL(fileURLWithPath: record.originalPath)

            // 1. Kiểm tra sự tồn tại trong vùng cách ly
            guard fileManager.fileExists(atPath: quarantineFileURL.path) else {
                failedRecords.append(RestoreFailure(
                    record: record,
                    errorMessage: "Không tìm thấy tệp trong thư mục cách ly: \(quarantineFileURL.path)"
                ))
                continue
            }

            // 2. Thẩm định mã băm SHA-256 trước khi hoàn tác để tránh tệp bị can thiệp
            let preRestoreChecksum: String
            do {
                preRestoreChecksum = try calculateSHA256(for: quarantineFileURL)
            } catch {
                failedRecords.append(RestoreFailure(
                    record: record,
                    errorMessage: "Không thể tính SHA-256 trước khi khôi phục: \(error.localizedDescription)"
                ))
                continue
            }

            guard preRestoreChecksum == record.sha256Checksum else {
                failedRecords.append(RestoreFailure(
                    record: record,
                    errorMessage: "Mã SHA-256 trong vùng cách ly không khớp với manifest (Đã bị can thiệp trái phép)."
                ))
                continue
            }

            // 3. Tái tạo thư mục cha ban đầu nếu đã bị xoá
            let originalParentDir = originalURL.deletingLastPathComponent()
            do {
                try createDirectoryIfNeeded(at: originalParentDir)
            } catch {
                failedRecords.append(RestoreFailure(
                    record: record,
                    errorMessage: "Không thể tạo lại thư mục cha '\(originalParentDir.path)': \(error.localizedDescription)"
                ))
                continue
            }

            // 4. Kiểm tra xem đường dẫn gốc đã có tệp nào khác trùng tên chưa (Tránh ghi đè tệp mới)
            if fileManager.fileExists(atPath: originalURL.path) {
                let backupURL = originalParentDir.appendingPathComponent(
                    "\(originalURL.deletingPathExtension().lastPathComponent)_conflict_\(UUID().uuidString.prefix(6)).\(originalURL.pathExtension)"
                )
                try? fileManager.moveItem(at: originalURL, to: backupURL)
            }

            // 5. Di chuyển tệp về lại đường dẫn ban đầu
            do {
                try fileManager.moveItem(at: quarantineFileURL, to: originalURL)
            } catch {
                failedRecords.append(RestoreFailure(
                    record: record,
                    errorMessage: "Lỗi di chuyển tệp về vị trí gốc: \(error.localizedDescription)"
                ))
                continue
            }

            // 6. Khôi phục quyền POSIX và thời gian sửa đổi gốc
            var restoreAttrs: [FileAttributeKey: Any] = [
                .posixPermissions: NSNumber(value: record.posixPermissions)
            ]
            if let origModDate = record.originalModificationDate {
                restoreAttrs[.modificationDate] = origModDate
            }
            try? fileManager.setAttributes(restoreAttrs, ofItemAtPath: originalURL.path)

            // 7. Thẩm định mã băm SHA-256 sau khi đã hoàn tác về vị trí gốc (Đối soát toàn vẹn 100%: Hash A == Hash B)
            do {
                let postRestoreChecksum = try calculateSHA256(for: originalURL)
                guard postRestoreChecksum == record.sha256Checksum else {
                    failedRecords.append(RestoreFailure(
                        record: record,
                        errorMessage: "Mã SHA-256 sau khi khôi phục sai lệch với dữ liệu gốc."
                    ))
                    continue
                }
            } catch {
                failedRecords.append(RestoreFailure(
                    record: record,
                    errorMessage: "Không thể xác thực mã SHA-256 sau khi hoàn tác: \(error.localizedDescription)"
                ))
                continue
            }

            restoredRecords.append(record)
        }

        let result = RestoreResult(
            sessionId: sessionId,
            restoredRecords: restoredRecords,
            failedRecords: failedRecords
        )

        // Cập nhật trạng thái manifest
        if result.isFullyRestored {
            session.status = .restored
            try? fileManager.removeItem(at: sessionDir)
        } else {
            session.status = .partiallyRestored
            try? saveManifest(session: session, at: sessionDir)
        }

        return result
    }

    // MARK: - Xoá vĩnh viễn Phiên (Purge)

    /// Xoá vĩnh viễn toàn bộ dữ liệu của một phiên cách ly.
    public func purgeSessionPermanently(sessionId: UUID) async throws {
        if let resolved = resolveExistingSessionDirectory(sessionId: sessionId) {
            try fileManager.removeItem(at: resolved)
            return
        }
        let sessionDir = baseQuarantineDirectory.appendingPathComponent(sessionId.uuidString, isDirectory: true)
        guard fileManager.fileExists(atPath: sessionDir.path) else {
            throw QuarantineError.sessionNotFound(sessionId: sessionId)
        }
        try fileManager.removeItem(at: sessionDir)
    }

    // MARK: - Danh sách & Truy vấn Phiên

    public func listSessions() async throws -> [QuarantineSession] {
        var rootDirs: [URL] = [baseQuarantineDirectory]
        if let legacy = legacyQuarantineDirectory {
            rootDirs.append(legacy)
        }

        var sessionsById: [UUID: QuarantineSession] = [:]
        for root in rootDirs {
            guard fileManager.fileExists(atPath: root.path) else { continue }
            let subdirs = (try? fileManager.contentsOfDirectory(
                at: root,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles]
            )) ?? []

            for dir in subdirs {
                let manifestURL = dir.appendingPathComponent("manifest.json")
                if fileManager.fileExists(atPath: manifestURL.path),
                   let session = try? loadManifest(from: manifestURL) {
                    sessionsById[session.id] = session
                }
            }
        }

        return Array(sessionsById.values).sorted { $0.dateCreated > $1.dateCreated }
    }

    public func getSession(sessionId: UUID) async throws -> QuarantineSession? {
        guard let sessionDir = resolveExistingSessionDirectory(sessionId: sessionId) else {
            return nil
        }
        let manifestURL = sessionDir.appendingPathComponent("manifest.json")
        guard fileManager.fileExists(atPath: manifestURL.path) else {
            return nil
        }
        return try? loadManifest(from: manifestURL)
    }

    // MARK: - Tính toán SHA-256 (Apple CryptoKit Streaming 64KB)

    /// Tính mã băm SHA-256 bằng Apple CryptoKit theo từng khối nhớ 64KB, chống tràn RAM đối với tệp lớn.
    public func calculateSHA256(for url: URL) throws -> String {
        var isDir: ObjCBool = false
        guard fileManager.fileExists(atPath: url.path, isDirectory: &isDir) else {
            throw QuarantineError.fileNotFound(path: url.path)
        }

        if isDir.boolValue {
            return try calculateDirectorySHA256(for: url)
        }

        let fileHandle = try FileHandle(forReadingFrom: url)
        defer {
            try? fileHandle.close()
        }

        var hasher = SHA256()
        let bufferSize = 64 * 1024 // 64 KB

        while autoreleasepool(invoking: {
            let data = fileHandle.readData(ofLength: bufferSize)
            if data.isEmpty {
                return false
            }
            hasher.update(data: data)
            return true
        }) {}

        let digest = hasher.finalize()
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }

    private func calculateDirectorySHA256(for dirURL: URL) throws -> String {
        let resolvedDirURL = dirURL.resolvingSymlinksInPath()
        let standardizedDirPath = (resolvedDirURL.path as NSString).standardizingPath

        let keys: [URLResourceKey] = [.isRegularFileKey, .nameKey]
        guard let enumerator = fileManager.enumerator(
            at: resolvedDirURL,
            includingPropertiesForKeys: keys,
            options: []
        ) else {
            throw QuarantineError.cannotEnumerateDirectory(path: dirURL.path)
        }

        var hasher = SHA256()
        var fileURLs: [URL] = []

        for case let fileURL as URL in enumerator {
            let resourceValues = try? fileURL.resourceValues(forKeys: Set(keys))
            if resourceValues?.isRegularFile == true {
                fileURLs.append(fileURL)
            }
        }

        fileURLs.sort { $0.path < $1.path }

        for fileURL in fileURLs {
            let resolvedFileURL = fileURL.resolvingSymlinksInPath()
            let standardizedFilePath = (resolvedFileURL.path as NSString).standardizingPath

            let relativePath: String
            if standardizedFilePath.hasPrefix(standardizedDirPath) {
                relativePath = String(standardizedFilePath.dropFirst(standardizedDirPath.count))
            } else {
                relativePath = resolvedFileURL.lastPathComponent
            }

            if let relData = relativePath.data(using: .utf8) {
                hasher.update(data: relData)
            }
            let fileHandle = try FileHandle(forReadingFrom: resolvedFileURL)
            let bufferSize = 64 * 1024
            while autoreleasepool(invoking: {
                let data = fileHandle.readData(ofLength: bufferSize)
                if data.isEmpty { return false }
                hasher.update(data: data)
                return true
            }) {}
            try? fileHandle.close()
        }

        let digest = hasher.finalize()
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }

    // MARK: - Trợ giúp Nội bộ (Helpers)

    private func createDirectoryIfNeeded(at url: URL) throws {
        if !fileManager.fileExists(atPath: url.path) {
            try fileManager.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
        }
    }

    private func saveManifest(session: QuarantineSession, at sessionDir: URL) throws {
        let manifestURL = sessionDir.appendingPathComponent("manifest.json")
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(session)
        try data.write(to: manifestURL, options: .atomic)
    }

    private func loadManifest(from url: URL) throws -> QuarantineSession {
        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        do {
            return try decoder.decode(QuarantineSession.self, from: data)
        } catch {
            throw QuarantineError.manifestCorrupted(reason: error.localizedDescription)
        }
    }
}
