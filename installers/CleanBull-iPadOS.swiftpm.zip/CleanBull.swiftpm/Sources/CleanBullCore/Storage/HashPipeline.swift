import Foundation
import CryptoKit

/// Nhóm tệp tin trùng lặp phát hiện được qua thuật toán băm 3 tầng
public struct DuplicateFileGroup: Identifiable, Sendable, Equatable {
    public var id: String { sha256 }
    public let masterFile: URL
    public let duplicateFiles: [URL]
    public let fileSize: Int64
    public let sha256: String

    public init(
        masterFile: URL,
        duplicateFiles: [URL],
        fileSize: Int64,
        sha256: String
    ) {
        self.masterFile = masterFile
        self.duplicateFiles = duplicateFiles
        self.fileSize = fileSize
        self.sha256 = sha256
    }

    /// Dung lượng lãng phí do các bản trùng lặp chiếm dụng
    public var wastedBytes: Int64 {
        fileSize * Int64(duplicateFiles.count)
    }

    public var formattedWastedSize: String {
        ByteCountFormatter.string(fromByteCount: wastedBytes, countStyle: .file)
    }
}

/// Pipeline Băm Tệp Trùng Lặp 3 Tầng (Size -> 4KB Pre-hash -> Full SHA-256)
public final class HashPipeline: Sendable {
    public init() {}

    /// Thực thi tìm kiếm tệp trùng lặp từ danh sách ứng viên
    public func findDuplicates(candidateURLs: [URL]) throws -> [DuplicateFileGroup] {
        let fileManager = FileManager.default

        // MARK: - Tầng 1: Lọc theo kích thước byte chính xác (O(1) File Size Grouping)
        // Giới hạn băm tối đa 400 ứng viên và bỏ qua các tệp quá 100MB để không gây nghẽn ổ cứng SSD
        let maxHashFileSize: Int64 = 100 * 1024 * 1024
        var sizeGroups: [Int64: [URL]] = [:]

        for url in candidateURLs.prefix(400) {
            var isDir: ObjCBool = false
            guard fileManager.fileExists(atPath: url.path, isDirectory: &isDir), !isDir.boolValue else {
                continue
            }
            guard let attrs = try? fileManager.attributesOfItem(atPath: url.path),
                  let size = (attrs[.size] as? NSNumber)?.int64Value,
                  size > 0,
                  size <= maxHashFileSize else {
                continue
            }
            sizeGroups[size, default: []].append(url)
        }

        // Chỉ giữ các nhóm có từ 2 tệp trở lên cùng kích thước
        let candidateSizeGroups = sizeGroups.filter { $0.value.count >= 2 }
        if candidateSizeGroups.isEmpty {
            return []
        }

        // MARK: - Tầng 2: Băm tiền tố 4KB (4KB Pre-Hash)
        var preHashGroups: [String: [URL]] = [:]
        let preHashBufferSize = 4096 // 4 KB

        for (size, urls) in candidateSizeGroups {
            for url in urls {
                guard let handle = try? FileHandle(forReadingFrom: url) else { continue }
                let preData = handle.readData(ofLength: preHashBufferSize)
                try? handle.close()

                let preDigest = SHA256.hash(data: preData)
                let preHashStr = "\(size)_" + preDigest.map { String(format: "%02hhx", $0) }.joined()
                preHashGroups[preHashStr, default: []].append(url)
            }
        }

        // Chỉ giữ các nhóm có từ 2 tệp trở lên trùng cả Size và 4KB đầu
        let candidatePreHashGroups = preHashGroups.filter { $0.value.count >= 2 }
        if candidatePreHashGroups.isEmpty {
            return []
        }

        // MARK: - Tầng 3: Băm toàn phần Streaming SHA-256 (64KB Chunks)
        var fullHashGroups: [String: (size: Int64, urls: [URL])] = [:]
        var fullHashedCount = 0

        for (_, urls) in candidatePreHashGroups {
            for url in urls {
                fullHashedCount += 1
                if fullHashedCount > 80 { break }
                guard let fullSHA256 = try? calculateStreamingSHA256(for: url) else { continue }
                let attrs = try? fileManager.attributesOfItem(atPath: url.path)
                let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0

                if var existing = fullHashGroups[fullSHA256] {
                    existing.urls.append(url)
                    fullHashGroups[fullSHA256] = existing
                } else {
                    fullHashGroups[fullSHA256] = (size, [url])
                }
            }
        }

        var results: [DuplicateFileGroup] = []

        for (hash, data) in fullHashGroups where data.urls.count >= 2 {
            // Sắp xếp theo ngày tạo hoặc đường dẫn để chọn master ổn định
            let sortedURLs = data.urls.sorted { u1, u2 in
                let d1 = (try? fileManager.attributesOfItem(atPath: u1.path)[.creationDate] as? Date) ?? Date.distantPast
                let d2 = (try? fileManager.attributesOfItem(atPath: u2.path)[.creationDate] as? Date) ?? Date.distantPast
                if d1 == d2 {
                    return u1.path < u2.path
                }
                return d1 < d2
            }

            let master = sortedURLs[0]
            let duplicates = Array(sortedURLs.dropFirst())

            results.append(DuplicateFileGroup(
                masterFile: master,
                duplicateFiles: duplicates,
                fileSize: data.size,
                sha256: hash
            ))
        }

        return results.sorted { $0.wastedBytes > $1.wastedBytes }
    }

    /// Tính mã SHA-256 toàn phần theo luồng 64KB
    public func calculateStreamingSHA256(for url: URL) throws -> String {
        let fileHandle = try FileHandle(forReadingFrom: url)
        defer {
            try? fileHandle.close()
        }

        var hasher = SHA256()
        let bufferSize = 64 * 1024

        while autoreleasepool(invoking: {
            let data = fileHandle.readData(ofLength: bufferSize)
            if data.isEmpty { return false }
            hasher.update(data: data)
            return true
        }) {}

        let digest = hasher.finalize()
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }
}
