import Foundation

/// Phân loại danh mục quét dọn trong CleanBull.
public enum CleanerCategory: String, Codable, Sendable, CaseIterable, Identifiable {
    case all = "all"
    case appCaches = "app_caches"
    case appLogs = "app_logs"
    case oldDownloads = "old_downloads"
    case largeFiles = "large_files"

    public var id: String { rawValue }

    public var localizedTitle: String {
        switch self {
        case .all:
            return "Tất cả"
        case .appCaches:
            return "Bộ nhớ đệm (Caches)"
        case .appLogs:
            return "Nhật ký ứng dụng (Logs)"
        case .oldDownloads:
            return "Tệp tải về cũ (>60 ngày)"
        case .largeFiles:
            return "Tệp dung lượng lớn (>100MB/500MB)"
        }
    }

    public var iconName: String {
        switch self {
        case .all: return "tray.full"
        case .appCaches: return "internaldrive"
        case .appLogs: return "doc.plaintext"
        case .oldDownloads: return "arrow.down.circle"
        case .largeFiles: return "scalemass"
        }
    }
}

/// Bộ quy tắc nhận diện và đánh giá ngữ cảnh cho từng tệp tin/thư mục cần xem xét.
public struct RuleEngine: Sendable {
    public let safetyFilter: SafetyFilterService
    public let homeDirectory: URL
    public let oldDownloadThresholdDays: Int
    public let largeFileThresholdBytes: Int64

    public init(
        safetyFilter: SafetyFilterService? = nil,
        homeDirectory: URL = FileManager.default.homeDirectoryForCurrentUser,
        oldDownloadThresholdDays: Int = 60,
        largeFileThresholdBytes: Int64 = 100 * 1024 * 1024 // 100 MB
    ) {
        let filter = safetyFilter ?? SafetyFilterService(homeDirectory: homeDirectory)
        self.safetyFilter = filter
        self.homeDirectory = homeDirectory
        self.oldDownloadThresholdDays = oldDownloadThresholdDays
        self.largeFileThresholdBytes = largeFileThresholdBytes
    }

    /// Đánh giá một mục thô `ScannedRawItem`, nếu phù hợp quy tắc và an toàn sẽ trả về `EvidenceCardModel`.
    public func evaluate(rawItem: ScannedRawItem) -> EvidenceCardModel? {
        let url = rawItem.url

        // 1. Thẩm định qua Safety Filter trước tiên
        let safetyCheck = safetyFilter.isSafeToProcess(url: url)
        guard safetyCheck.isSafe else {
            return nil
        }

        let homePath = (homeDirectory.path as NSString).standardizingPath
        let standardizedPath = (url.path as NSString).standardizingPath

        let cachesRoot = (homePath as NSString).appendingPathComponent("Library/Caches")
        let logsRoot = (homePath as NSString).appendingPathComponent("Library/Logs")
        let downloadsRoot = (homePath as NSString).appendingPathComponent("Downloads")

        // A. Quy tắc: App Caches (mục con bên trong ~/Library/Caches)
        if standardizedPath.hasPrefix(cachesRoot + "/") && standardizedPath != cachesRoot {
            return makeAppCacheCard(from: rawItem, cachesRoot: cachesRoot)
        }

        // B. Quy tắc: App Logs (mục con bên trong ~/Library/Logs)
        if standardizedPath.hasPrefix(logsRoot + "/") && standardizedPath != logsRoot {
            return makeAppLogCard(from: rawItem, logsRoot: logsRoot)
        }

        // C. Quy tắc: Downloads cũ (> 60 ngày không dùng)
        if standardizedPath.hasPrefix(downloadsRoot + "/") && standardizedPath != downloadsRoot {
            if let card = makeOldDownloadCard(from: rawItem) {
                return card
            }
        }

        // D. Quy tắc: Tệp Lớn (> 100MB / 500MB)
        if rawItem.fileSize >= largeFileThresholdBytes {
            return makeLargeFileCard(from: rawItem)
        }

        return nil
    }

    /// Đánh giá hàng loạt danh sách các mục thô với độ phức tạp O(N log N), tự động loại trừ các tệp con nếu thư mục cha đã được chọn.
    public func evaluateAll(rawItems: [ScannedRawItem]) -> [EvidenceCardModel] {
        let cards = rawItems.compactMap { evaluate(rawItem: $0) }
        guard !cards.isEmpty else { return [] }

        let sortedCards = cards.sorted { $0.path < $1.path }
        var uniqueRoots: [EvidenceCardModel] = []
        uniqueRoots.reserveCapacity(min(sortedCards.count, 512))

        for card in sortedCards {
            if let lastRoot = uniqueRoots.last, card.path.hasPrefix(lastRoot.path + "/") {
                continue
            }
            uniqueRoots.append(card)
        }

        return uniqueRoots
    }

    // MARK: - Trình tạo Thẻ Bằng Chứng Từng Nhóm

    private func makeAppCacheCard(from item: ScannedRawItem, cachesRoot: String) -> EvidenceCardModel {
        let relativePath = item.url.path.replacingOccurrences(of: cachesRoot + "/", with: "")
        let bundleOrAppName = relativePath.components(separatedBy: "/").first ?? item.url.lastPathComponent

        let explanation = "Bộ nhớ đệm tạm thời của ứng dụng '\(bundleOrAppName)'. Dữ liệu này giúp ứng dụng khởi chạy nhanh hơn, nhưng có thể tạo lại tự động bất kỳ lúc nào."
        let impact = "Không có rủi ro mất mát dữ liệu quan trọng. Lần mở tiếp theo có thể mất một vài giây để tái tạo bộ đệm mới."

        return EvidenceCardModel(
            path: item.url.path,
            fileSize: item.fileSize,
            fileType: "App Cache",
            owner: item.owner,
            lastModifiedDate: item.lastModifiedDate,
            lastAccessedDate: item.lastAccessedDate,
            confidenceScore: 92,
            riskLevel: .low,
            explanationText: explanation,
            potentialImpactText: impact
        )
    }

    private func makeAppLogCard(from item: ScannedRawItem, logsRoot: String) -> EvidenceCardModel {
        let relativePath = item.url.path.replacingOccurrences(of: logsRoot + "/", with: "")
        let appName = relativePath.components(separatedBy: "/").first ?? item.url.lastPathComponent

        let explanation = "Nhật ký ghi lại tiến trình hoạt động và thông tin chẩn đoán lỗi của '\(appName)'. Không chứa tệp dữ liệu cá nhân hay thiết lập cấu hình của bạn."
        let impact = "Hoàn toàn an toàn khi dọn dẹp. Bạn chỉ mất đi lịch sử ghi sự kiện của các phiên làm việc đã qua."

        return EvidenceCardModel(
            path: item.url.path,
            fileSize: item.fileSize,
            fileType: "App Log",
            owner: item.owner,
            lastModifiedDate: item.lastModifiedDate,
            lastAccessedDate: item.lastAccessedDate,
            confidenceScore: 95,
            riskLevel: .low,
            explanationText: explanation,
            potentialImpactText: impact
        )
    }

    private func makeOldDownloadCard(from item: ScannedRawItem) -> EvidenceCardModel? {
        let now = Date()
        let refDate = item.lastAccessedDate < item.lastModifiedDate ? item.lastAccessedDate : item.lastModifiedDate
        let daysInactive = Calendar.current.dateComponents([.day], from: refDate, to: now).day ?? 0

        guard daysInactive >= oldDownloadThresholdDays else {
            return nil
        }

        let fileName = item.url.lastPathComponent
        let explanation = "Tệp tin '\(fileName)' trong thư mục Tải về (Downloads) đã không được mở hoặc chỉnh sửa trong suốt \(daysInactive) ngày qua."
        let impact = "Tệp tin sẽ được chuyển vào vùng Cách ly an toàn. Bạn luôn có thể hoàn tác bất kỳ lúc nào."

        return EvidenceCardModel(
            path: item.url.path,
            fileSize: item.fileSize,
            fileType: "Old Download",
            owner: item.owner,
            lastModifiedDate: item.lastModifiedDate,
            lastAccessedDate: item.lastAccessedDate,
            confidenceScore: 78,
            riskLevel: .medium,
            explanationText: explanation,
            potentialImpactText: impact
        )
    }

    private func makeLargeFileCard(from item: ScannedRawItem) -> EvidenceCardModel {
        let fileName = item.url.lastPathComponent
        let sizeString = ByteCountFormatter.string(fromByteCount: item.fileSize, countStyle: .file)

        let explanation = "Tệp tin '\(fileName)' có kích thước lớn (\(sizeString)), chiếm dụng nhiều dung lượng trên ổ đĩa."
        let impact = "Dọn dẹp tệp này sẽ giải phóng ngay lập tức \(sizeString). Hệ thống đưa tệp vào vùng Cách ly để bạn có thể hoàn tác nếu cần."

        return EvidenceCardModel(
            path: item.url.path,
            fileSize: item.fileSize,
            fileType: "Large File",
            owner: item.owner,
            lastModifiedDate: item.lastModifiedDate,
            lastAccessedDate: item.lastAccessedDate,
            confidenceScore: 70,
            riskLevel: .medium,
            explanationText: explanation,
            potentialImpactText: impact
        )
    }
}
