import Foundation

/// Dịch vụ tìm kiếm tệp liên đới (Leftovers) và rác còn sót của ứng dụng (Corpse Files)
/// Có bộ nhớ đệm In-Memory chống quét lặp gây nghẽn ổ đĩa khi chuyển tab.
public struct AppLeftoverFinder: Sendable {
    public let homeDirectory: URL
    public let safetyFilter: SafetyFilterService
    private var fileManager: FileManager { FileManager.default }

    private static let cacheLock = NSLock()
    private nonisolated(unsafe) static var leftoversCache: [String: [EvidenceCardModel]] = [:]
    private nonisolated(unsafe) static var sizeCache: [String: Int64] = [:]

    public static func clearCache() {
        cacheLock.lock()
        leftoversCache.removeAll()
        sizeCache.removeAll()
        cacheLock.unlock()
    }

    public init(
        homeDirectory: URL = FileManager.default.homeDirectoryForCurrentUser,
        safetyFilter: SafetyFilterService? = nil
    ) {
        self.homeDirectory = homeDirectory
        self.safetyFilter = safetyFilter ?? SafetyFilterService(homeDirectory: homeDirectory)
    }

    /// Tìm kiếm các thư mục liên đới của một ứng dụng cụ thể theo bundleIdentifier và appName
    public func findLeftovers(bundleIdentifier: String, appName: String) -> [EvidenceCardModel] {
        let cacheKey = "\(homeDirectory.path)|\(bundleIdentifier)|\(appName)"
        // Chỉ dùng cache khi chạy trên thư mục Home thật của người dùng (không ảnh hưởng Unit Test dùng tempDir)
        let isRealUserHome = (homeDirectory.path == FileManager.default.homeDirectoryForCurrentUser.path)
        if isRealUserHome {
            Self.cacheLock.lock()
            if let cached = Self.leftoversCache[cacheKey] {
                Self.cacheLock.unlock()
                return cached
            }
            Self.cacheLock.unlock()
        }

        let home = homeDirectory
        var candidates: [EvidenceCardModel] = []

        let searchLocations: [(url: URL, type: String)] = [
            (home.appendingPathComponent("Library/Application Support", isDirectory: true), "Application Support"),
            (home.appendingPathComponent("Library/Caches", isDirectory: true), "App Cache"),
            (home.appendingPathComponent("Library/Preferences", isDirectory: true), "Preferences"),
            (home.appendingPathComponent("Library/Saved Application State", isDirectory: true), "Saved State"),
            (home.appendingPathComponent("Library/WebKit", isDirectory: true), "WebKit Data"),
            (home.appendingPathComponent("Library/Containers", isDirectory: true), "Container Sandbox")
        ]

        for location in searchLocations {
            guard fileManager.fileExists(atPath: location.url.path) else { continue }
            guard let contents = try? fileManager.contentsOfDirectory(
                at: location.url,
                includingPropertiesForKeys: [.fileSizeKey, .totalFileSizeKey, .isDirectoryKey],
                options: [.skipsHiddenFiles]
            ) else { continue }

            for itemURL in contents.prefix(250) {
                let name = itemURL.lastPathComponent
                var isExactMatch = false
                var isNameMatch = false

                if name.localizedCaseInsensitiveContains(bundleIdentifier) {
                    isExactMatch = true
                } else if !appName.isEmpty && appName.count >= 3 && name.localizedCaseInsensitiveContains(appName) {
                    isNameMatch = true
                }

                guard isExactMatch || isNameMatch else { continue }

                let check = safetyFilter.isSafeToProcess(url: itemURL)
                guard check.isSafe else { continue }

                let size = calculateSize(at: itemURL, useCache: isRealUserHome)
                let score = isExactMatch ? 98 : 65
                let risk: RiskLevel = isExactMatch ? .low : .medium

                let explanation = isExactMatch
                    ? "Dữ liệu liên kết trực tiếp với mã định danh '\(bundleIdentifier)' tại \(location.type)."
                    : "Thư mục có tên liên quan đến '\(appName)' tại \(location.type)."

                let impact = "Tệp sẽ được di chuyển an toàn vào Kho Cách Ly SHA-256. Có thể hoàn tác về vị trí gốc."

                candidates.append(EvidenceCardModel(
                    path: itemURL.path,
                    fileSize: size,
                    fileType: "App Leftover: \(location.type)",
                    owner: ProcessInfo.processInfo.environment["USER"] ?? "User",
                    lastModifiedDate: Date(),
                    lastAccessedDate: Date(),
                    confidenceScore: score,
                    riskLevel: risk,
                    explanationText: explanation,
                    potentialImpactText: impact
                ))
            }
        }

        if isRealUserHome {
            Self.cacheLock.lock()
            Self.leftoversCache[cacheKey] = candidates
            Self.cacheLock.unlock()
        }

        return candidates
    }

    private func calculateSize(at url: URL, useCache: Bool) -> Int64 {
        let pathKey = url.path
        if useCache {
            Self.cacheLock.lock()
            if let cached = Self.sizeCache[pathKey] {
                Self.cacheLock.unlock()
                return cached
            }
            Self.cacheLock.unlock()
        }

        var isDir: ObjCBool = false
        guard fileManager.fileExists(atPath: pathKey, isDirectory: &isDir) else { return 0 }
        if !isDir.boolValue {
            let attrs = try? fileManager.attributesOfItem(atPath: pathKey)
            let s = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            if useCache {
                Self.cacheLock.lock()
                Self.sizeCache[pathKey] = s
                Self.cacheLock.unlock()
            }
            return s
        }

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileSizeKey, .isRegularFileKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else { return 0 }

        var total: Int64 = 0
        var count = 0
        while let nextURL = enumerator.nextObject() as? URL {
            count += 1
            if count > 120 { break }
            if let values = try? nextURL.resourceValues(forKeys: [.fileSizeKey, .totalFileSizeKey, .isRegularFileKey]),
               values.isRegularFile == true {
                total += Int64(values.totalFileSize ?? values.fileSize ?? 0)
            }
        }

        if useCache {
            Self.cacheLock.lock()
            Self.sizeCache[pathKey] = total
            Self.cacheLock.unlock()
        }
        return total
    }
}
