import Foundation

/// Dữ liệu tiến độ quét theo thời gian thực.
public struct ScanProgress: Sendable, Equatable {
    public let scannedFilesCount: Int
    public let discoveredBytes: Int64
    public let candidateItemsCount: Int
    public let currentScanningPath: String
    public let isCompleted: Bool

    public init(
        scannedFilesCount: Int = 0,
        discoveredBytes: Int64 = 0,
        candidateItemsCount: Int = 0,
        currentScanningPath: String = "",
        isCompleted: Bool = false
    ) {
        self.scannedFilesCount = scannedFilesCount
        self.discoveredBytes = discoveredBytes
        self.candidateItemsCount = candidateItemsCount
        self.currentScanningPath = currentScanningPath
        self.isCompleted = isCompleted
    }
}

/// Thông tin chi tiết của một mục thô thu thập được từ bộ quét APFS.
public struct ScannedRawItem: Sendable, Equatable {
    public let url: URL
    public let fileSize: Int64
    public let lastModifiedDate: Date
    public let lastAccessedDate: Date
    public let isDirectory: Bool
    public let isPackage: Bool
    public let owner: String

    public init(
        url: URL,
        fileSize: Int64,
        lastModifiedDate: Date = Date(),
        lastAccessedDate: Date = Date(),
        isDirectory: Bool = false,
        isPackage: Bool = false,
        owner: String = ProcessInfo.processInfo.environment["USER"] ?? "User"
    ) {
        self.url = url
        self.fileSize = fileSize
        self.lastModifiedDate = lastModifiedDate
        self.lastAccessedDate = lastAccessedDate
        self.isDirectory = isDirectory
        self.isPackage = isPackage
        self.owner = owner
    }
}

/// Lỗi phát sinh trong quá trình quét hệ thống tệp tin.
public enum ScanError: LocalizedError, Sendable, Equatable {
    case scanCancelled
    case directoryAccessDenied(String)
    case invalidDirectory(String)

    public var errorDescription: String? {
        switch self {
        case .scanCancelled:
            return "Quá trình quét đã bị hủy bởi người dùng."
        case .directoryAccessDenied(let path):
            return "Không có quyền truy cập vào thư mục: \(path)"
        case .invalidDirectory(let path):
            return "Thư mục quét không tồn tại hoặc không hợp lệ: \(path)"
        }
    }
}

/// Swift Actor chịu trách nhiệm duyệt cây thư mục APFS bất đồng bộ,
/// bảo vệ tuyệt đối các khu làm việc (Coding Workspaces) và không bao giờ gây nghẽn I/O hay treo máy Mac.
public actor FileScannerActor {
    private let fileManager = FileManager.default
    private let currentUserName = ProcessInfo.processInfo.environment["USER"] ?? "User"

    /// Danh sách các thư mục kỹ thuật/build tuyệt đối không bao giờ đi sâu vào
    private static let skippedFolderNames: Set<String> = [
        "node_modules", ".git", ".svn", ".hg", ".build", ".swiftpm",
        ".gradle", ".gradle-home", ".android-sdk", "deriveddata",
        "pods", "venv", ".venv", "__pycache__", "target", "vendor",
        "bower_components", ".next", ".nuxt", "dist", "build", "out",
        "cleanbull", "cleangiabull", "antigravity", "google", "spotify"
    ]

    /// Các dấu hiệu nhận biết một thư mục là Khu làm việc / Dự án lập trình (Workspace) cần bảo vệ tuyệt đối
    private static let workspaceMarkers: [String] = [
        ".git", "Package.swift", "package.json", "Cargo.toml",
        "pyproject.toml", "Podfile", "gradlew", "CMakeLists.txt",
        ".xcodeproj", ".xcworkspace"
    ]

    public init() {}

    /// Kiểm tra nhanh xem một thư mục có phải là Dự án Code / Khu làm việc hay không
    private func isDeveloperWorkspace(_ dirURL: URL) -> Bool {
        let nameLower = dirURL.lastPathComponent.lowercased()
        if Self.skippedFolderNames.contains(nameLower) {
            return true
        }
        for marker in Self.workspaceMarkers {
            let markerPath = dirURL.appendingPathComponent(marker).path
            if fileManager.fileExists(atPath: markerPath) {
                return true
            }
        }
        return false
    }

    /// Quét các thư mục gốc cực nhẹ (< 150ms), bảo vệ 100% các khu làm việc (Workspaces) và tiết lưu tiến độ.
    public func scan(
        rootURLs: [URL],
        maxItemsPerRoot: Int = 250,
        maxDepth: Int = 2,
        onProgress: (@Sendable (ScanProgress) -> Void)? = nil
    ) async -> [ScannedRawItem] {
        var scannedItems: [ScannedRawItem] = []
        var scannedCount = 0
        var totalCandidateBytes: Int64 = 0

        let resourceKeys: Set<URLResourceKey> = [
            .fileSizeKey,
            .totalFileSizeKey,
            .contentModificationDateKey,
            .contentAccessDateKey,
            .isDirectoryKey,
            .isPackageKey,
            .isRegularFileKey
        ]

        for rootURL in rootURLs {
            if Task.isCancelled { break }

            var isDirectory: ObjCBool = false
            guard fileManager.fileExists(atPath: rootURL.path, isDirectory: &isDirectory) else {
                continue
            }

            if !isDirectory.boolValue {
                scannedCount += 1
                if let item = extractItemMetadata(at: rootURL, resourceKeys: resourceKeys) {
                    scannedItems.append(item)
                    totalCandidateBytes += item.fileSize
                }
                continue
            }

            let rootName = rootURL.lastPathComponent.lowercased()
            let isCacheOrLogRoot = (rootName == "caches" || rootName == "logs")
            let isDownloadsRoot = (rootName == "downloads")

            // 1. Đối với Caches hoặc Logs: Chỉ duyệt cấp 1 (tối đa 80 thư mục cache lớn nhất) để tránh quét hàng trăm nghìn file nhỏ
            if isCacheOrLogRoot {
                if let topLevelURLs = try? fileManager.contentsOfDirectory(
                    at: rootURL,
                    includingPropertiesForKeys: Array(resourceKeys),
                    options: [.skipsHiddenFiles]
                ) {
                    for childURL in topLevelURLs.prefix(80) {
                        if Task.isCancelled { break }
                        let childName = childURL.lastPathComponent.lowercased()
                        // Bỏ qua cache của trình biên dịch / IDE đang chạy để không làm chậm khu làm việc
                        if childName.contains("clang") || childName.contains("swift") || childName.contains("xcode") || childName.contains("antigravity") || childName.contains("typescript") || childName.contains("node") || childName.contains("pip") || childName.contains("homebrew") {
                            continue
                        }
                        scannedCount += 1
                        if let item = extractTopLevelDirectoryOrFileMetadata(at: childURL, resourceKeys: resourceKeys) {
                            if item.fileSize > 0 {
                                scannedItems.append(item)
                                totalCandidateBytes += item.fileSize
                            }
                        }
                        if scannedCount % 40 == 0 {
                            onProgress?(ScanProgress(
                                scannedFilesCount: scannedCount,
                                discoveredBytes: totalCandidateBytes,
                                candidateItemsCount: scannedItems.count,
                                currentScanningPath: childURL.lastPathComponent,
                                isCompleted: false
                            ))
                            await Task.yield()
                        }
                    }
                }
                continue
            }

            // 2. Đối với Downloads: Chỉ duyệt tệp tin cấp 1 (File lẻ, bộ cài .dmg/.pkg/.zip, tài liệu PDF/Word/Excel)
            // TUYỆT ĐỐI KHÔNG đi sâu vào các thư mục dự án / khu làm việc nằm trong Downloads!
            if isDownloadsRoot {
                if let topLevelURLs = try? fileManager.contentsOfDirectory(
                    at: rootURL,
                    includingPropertiesForKeys: Array(resourceKeys),
                    options: [.skipsHiddenFiles]
                ) {
                    for childURL in topLevelURLs.prefix(maxItemsPerRoot) {
                        if Task.isCancelled { break }
                        let values = try? childURL.resourceValues(forKeys: resourceKeys)
                        let isDir = values?.isDirectory ?? false
                        let isPkg = values?.isPackage ?? false

                        // Nếu là thư mục thường trong Downloads (ví dụ: thư mục code CLEANBULL, TẠO TOOL LOCAL ALTTAB...), bỏ qua hoàn toàn để bảo vệ khu làm việc!
                        if isDir && !isPkg {
                            continue
                        }

                        scannedCount += 1
                        if let item = extractItemMetadata(at: childURL, resourceKeys: resourceKeys) {
                            if item.fileSize > 0 {
                                scannedItems.append(item)
                                totalCandidateBytes += item.fileSize
                            }
                        }
                    }
                }
                continue
            }

            // 3. Các thư mục khác (ví dụ trong Kiểm thử hoặc thư mục chỉ định riêng): Giới hạn chặt maxDepth và bảo vệ Workspace
            guard let enumerator = fileManager.enumerator(
                at: rootURL,
                includingPropertiesForKeys: Array(resourceKeys),
                options: [.skipsPackageDescendants, .skipsHiddenFiles]
            ) else {
                continue
            }

            var rootCount = 0
            while let nextURL = enumerator.nextObject() as? URL {
                if Task.isCancelled { break }
                let nameLower = nextURL.lastPathComponent.lowercased()
                if Self.skippedFolderNames.contains(nameLower) {
                    enumerator.skipDescendants()
                    continue
                }
                if enumerator.level > maxDepth {
                    enumerator.skipDescendants()
                    continue
                }

                let values = try? nextURL.resourceValues(forKeys: [.isDirectoryKey, .isPackageKey])
                if values?.isDirectory == true && values?.isPackage != true {
                    if isDeveloperWorkspace(nextURL) {
                        enumerator.skipDescendants()
                        continue
                    }
                }

                rootCount += 1
                scannedCount += 1
                if rootCount > maxItemsPerRoot {
                    break
                }

                if let item = extractItemMetadata(at: nextURL, resourceKeys: resourceKeys) {
                    scannedItems.append(item)
                    totalCandidateBytes += item.fileSize
                }

                if scannedCount % 100 == 0 {
                    onProgress?(ScanProgress(
                        scannedFilesCount: scannedCount,
                        discoveredBytes: totalCandidateBytes,
                        candidateItemsCount: scannedItems.count,
                        currentScanningPath: nextURL.lastPathComponent,
                        isCompleted: false
                    ))
                    await Task.yield()
                }
            }
        }

        onProgress?(ScanProgress(
            scannedFilesCount: scannedCount,
            discoveredBytes: totalCandidateBytes,
            candidateItemsCount: scannedItems.count,
            currentScanningPath: "Quá trình quét hoàn tất",
            isCompleted: true
        ))

        return scannedItems
    }

    /// Quét trực tiếp và trả về toàn bộ danh sách `[ScannedRawItem]` đồng thời kiểm tra `Task.isCancelled`.
    public func scanDirect(rootURLs: [URL]) async throws -> [ScannedRawItem] {
        try Task.checkCancellation()
        return await scan(rootURLs: rootURLs, maxItemsPerRoot: 300, maxDepth: 2)
    }

    private func extractTopLevelDirectoryOrFileMetadata(at url: URL, resourceKeys: Set<URLResourceKey>) -> ScannedRawItem? {
        guard let values = try? url.resourceValues(forKeys: resourceKeys) else {
            return nil
        }
        let isDir = values.isDirectory ?? false
        let isPkg = values.isPackage ?? false
        let modDate = values.contentModificationDate ?? Date()
        let accessDate = values.contentAccessDate ?? modDate

        var size: Int64 = Int64(values.totalFileSize ?? values.fileSize ?? 0)
        if isDir && size == 0 {
            size = fastDirectorySize(at: url, maxFiles: 80)
        }

        return ScannedRawItem(
            url: url,
            fileSize: size,
            lastModifiedDate: modDate,
            lastAccessedDate: accessDate,
            isDirectory: isDir,
            isPackage: isPkg,
            owner: currentUserName
        )
    }

    private func fastDirectorySize(at dirURL: URL, maxFiles: Int) -> Int64 {
        let keys: [URLResourceKey] = [.isRegularFileKey, .totalFileSizeKey, .fileSizeKey]
        guard let enumerator = fileManager.enumerator(
            at: dirURL,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else {
            return 0
        }
        var total: Int64 = 0
        var count = 0
        while let fileURL = enumerator.nextObject() as? URL {
            count += 1
            if count > maxFiles { break }
            if let vals = try? fileURL.resourceValues(forKeys: Set(keys)), vals.isRegularFile == true {
                total += Int64(vals.totalFileSize ?? vals.fileSize ?? 0)
            }
        }
        return total
    }

    private func extractItemMetadata(at url: URL, resourceKeys: Set<URLResourceKey>) -> ScannedRawItem? {
        guard let values = try? url.resourceValues(forKeys: resourceKeys) else {
            return nil
        }

        let isDir = values.isDirectory ?? false
        let isPkg = values.isPackage ?? false

        var size: Int64 = 0
        if isDir && !isPkg {
            size = 0
        } else {
            size = Int64(values.totalFileSize ?? values.fileSize ?? 0)
            if size == 0 {
                let attrs = try? fileManager.attributesOfItem(atPath: url.path)
                size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            }
        }

        let modDate = values.contentModificationDate ?? Date()
        let accessDate = values.contentAccessDate ?? modDate

        return ScannedRawItem(
            url: url,
            fileSize: size,
            lastModifiedDate: modDate,
            lastAccessedDate: accessDate,
            isDirectory: isDir,
            isPackage: isPkg,
            owner: currentUserName
        )
    }
}
