import SwiftUI
import CleanBullCore

/// Nhãn trạng thái chuẩn UI 3 KHÔNG: Nền 50 + Viền 200 + Chữ 700 (Emerald, Amber, Rose, Sky, Zinc)
public struct StatusBadgeView: View {
    public let text: String
    public let style: BadgeStyle

    public enum BadgeStyle {
        case emerald
        case amber
        case rose
        case sky
        case zinc
    }

    public init(_ text: String, style: BadgeStyle = .zinc) {
        self.text = text
        self.style = style
    }

    public var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .semibold))
            .lineLimit(1)
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(bgColor)
            .foregroundColor(textColor)
            .overlay(
                RoundedRectangle(cornerRadius: BullTheme.badgeRadius)
                    .stroke(borderColor, lineWidth: 1)
            )
            .cornerRadius(BullTheme.badgeRadius)
    }

    private var bgColor: Color {
        switch style {
        case .emerald: return BullTheme.emeraldBg
        case .amber: return BullTheme.amberBg
        case .rose: return BullTheme.roseBg
        case .sky: return BullTheme.skyBg
        case .zinc: return BullTheme.bgZinc100
        }
    }

    private var borderColor: Color {
        switch style {
        case .emerald: return BullTheme.emeraldBorder
        case .amber: return BullTheme.amberBorder
        case .rose: return BullTheme.roseBorder
        case .sky: return BullTheme.skyBorder
        case .zinc: return BullTheme.borderZinc300
        }
    }

    private var textColor: Color {
        switch style {
        case .emerald: return BullTheme.emeraldText
        case .amber: return BullTheme.amberText
        case .rose: return BullTheme.roseText
        case .sky: return BullTheme.skyText
        case .zinc: return BullTheme.textZinc600
        }
    }
}
