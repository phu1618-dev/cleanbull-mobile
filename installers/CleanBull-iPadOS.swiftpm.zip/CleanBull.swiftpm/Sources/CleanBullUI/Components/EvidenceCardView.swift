import SwiftUI
import CleanBullCore

/// Thẻ Bằng Chứng (Evidence Card View) minh bạch ngữ cảnh từng tệp tin theo chuẩn UI 3 KHÔNG
/// Có hiệu ứng Hover, Active và Trạng thái Chọn (Emerald Highlight) trên toàn bộ khối thẻ.
public struct EvidenceCardView: View {
    public let item: EvidenceCardModel
    public var isSelected: Bool
    public var onToggleSelect: (() -> Void)?

    @State private var isHovered: Bool = false

    public init(
        item: EvidenceCardModel,
        isSelected: Bool = false,
        onToggleSelect: (() -> Void)? = nil
    ) {
        self.item = item
        self.isSelected = isSelected
        self.onToggleSelect = onToggleSelect
    }

    private var isInteractive: Bool {
        onToggleSelect != nil
    }

    private var cardBackground: Color {
        if isSelected {
            return BullTheme.emeraldBg
        }
        if isHovered && isInteractive {
            return BullTheme.bgZinc100.opacity(0.85)
        }
        return BullTheme.surfaceWhite
    }

    private var cardBorderColor: Color {
        if isSelected {
            return BullTheme.emerald600
        }
        if isHovered && isInteractive {
            return BullTheme.emerald500
        }
        return BullTheme.bgZinc200
    }

    private var cardBorderWidth: CGFloat {
        if isSelected {
            return 2.0
        }
        if isHovered && isInteractive {
            return 1.5
        }
        return 1.0
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 10) {
                if isInteractive {
                    Image(systemName: isSelected ? "checkmark.square.fill" : (isHovered ? "plus.square" : "square"))
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(isSelected ? BullTheme.emerald600 : (isHovered ? BullTheme.emerald700 : BullTheme.textZinc400))
                        .padding(.top, 1)
                }

                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(item.fileName)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(isSelected ? BullTheme.emerald800 : BullTheme.textZinc900)
                            .lineLimit(1)
                            .truncationMode(.middle)

                        if isSelected {
                            StatusBadgeView("ĐÃ CHỌN DỌN DẸP", style: .emerald)
                        } else if isHovered && isInteractive {
                            StatusBadgeView("Chạm để chọn", style: .zinc)
                        }
                    }

                    Text(item.path)
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundColor(BullTheme.textZinc500)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text(item.formattedFileSize)
                        .font(.system(size: 12.5, weight: .bold, design: .monospaced))
                        .monospacedDigit()
                        .foregroundColor(isSelected ? BullTheme.emerald700 : BullTheme.textZinc900)

                    HStack(spacing: 4) {
                        StatusBadgeView(
                            item.riskLevel.localizedTitle,
                            style: badgeStyle(for: item.riskLevel)
                        )
                        StatusBadgeView(
                            "\(item.confidenceScore)%",
                            style: item.isHighConfidence ? .emerald : .zinc
                        )
                    }
                }
            }

            Divider()
                .background(isSelected ? BullTheme.emeraldBorder : BullTheme.bgZinc100)

            VStack(alignment: .leading, spacing: 4) {
                HStack(alignment: .top, spacing: 4) {
                    Text("Lý do:")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc600)
                    Text(item.explanationText)
                        .font(.system(size: 11))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(2)
                }

                HStack(alignment: .top, spacing: 4) {
                    Text("Tác động:")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc600)
                    Text(item.potentialImpactText)
                        .font(.system(size: 11))
                        .foregroundColor(BullTheme.textZinc600)
                        .lineLimit(1)
                }
            }
        }
        .padding(12)
        .background(cardBackground)
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(cardBorderColor, lineWidth: cardBorderWidth)
        )
        .cornerRadius(BullTheme.cornerRadius)
        .contentShape(Rectangle())
        .onHover { hovering in
            withAnimation(.easeOut(duration: 0.12)) {
                isHovered = hovering
            }
        }
        .onTapGesture {
            if let toggle = onToggleSelect {
                withAnimation(.easeOut(duration: 0.12)) {
                    toggle()
                }
            }
        }
    }

    private func badgeStyle(for risk: RiskLevel) -> StatusBadgeView.BadgeStyle {
        switch risk {
        case .low: return .emerald
        case .medium: return .amber
        case .high: return .rose
        }
    }
}
