import SwiftUI

/// Biểu tượng Vector Chuẩn Đa Nền Tảng của CleanBull (Khiên Emerald #10B981 + Đầu Bò Tót Trắng #FFFFFF + Mắt Emerald)
/// Hiển thị sắc nét ở mọi độ phân giải trên iPadOS, iOS và macOS.
public struct CleanBullLogoView: View {
    public let size: CGFloat

    public init(size: CGFloat = 28) {
        self.size = size
    }

    public var body: some View {
        Canvas { context, canvasSize in
            let s = canvasSize.width / 108.0
            let emerald = Color(red: 16/255, green: 185/255, blue: 129/255)
            let white = Color.white

            // 1. Vòm Khiên Trên & Cánh Khiên Dưới (Emerald #10B981)
            var shieldPath = Path()
            shieldPath.move(to: CGPoint(x: 54.0 * s, y: 21.5 * s))
            shieldPath.addLine(to: CGPoint(x: 76.5 * s, y: 29.2 * s))
            shieldPath.addLine(to: CGPoint(x: 76.5 * s, y: 36.5 * s))
            shieldPath.addLine(to: CGPoint(x: 72.3 * s, y: 36.5 * s))
            shieldPath.addLine(to: CGPoint(x: 72.3 * s, y: 32.1 * s))
            shieldPath.addLine(to: CGPoint(x: 54.0 * s, y: 25.8 * s))
            shieldPath.addLine(to: CGPoint(x: 35.7 * s, y: 32.1 * s))
            shieldPath.addLine(to: CGPoint(x: 35.7 * s, y: 36.5 * s))
            shieldPath.addLine(to: CGPoint(x: 31.5 * s, y: 36.5 * s))
            shieldPath.addLine(to: CGPoint(x: 31.5 * s, y: 29.2 * s))
            shieldPath.closeSubpath()

            shieldPath.move(to: CGPoint(x: 30.2 * s, y: 51.5 * s))
            shieldPath.addLine(to: CGPoint(x: 34.4 * s, y: 52.8 * s))
            shieldPath.addCurve(
                to: CGPoint(x: 54.0 * s, y: 83.4 * s),
                control1: CGPoint(x: 35.5 * s, y: 65.8 * s),
                control2: CGPoint(x: 42.4 * s, y: 75.8 * s)
            )
            shieldPath.addCurve(
                to: CGPoint(x: 73.6 * s, y: 52.8 * s),
                control1: CGPoint(x: 65.6 * s, y: 75.8 * s),
                control2: CGPoint(x: 72.5 * s, y: 65.8 * s)
            )
            shieldPath.addLine(to: CGPoint(x: 77.8 * s, y: 51.5 * s))
            shieldPath.addCurve(
                to: CGPoint(x: 54.0 * s, y: 87.8 * s),
                control1: CGPoint(x: 76.4 * s, y: 67.2 * s),
                control2: CGPoint(x: 68.2 * s, y: 78.8 * s)
            )
            shieldPath.addCurve(
                to: CGPoint(x: 30.2 * s, y: 51.5 * s),
                control1: CGPoint(x: 39.8 * s, y: 78.8 * s),
                control2: CGPoint(x: 31.6 * s, y: 67.2 * s)
            )
            shieldPath.closeSubpath()
            context.fill(shieldPath, with: .color(emerald))

            // 2. Sừng, Tai & Đầu Bò Tót Hình Học (#FFFFFF)
            var bullPath = Path()
            // Sừng trái
            bullPath.move(to: CGPoint(x: 33.2 * s, y: 21.2 * s))
            bullPath.addCurve(
                to: CGPoint(x: 32.6 * s, y: 39.2 * s),
                control1: CGPoint(x: 26.4 * s, y: 29.2 * s),
                control2: CGPoint(x: 26.2 * s, y: 37.5 * s)
            )
            bullPath.addLine(to: CGPoint(x: 41.0 * s, y: 39.2 * s))
            bullPath.addLine(to: CGPoint(x: 38.8 * s, y: 45.2 * s))
            bullPath.addLine(to: CGPoint(x: 29.4 * s, y: 45.2 * s))
            bullPath.addCurve(
                to: CGPoint(x: 28.4 * s, y: 23.0 * s),
                control1: CGPoint(x: 21.0 * s, y: 45.2 * s),
                control2: CGPoint(x: 19.4 * s, y: 34.4 * s)
            )
            bullPath.closeSubpath()

            // Sừng phải
            bullPath.move(to: CGPoint(x: 74.8 * s, y: 21.2 * s))
            bullPath.addCurve(
                to: CGPoint(x: 75.4 * s, y: 39.2 * s),
                control1: CGPoint(x: 81.6 * s, y: 29.2 * s),
                control2: CGPoint(x: 81.8 * s, y: 37.5 * s)
            )
            bullPath.addLine(to: CGPoint(x: 67.0 * s, y: 39.2 * s))
            bullPath.addLine(to: CGPoint(x: 69.2 * s, y: 45.2 * s))
            bullPath.addLine(to: CGPoint(x: 78.6 * s, y: 45.2 * s))
            bullPath.addCurve(
                to: CGPoint(x: 79.6 * s, y: 23.0 * s),
                control1: CGPoint(x: 87.0 * s, y: 45.2 * s),
                control2: CGPoint(x: 88.6 * s, y: 34.4 * s)
            )
            bullPath.closeSubpath()

            // Tai trái & phải
            bullPath.move(to: CGPoint(x: 38.2 * s, y: 46.8 * s))
            bullPath.addLine(to: CGPoint(x: 24.2 * s, y: 48.2 * s))
            bullPath.addLine(to: CGPoint(x: 30.0 * s, y: 52.6 * s))
            bullPath.addLine(to: CGPoint(x: 38.0 * s, y: 51.2 * s))
            bullPath.closeSubpath()

            bullPath.move(to: CGPoint(x: 69.8 * s, y: 46.8 * s))
            bullPath.addLine(to: CGPoint(x: 83.8 * s, y: 48.2 * s))
            bullPath.addLine(to: CGPoint(x: 78.0 * s, y: 52.6 * s))
            bullPath.addLine(to: CGPoint(x: 70.0 * s, y: 51.2 * s))
            bullPath.closeSubpath()

            // Gò má trái & phải
            bullPath.move(to: CGPoint(x: 39.4 * s, y: 51.0 * s))
            bullPath.addLine(to: CGPoint(x: 45.2 * s, y: 53.4 * s))
            bullPath.addLine(to: CGPoint(x: 46.2 * s, y: 55.4 * s))
            bullPath.addLine(to: CGPoint(x: 44.2 * s, y: 65.6 * s))
            bullPath.addLine(to: CGPoint(x: 39.8 * s, y: 59.6 * s))
            bullPath.closeSubpath()

            bullPath.move(to: CGPoint(x: 68.6 * s, y: 51.0 * s))
            bullPath.addLine(to: CGPoint(x: 62.8 * s, y: 53.4 * s))
            bullPath.addLine(to: CGPoint(x: 61.8 * s, y: 55.4 * s))
            bullPath.addLine(to: CGPoint(x: 63.8 * s, y: 65.6 * s))
            bullPath.addLine(to: CGPoint(x: 68.2 * s, y: 59.6 * s))
            bullPath.closeSubpath()

            // Khối Trán & Sống Mũi Trung Tâm
            bullPath.move(to: CGPoint(x: 48.5 * s, y: 33.8 * s))
            bullPath.addLine(to: CGPoint(x: 54.0 * s, y: 35.6 * s))
            bullPath.addLine(to: CGPoint(x: 59.5 * s, y: 33.8 * s))
            bullPath.addLine(to: CGPoint(x: 65.8 * s, y: 36.4 * s))
            bullPath.addLine(to: CGPoint(x: 68.2 * s, y: 46.4 * s))
            bullPath.addLine(to: CGPoint(x: 62.0 * s, y: 48.2 * s))
            bullPath.addLine(to: CGPoint(x: 60.2 * s, y: 51.5 * s))
            bullPath.addLine(to: CGPoint(x: 62.8 * s, y: 64.5 * s))
            bullPath.addLine(to: CGPoint(x: 64.6 * s, y: 68.5 * s))
            bullPath.addLine(to: CGPoint(x: 61.5 * s, y: 73.2 * s))
            bullPath.addLine(to: CGPoint(x: 54.0 * s, y: 72.0 * s))
            bullPath.addLine(to: CGPoint(x: 46.5 * s, y: 73.2 * s))
            bullPath.addLine(to: CGPoint(x: 43.4 * s, y: 68.5 * s))
            bullPath.addLine(to: CGPoint(x: 45.2 * s, y: 64.5 * s))
            bullPath.addLine(to: CGPoint(x: 47.8 * s, y: 51.5 * s))
            bullPath.addLine(to: CGPoint(x: 46.0 * s, y: 48.2 * s))
            bullPath.addLine(to: CGPoint(x: 39.8 * s, y: 46.4 * s))
            bullPath.addLine(to: CGPoint(x: 42.2 * s, y: 36.4 * s))
            bullPath.closeSubpath()

            // Cằm dưới
            bullPath.move(to: CGPoint(x: 48.5 * s, y: 74.8 * s))
            bullPath.addLine(to: CGPoint(x: 59.5 * s, y: 74.8 * s))
            bullPath.addLine(to: CGPoint(x: 57.5 * s, y: 77.6 * s))
            bullPath.addLine(to: CGPoint(x: 50.5 * s, y: 77.6 * s))
            bullPath.closeSubpath()
            context.fill(bullPath, with: .color(white))

            // 3. Đôi Mắt Sắc Lạnh (Emerald #10B981)
            var eyesPath = Path()
            eyesPath.move(to: CGPoint(x: 41.0 * s, y: 48.0 * s))
            eyesPath.addLine(to: CGPoint(x: 47.2 * s, y: 51.5 * s))
            eyesPath.addLine(to: CGPoint(x: 45.2 * s, y: 53.2 * s))
            eyesPath.addLine(to: CGPoint(x: 41.4 * s, y: 51.4 * s))
            eyesPath.closeSubpath()

            eyesPath.move(to: CGPoint(x: 67.0 * s, y: 48.0 * s))
            eyesPath.addLine(to: CGPoint(x: 60.8 * s, y: 51.5 * s))
            eyesPath.addLine(to: CGPoint(x: 62.8 * s, y: 53.2 * s))
            eyesPath.addLine(to: CGPoint(x: 66.6 * s, y: 51.4 * s))
            eyesPath.closeSubpath()
            context.fill(eyesPath, with: .color(emerald))
        }
        .frame(width: size, height: size)
        .background(Color(red: 24/255, green: 24/255, blue: 27/255))
        .clipShape(RoundedRectangle(cornerRadius: size * 0.225, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: size * 0.225, style: .continuous)
                .stroke(Color(red: 39/255, green: 39/255, blue: 42/255), lineWidth: 1)
        )
    }
}
