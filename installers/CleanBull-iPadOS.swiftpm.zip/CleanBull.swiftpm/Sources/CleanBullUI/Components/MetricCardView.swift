import SwiftUI

/// Thẻ KPI phẳng chuẩn UI 3 KHÔNG (0 Emoji, viền mảnh 1px, Tabular-nums, có hiệu ứng Hover)
public struct MetricCardView: View {
    public let title: String
    public let value: String
    public let subtitle: String?
    public let systemImage: String?
    public let badgeText: String?
    public let badgeStyle: StatusBadgeView.BadgeStyle

    @State private var isHovered: Bool = false

    public init(
        title: String,
        value: String,
        subtitle: String? = nil,
        systemImage: String? = nil,
        badgeText: String? = nil,
        badgeStyle: StatusBadgeView.BadgeStyle = .zinc
    ) {
        self.title = title
        self.value = value
        self.subtitle = subtitle
        self.systemImage = systemImage
        self.badgeText = badgeText
        self.badgeStyle = badgeStyle
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                if let icon = systemImage {
                    Image(systemName: icon)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(isHovered ? BullTheme.emerald700 : BullTheme.textZinc600)
                }
                Text(title)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(isHovered ? BullTheme.emerald800 : BullTheme.textZinc600)
                    .lineLimit(1)
                    .truncationMode(.tail)
                Spacer()
                if let badge = badgeText {
                    StatusBadgeView(badge, style: badgeStyle)
                }
            }

            Text(value)
                .font(.system(size: 20, weight: .bold))
                .monospacedDigit()
                .foregroundColor(BullTheme.textZinc900)
                .lineLimit(1)

            if let sub = subtitle {
                Text(sub)
                    .font(.system(size: 11))
                    .foregroundColor(isHovered ? BullTheme.textZinc600 : BullTheme.textZinc400)
                    .lineLimit(1)
                    .truncationMode(.tail)
            }
        }
        .padding(12)
        .background(isHovered ? BullTheme.emeraldBg.opacity(0.35) : BullTheme.surfaceWhite)
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(isHovered ? BullTheme.emerald500 : BullTheme.bgZinc200, lineWidth: isHovered ? 1.5 : 1)
        )
        .cornerRadius(BullTheme.cornerRadius)
        .contentShape(Rectangle())
        .onHover { h in
            withAnimation(.easeOut(duration: 0.12)) {
                isHovered = h
            }
        }
    }
}
