import SwiftUI
import CleanBullCore

/// Nhóm điều hướng trên Sidebar chuẩn v4.4.0
public enum SidebarGroup: String, CaseIterable, Identifiable {
    case commandCenter = "TRUNG TÂM TÁC CHIẾN"
    case deepClean = "QUẢN LÝ HỆ THỐNG"
    case securityAndVpn = "AN TOÀN & KHIÊN MẠNG"

    public var id: String { rawValue }
}

/// Các phân hệ của ứng dụng CleanBull (Khớp 100% giao diện v4.4.0)
public enum SubsystemRoute: String, CaseIterable, Identifiable {
    case dashboard = "dashboard"
    case aiAssistant = "ai_assistant"
    case memoryGuardian = "memory_guardian"
    case storageCleaner = "storage_cleaner"
    case appUninstaller = "app_uninstaller"
    case appUsage = "app_usage"
    case safetyCenter = "safety_center"
    case vpnShield = "vpn_shield"

    public var id: String { rawValue }

    public var group: SidebarGroup {
        switch self {
        case .dashboard, .aiAssistant:
            return .commandCenter
        case .memoryGuardian, .storageCleaner, .appUninstaller, .appUsage:
            return .deepClean
        case .safetyCenter, .vpnShield:
            return .securityAndVpn
        }
    }

    public var title: String {
        switch self {
        case .dashboard: return "Tổng quan & Dọn dẹp"
        case .aiAssistant: return "Trợ lý AI Thực Thi"
        case .memoryGuardian: return "Quản lý RAM & Tiến trình"
        case .storageCleaner: return "Tài liệu & Dung lượng"
        case .appUninstaller: return "Ứng dụng & Rác Tồn Đọng"
        case .appUsage: return "Tần Suất Dùng App"
        case .safetyCenter: return "Kho Cách Ly SHA-256"
        case .vpnShield: return "Khiên VPN & Chặn Tracker"
        }
    }

    public var subtitle: String {
        switch self {
        case .dashboard: return "Bảng điều khiển nhanh"
        case .aiAssistant: return "Hiểu lệnh & dọn thật"
        case .memoryGuardian: return "Giải phóng bộ nhớ & tiến trình"
        case .storageCleaner: return "Tài liệu không dùng & trùng lặp"
        case .appUninstaller: return "Dọn cache & app ít dùng"
        case .appUsage: return "Theo dõi lịch sử mở app thật"
        case .safetyCenter: return "Hoàn tác phiên an toàn"
        case .vpnShield: return "Đổi vùng & lọc quảng cáo"
        }
    }

    public var iconName: String {
        switch self {
        case .dashboard: return "speedometer"
        case .aiAssistant: return "terminal"
        case .memoryGuardian: return "cpu"
        case .storageCleaner: return "internaldrive"
        case .appUninstaller: return "trash"
        case .appUsage: return "clock.arrow.circlepath"
        case .safetyCenter: return "archivebox"
        case .vpnShield: return "lock.shield"
        }
    }
}

/// Giao diện chính của CleanBull v4.4.0 (Khớp 100% bố cục & thẩm mỹ https://phu1618-dev.github.io/cleanbull-mobile/)
public struct CleanBullRootView: View {
    @State private var selectedRoute: SubsystemRoute = .vpnShield
    @State private var syncToast: String? = nil

    public init() {}

    public var body: some View {
        VStack(spacing: 0) {
            // 1. Top Status Header Bar (Chuẩn v4.4.0)
            topHeaderBar

            Divider()

            // 2. Main Split Content: Custom Left Sidebar + Active View
            HStack(spacing: 0) {
                leftSidebar
                Divider()
                detailContentArea
            }
        }
        .background(BullTheme.bgZinc50)
        .frame(minWidth: 1120, minHeight: 720)
        .onAppear {
            AppLaunchTracker.shared.startTracking()
        }
    }

    // MARK: - Top Status Header Bar
    private var topHeaderBar: some View {
        HStack(spacing: 12) {
            HStack(spacing: 8) {
                CleanBullLogoView(size: 24)
                Text("CleanBull Mobile")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(BullTheme.textZinc900)
                Text("v4.4.0")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(BullTheme.emeraldBg)
                    .foregroundColor(BullTheme.emeraldText)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.badgeRadius)

                if let toast = syncToast {
                    Text(toast)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(BullTheme.emerald700)
                        .padding(.leading, 6)
                }
            }

            Spacer()

            HStack(spacing: 14) {
                HStack(spacing: 4) {
                    Image(systemName: "checkmark.shield")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(BullTheme.emerald600)
                    Text("Chuẩn 3 Không")
                        .font(.system(size: 11.5, weight: .medium))
                        .foregroundColor(BullTheme.textZinc600)
                }

                HStack(spacing: 4) {
                    Image(systemName: "lock.shield")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(BullTheme.emerald600)
                    Text("Bảo Mật 100%")
                        .font(.system(size: 11.5, weight: .medium))
                        .foregroundColor(BullTheme.textZinc600)
                }

                Text("macOS • iPadOS • Android Ready")
                    .font(.system(size: 10.5, weight: .semibold, design: .monospaced))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(BullTheme.bgZinc100)
                    .foregroundColor(BullTheme.textZinc700)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                    .cornerRadius(BullTheme.badgeRadius)
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 44)
        .background(BullTheme.surfaceWhite)
    }

    // MARK: - Left Sidebar (3 Groups + Emerald 600 Active Highlight)
    private var leftSidebar: some View {
        VStack(alignment: .leading, spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    ForEach(SidebarGroup.allCases) { group in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(group.rawValue)
                                .font(.system(size: 10, weight: .bold))
                                .tracking(0.6)
                                .foregroundColor(BullTheme.textZinc400)
                                .padding(.horizontal, 10)
                                .padding(.bottom, 2)

                            let items = SubsystemRoute.allCases.filter { $0.group == group }
                            ForEach(items) { route in
                                sidebarItemButton(route)
                            }
                        }
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 14)
            }

            Divider()

            // Footer: Đồng Bộ Bản Mới (v4.4) + Khiên Bảo Mật Local-First
            VStack(spacing: 8) {
                Button(action: triggerSyncStatus) {
                    HStack(spacing: 6) {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.system(size: 11.5, weight: .semibold))
                            .foregroundColor(BullTheme.textZinc600)
                        Text("Đồng Bộ Bản Mới (v4.4)")
                            .font(.system(size: 11.5, weight: .semibold))
                            .foregroundColor(BullTheme.textZinc700)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 7)
                    .background(BullTheme.bgZinc50)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                    .cornerRadius(BullTheme.buttonRadius)
                }
                .buttonStyle(.plain)

                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 5) {
                        Image(systemName: "lock.shield")
                            .font(.system(size: 11.5, weight: .semibold))
                            .foregroundColor(BullTheme.emerald700)
                        Text("Khiên Bảo Mật Local-First")
                            .font(.system(size: 11.5, weight: .bold))
                            .foregroundColor(BullTheme.emerald800)
                            .lineLimit(1)
                    }
                    Text("100% xử lý tại chỗ — Chuẩn 3 Không")
                        .font(.system(size: 10.5))
                        .foregroundColor(BullTheme.emerald700)
                        .lineLimit(1)
                }
                .padding(9)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(BullTheme.emeraldBg)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                .cornerRadius(BullTheme.buttonRadius)
            }
            .padding(10)
        }
        .frame(width: 245)
        .background(BullTheme.surfaceWhite)
    }

    @State private var hoveredRoute: SubsystemRoute? = nil

    private func sidebarItemButton(_ route: SubsystemRoute) -> some View {
        let isActive = selectedRoute == route
        let isHov = hoveredRoute == route
        return Button(action: {
            withAnimation(.easeOut(duration: 0.1)) {
                selectedRoute = route
            }
        }) {
            HStack(spacing: 10) {
                Image(systemName: route.iconName)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(isActive ? .white : (isHov ? BullTheme.emerald700 : BullTheme.textZinc400))
                    .frame(width: 18)

                VStack(alignment: .leading, spacing: 1.5) {
                    Text(route.title)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(isActive ? .white : (isHov ? BullTheme.emerald800 : BullTheme.textZinc700))
                        .lineLimit(1)

                    Text(route.subtitle)
                        .font(.system(size: 10.5))
                        .foregroundColor(isActive ? BullTheme.emerald100 : BullTheme.textZinc400)
                        .lineLimit(1)
                }

                Spacer(minLength: 0)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(isActive ? BullTheme.emerald600 : (isHov ? BullTheme.emeraldBg : Color.clear))
            .overlay(
                RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                    .stroke(isActive ? BullTheme.emerald700 : (isHov ? BullTheme.emeraldBorder : Color.clear), lineWidth: 1)
            )
            .cornerRadius(BullTheme.buttonRadius)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .onHover { h in
            hoveredRoute = h ? route : nil
        }
    }

    // MARK: - Detail Content Area
    @ViewBuilder
    private var detailContentArea: some View {
        Group {
            switch selectedRoute {
            case .dashboard:
                DashboardView(onNavigate: { target in
                    selectedRoute = target
                })
            case .aiAssistant:
                AIAssistantView()
            case .memoryGuardian:
                MemoryGuardianView()
            case .storageCleaner:
                StorageCleanerView()
            case .appUninstaller:
                AppUninstallerView()
            case .appUsage:
                AppUsageView()
            case .safetyCenter:
                SafetyCenterView()
            case .vpnShield:
                UnifiedVPNShieldView()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func triggerSyncStatus() {
        syncToast = "Đã đồng bộ dữ liệu trực tiếp v4.4.0"
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            syncToast = nil
        }
    }
}
