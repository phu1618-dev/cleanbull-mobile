import SwiftUI
import CleanBullCore

/// Bộ nhớ đệm In-Memory cho kết quả quét Dung lượng để chuyển tab 0ms, không quét lặp
private final class StorageCleanerScanCache: @unchecked Sendable {
    static let shared = StorageCleanerScanCache()
    private let lock = NSLock()
    var cachedItems: [EvidenceCardModel] = []
    var cachedDuplicates: [DuplicateFileGroup] = []
    var hasScannedOnce: Bool = false
}

/// Phân hệ 4: Dọn dẹp Dung lượng & Pipeline Băm 3 Tầng (StorageCleaner)
/// Đã tích hợp Bảo Vệ Khu Làm Việc (Workspace Guard) — không bao giờ quét vào thư mục dự án code trong Downloads.
public struct StorageCleanerView: View {
    @State private var selectedCategory: CleanerCategory = .all
    @State private var items: [EvidenceCardModel] = []
    @State private var selectedIds: Set<UUID> = []
    @State private var isScanning: Bool = false
    @State private var scanProgressText: String = ""
    @State private var actionMessage: String?
    @State private var duplicateGroups: [DuplicateFileGroup] = []
    @State private var showDuplicatesSection: Bool = false
    @State private var hoveredCategory: String? = nil

    private let scanner = FileScannerActor()
    private let ruleEngine = RuleEngine()
    private let hashPipeline = HashPipeline()
    private let quarantineManager = QuarantineManager()

    public init() {}

    public var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 8) {
                        Text("Dọn Dẹp Dung Lượng & Tệp Trùng")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        StatusBadgeView("Bảo vệ Khu làm việc 100%", style: .emerald)
                    }
                    Text("Quét Caches, Logs, File tải về lẻ & Băm 3 tầng SHA-256 (Tự động bỏ qua mọi thư mục dự án Code / Workspace)")
                        .font(.system(size: 12))
                        .foregroundColor(BullTheme.textZinc600)
                }
                Spacer()
                Button(action: { startScan(forceRefresh: true) }) {
                    HStack(spacing: 6) {
                        Image(systemName: isScanning ? "arrow.triangle.2.circlepath" : "magnifyingglass")
                        Text(isScanning ? "Đang quét nhanh..." : "Quét làm mới")
                    }
                    .font(.system(size: 12.5, weight: .semibold))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(BullTheme.emerald600)
                    .foregroundColor(.white)
                    .cornerRadius(BullTheme.buttonRadius)
                }
                .buttonStyle(.plain)
                .disabled(isScanning)
            }
            .padding(16)
            .background(BullTheme.surfaceWhite)
            .overlay(Divider(), alignment: .bottom)

            // Category Tabs + Duplicates Toggle
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(CleanerCategory.allCases) { cat in
                        let isSelected = !showDuplicatesSection && selectedCategory == cat
                        let isHov = hoveredCategory == cat.rawValue
                        let catCount = countForCategory(cat)
                        Button(action: {
                            withAnimation(.easeOut(duration: 0.12)) {
                                showDuplicatesSection = false
                                selectedCategory = cat
                            }
                        }) {
                            HStack(spacing: 5) {
                                Image(systemName: cat.iconName)
                                Text("\(cat.localizedTitle) (\(catCount))")
                            }
                            .font(.system(size: 12, weight: .semibold))
                            .padding(.horizontal, 11)
                            .padding(.vertical, 7)
                            .background(isSelected ? BullTheme.emerald600 : (isHov ? BullTheme.emeraldBg : BullTheme.surfaceWhite))
                            .foregroundColor(isSelected ? .white : (isHov ? BullTheme.emerald800 : BullTheme.textZinc700))
                            .overlay(
                                RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                                    .stroke(isSelected ? BullTheme.emerald600 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: 1)
                            )
                            .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)
                        .onHover { h in hoveredCategory = h ? cat.rawValue : nil }
                    }

                    let isDupHov = hoveredCategory == "dup"
                    Button(action: {
                        withAnimation(.easeOut(duration: 0.12)) {
                            showDuplicatesSection = true
                        }
                    }) {
                        HStack(spacing: 5) {
                            Image(systemName: "doc.on.doc")
                            Text("Tệp Trùng 3-Tier (\(duplicateGroups.count) nhóm)")
                        }
                        .font(.system(size: 12, weight: .semibold))
                        .padding(.horizontal, 11)
                        .padding(.vertical, 7)
                        .background(showDuplicatesSection ? BullTheme.emerald600 : (isDupHov ? BullTheme.emeraldBg : BullTheme.surfaceWhite))
                        .foregroundColor(showDuplicatesSection ? .white : (isDupHov ? BullTheme.emerald800 : BullTheme.textZinc700))
                        .overlay(
                            RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                                .stroke(showDuplicatesSection ? BullTheme.emerald600 : (isDupHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: 1)
                        )
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                    .onHover { h in hoveredCategory = h ? "dup" : nil }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
            }
            .background(BullTheme.bgZinc50)
            .overlay(Divider(), alignment: .bottom)

            if let msg = actionMessage {
                HStack {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(BullTheme.emerald700)
                    Text(msg)
                        .font(.system(size: 12, weight: .semibold))
                    Spacer()
                    Button("Đóng") { actionMessage = nil }
                        .font(.system(size: 11, weight: .semibold))
                        .buttonStyle(.plain)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(BullTheme.emeraldBg)
                .foregroundColor(BullTheme.emerald800)
            }

            // Main List
            ScrollView {
                LazyVStack(spacing: 10) {
                    if isScanning {
                        VStack(spacing: 8) {
                            ProgressView()
                            Text(scanProgressText.isEmpty ? "Đang quét các mục an toàn (bỏ qua mọi Workspace)..." : scanProgressText)
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(BullTheme.textZinc600)
                        }
                        .padding(.vertical, 40)
                    } else if showDuplicatesSection {
                        if duplicateGroups.isEmpty {
                            VStack(spacing: 8) {
                                Image(systemName: "checkmark.seal")
                                    .font(.system(size: 28))
                                    .foregroundColor(BullTheme.emeraldText)
                                Text("Không phát hiện nhóm tệp trùng lặp nào trong phiên quét hiện tại.")
                                    .font(.system(size: 13))
                                    .foregroundColor(BullTheme.textZinc600)
                            }
                            .padding(.vertical, 40)
                        } else {
                            ForEach(duplicateGroups) { group in
                                duplicateGroupCard(group)
                            }
                        }
                    } else if filteredItems.isEmpty {
                        VStack(spacing: 8) {
                            Image(systemName: "checkmark.shield")
                                .font(.system(size: 28))
                                .foregroundColor(BullTheme.emerald600)
                            Text("Danh mục này hiện đã sạch sẽ hoặc không có tệp rác vượt ngưỡng.")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(BullTheme.textZinc600)
                        }
                        .padding(.vertical, 40)
                    } else {
                        // Thanh thao tác chọn và dọn dẹp nổi bật
                        HStack(spacing: 8) {
                            HStack(spacing: 5) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(selectedItems.isEmpty ? BullTheme.textZinc400 : BullTheme.emerald600)
                                Text("Đã chọn: \(selectedItems.count)/\(filteredItems.count) khối (\(selectedSizeFormatted))")
                                    .font(.system(size: 12.5, weight: .bold))
                                    .monospacedDigit()
                                    .foregroundColor(BullTheme.textZinc900)
                            }

                            Button("Chọn Tất cả Rủi ro Thấp") {
                                withAnimation(.easeOut(duration: 0.12)) {
                                    selectedIds = Set(filteredItems.filter { $0.riskLevel == .low }.map { $0.id })
                                }
                            }
                            .font(.system(size: 11, weight: .semibold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(BullTheme.emeraldBg)
                            .foregroundColor(BullTheme.emerald800)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                            .cornerRadius(BullTheme.badgeRadius)
                            .buttonStyle(.plain)

                            Button("Chọn Tất cả") {
                                withAnimation(.easeOut(duration: 0.12)) {
                                    selectedIds = Set(filteredItems.map { $0.id })
                                }
                            }
                            .font(.system(size: 11, weight: .medium))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(BullTheme.surfaceWhite)
                            .foregroundColor(BullTheme.textZinc700)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                            .cornerRadius(BullTheme.badgeRadius)
                            .buttonStyle(.plain)

                            Button("Bỏ chọn hết") {
                                withAnimation(.easeOut(duration: 0.12)) {
                                    selectedIds.removeAll()
                                }
                            }
                            .font(.system(size: 11, weight: .medium))
                            .foregroundColor(BullTheme.textZinc600)
                            .buttonStyle(.plain)

                            Spacer()

                            Button(action: deletePermanentlySelected) {
                                Text("Xóa Vĩnh Viễn (\(selectedItems.count))")
                                    .font(.system(size: 12, weight: .semibold))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(BullTheme.roseBg)
                                    .foregroundColor(BullTheme.roseText)
                                    .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.roseBorder, lineWidth: 1))
                                    .cornerRadius(BullTheme.badgeRadius)
                            }
                            .buttonStyle(.plain)
                            .disabled(selectedItems.isEmpty)

                            Button(action: quarantineSelected) {
                                HStack(spacing: 4) {
                                    Image(systemName: "archivebox.fill")
                                    Text("Dọn & Đưa Vào Kho Cách Ly (\(selectedItems.count))")
                                }
                                .font(.system(size: 12, weight: .bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(selectedItems.isEmpty ? BullTheme.bgZinc200 : BullTheme.emerald600)
                                .foregroundColor(selectedItems.isEmpty ? BullTheme.textZinc500 : .white)
                                .cornerRadius(BullTheme.badgeRadius)
                            }
                            .buttonStyle(.plain)
                            .disabled(selectedItems.isEmpty)
                        }
                        .padding(10)
                        .background(BullTheme.surfaceWhite)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                        .cornerRadius(BullTheme.cornerRadius)

                        ForEach(filteredItems) { card in
                            EvidenceCardView(
                                item: card,
                                isSelected: selectedIds.contains(card.id),
                                onToggleSelect: {
                                    if selectedIds.contains(card.id) {
                                        selectedIds.remove(card.id)
                                    } else {
                                        selectedIds.insert(card.id)
                                    }
                                }
                            )
                        }
                    }
                }
                .padding(16)
            }

            // Bottom Info Bar
            HStack {
                Text("Gợi ý: Chạm vào bất kỳ chỗ nào trên khối thẻ để chọn hoặc bỏ chọn. Mặc định chọn sẵn các mục Rủi ro Thấp.")
                    .font(.system(size: 11))
                    .foregroundColor(BullTheme.textZinc600)
                Spacer()
                Text("Workspace Guard Active • 3-Tier SHA-256")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(BullTheme.emerald700)
            }
            .padding(10)
            .background(BullTheme.bgZinc100)
            .overlay(Divider(), alignment: .top)
        }
        .background(BullTheme.bgZinc50)
        .onAppear {
            if StorageCleanerScanCache.shared.hasScannedOnce {
                let cached = StorageCleanerScanCache.shared.cachedItems
                self.items = cached
                self.duplicateGroups = StorageCleanerScanCache.shared.cachedDuplicates
                if self.selectedIds.isEmpty {
                    self.selectedIds = Set(cached.filter { $0.riskLevel == .low }.map { $0.id })
                }
            } else {
                startScan(forceRefresh: false)
            }
        }
    }

    private func countForCategory(_ cat: CleanerCategory) -> Int {
        switch cat {
        case .all: return items.count
        case .appCaches: return items.filter { $0.fileType == "App Cache" }.count
        case .appLogs: return items.filter { $0.fileType == "App Log" }.count
        case .oldDownloads: return items.filter { $0.fileType == "Old Download" }.count
        case .largeFiles: return items.filter { $0.fileType == "Large File" }.count
        }
    }

    private var filteredItems: [EvidenceCardModel] {
        switch selectedCategory {
        case .all: return items
        case .appCaches: return items.filter { $0.fileType == "App Cache" }
        case .appLogs: return items.filter { $0.fileType == "App Log" }
        case .oldDownloads: return items.filter { $0.fileType == "Old Download" }
        case .largeFiles: return items.filter { $0.fileType == "Large File" }
        }
    }

    private func duplicateGroupCard(_ group: DuplicateFileGroup) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("Tệp gốc: \(group.masterFile.lastPathComponent) • \(group.duplicateFiles.count) bản trùng")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(BullTheme.textZinc900)
                Spacer()
                StatusBadgeView(
                    "Lãng phí: \(group.formattedWastedSize)",
                    style: .amber
                )
            }
            Text("SHA-256: \(group.sha256)")
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(BullTheme.textZinc400)
                .lineLimit(1)

            ForEach(group.duplicateFiles, id: \.path) { url in
                HStack {
                    Image(systemName: "doc.on.doc")
                        .font(.system(size: 11))
                        .foregroundColor(BullTheme.textZinc600)
                    Text(url.path)
                        .font(.system(size: 11))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Spacer()
                }
                .padding(6)
                .background(BullTheme.bgZinc50)
                .cornerRadius(BullTheme.badgeRadius)
            }
        }
        .padding(12)
        .background(BullTheme.surfaceWhite)
        .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
        .cornerRadius(BullTheme.cornerRadius)
    }

    private var selectedItems: [EvidenceCardModel] {
        filteredItems.filter { selectedIds.contains($0.id) }
    }

    private var selectedSizeFormatted: String {
        let total = selectedItems.reduce(0) { $0 + $1.fileSize }
        return ByteCountFormatter.string(fromByteCount: total, countStyle: .file)
    }

    private func startScan(forceRefresh: Bool) {
        if !forceRefresh && StorageCleanerScanCache.shared.hasScannedOnce {
            return
        }
        isScanning = true
        actionMessage = nil
        let scannerActor = scanner
        let engine = ruleEngine
        let pipeline = hashPipeline

        // Chạy hoàn toàn trên luồng nền .utility — tách biệt 100% khỏi MainActor để không bao giờ treo UI hoặc làm chậm máy
        Task.detached(priority: .utility) {
            let home = FileManager.default.homeDirectoryForCurrentUser
            let scanDirs = [
                home.appendingPathComponent("Library/Caches"),
                home.appendingPathComponent("Library/Logs"),
                home.appendingPathComponent("Downloads")
            ]

            let raw = await scannerActor.scan(rootURLs: scanDirs, maxItemsPerRoot: 180, maxDepth: 2) { progress in
                Task { @MainActor in
                    self.scanProgressText = "Đã kiểm tra \(progress.scannedFilesCount) mục an toàn (\(ByteCountFormatter.string(fromByteCount: progress.discoveredBytes, countStyle: .file)))"
                }
            }

            let cards = engine.evaluateAll(rawItems: raw)

            // Chỉ băm tìm trùng lặp trên các file lẻ trong Downloads (tối đa 120 file < 100MB)
            let regularFileUrls = raw.filter { !$0.isDirectory }.prefix(120).map { $0.url }
            let duplicates = (try? pipeline.findDuplicates(candidateURLs: Array(regularFileUrls))) ?? []

            StorageCleanerScanCache.shared.cachedItems = cards
            StorageCleanerScanCache.shared.cachedDuplicates = duplicates
            StorageCleanerScanCache.shared.hasScannedOnce = true

            await MainActor.run {
                self.items = cards
                self.duplicateGroups = duplicates
                self.selectedIds = Set(cards.filter { $0.riskLevel == .low }.map { $0.id })
                self.isScanning = false
            }
        }
    }

    private func quarantineSelected() {
        let toQuarantine = selectedItems
        guard !toQuarantine.isEmpty else { return }
        let manager = quarantineManager
        let catRaw = selectedCategory.rawValue

        Task.detached(priority: .userInitiated) {
            do {
                let session = try await manager.quarantineItems(items: toQuarantine, ruleId: catRaw)
                await MainActor.run {
                    self.actionMessage = "Đã chuyển an toàn \(session.records.count) mục vào Kho Cách Ly SHA-256 (Phiên: \(session.id.uuidString.prefix(8)))."
                    let removedIds = Set(toQuarantine.map { $0.id })
                    self.items.removeAll { removedIds.contains($0.id) }
                    StorageCleanerScanCache.shared.cachedItems = self.items
                    self.selectedIds.removeAll()
                }
            } catch {
                await MainActor.run {
                    self.actionMessage = "Lỗi cách ly: \(error.localizedDescription)"
                }
            }
        }
    }

    private func deletePermanentlySelected() {
        let toDelete = selectedItems
        guard !toDelete.isEmpty else { return }
        let manager = quarantineManager

        Task.detached(priority: .userInitiated) {
            do {
                let res = try await manager.permanentlyDeleteItems(items: toDelete)
                await MainActor.run {
                    self.actionMessage = "Đã xóa vĩnh viễn \(res.deletedCount) mục (\(ByteCountFormatter.string(fromByteCount: res.freedBytes, countStyle: .file)))."
                    let removedIds = Set(toDelete.map { $0.id })
                    self.items.removeAll { removedIds.contains($0.id) }
                    StorageCleanerScanCache.shared.cachedItems = self.items
                    self.selectedIds.removeAll()
                }
            } catch {
                await MainActor.run {
                    self.actionMessage = "Lỗi xóa tệp: \(error.localizedDescription)"
                }
            }
        }
    }
}
