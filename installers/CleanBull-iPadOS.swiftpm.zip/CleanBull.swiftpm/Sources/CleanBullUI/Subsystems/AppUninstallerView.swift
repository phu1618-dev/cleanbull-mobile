import SwiftUI
import CleanBullCore
#if os(macOS)
import AppKit
#endif

/// Thông tin ứng dụng cài đặt
public struct AppEntryInfo: Identifiable, Sendable, Hashable, Equatable {
    public var id: String { bundleId }
    public let bundleId: String
    public let name: String
    public let version: String
    public let appPath: String?
    public let bundleSize: Int64
    public let isSystemApp: Bool
    public let leftovers: [EvidenceCardModel]

    public var leftoversSize: Int64 {
        leftovers.reduce(0) { $0 + $1.fileSize }
    }

    public var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: bundleSize, countStyle: .file)
    }

    public var formattedLeftoversSize: String {
        ByteCountFormatter.string(fromByteCount: leftoversSize, countStyle: .file)
    }
}

private final class AppUninstallerCache: @unchecked Sendable {
    static let shared = AppUninstallerCache()
    var cachedApps: [AppEntryInfo] = []
    var hasLoadedOnce: Bool = false
}

/// Phân hệ 5: Gỡ Ứng dụng Sạch & Rác Còn Sót (AppUninstaller)
/// Chạy hoàn toàn trên Task.detached(.utility) kèm bộ nhớ đệm 0ms và hiệu ứng chạm/chọn khối rõ nét.
public struct AppUninstallerView: View {
    @State private var apps: [AppEntryInfo] = []
    @State private var selectedApp: AppEntryInfo?
    @State private var selectedLeftoverIds: Set<UUID> = []
    @State private var hoveredBundleId: String? = nil
    @State private var searchQuery: String = ""
    @State private var isLoading: Bool = false
    @State private var actionMessage: String?

    private let leftoverFinder = AppLeftoverFinder()
    private let quarantineManager = QuarantineManager()

    public init() {}

    public var body: some View {
        HStack(spacing: 0) {
            // Cột 1: Danh sách ứng dụng
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 8) {
                            Text("Gỡ Ứng Dụng Sạch & Tệp Sót")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(BullTheme.textZinc900)
                            StatusBadgeView("Chạm vào khối ứng dụng để chọn", style: .emerald)
                        }
                        Text("Phát hiện tệp liên đới (Application Support, Caches, Preferences, Containers) của từng ứng dụng")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc600)
                    }
                    Spacer()
                    Button(action: {
                        AppLeftoverFinder.clearCache()
                        scanApps(force: true)
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.clockwise")
                            Text("Quét làm mới")
                        }
                        .font(.system(size: 12, weight: .semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.textZinc900)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                    .disabled(isLoading)
                }

                // Thanh tìm kiếm
                HStack(spacing: 6) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 12))
                        .foregroundColor(BullTheme.textZinc400)
                    TextField("Tìm ứng dụng theo tên hoặc Bundle ID...", text: $searchQuery)
                        .textFieldStyle(.plain)
                        .font(.system(size: 12))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(BullTheme.surfaceWhite)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                .cornerRadius(BullTheme.buttonRadius)

                if let msg = actionMessage {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(BullTheme.emerald700)
                        Text(msg)
                            .font(.system(size: 11.5, weight: .semibold))
                        Spacer()
                        Button("Đóng") { actionMessage = nil }
                            .font(.system(size: 11))
                            .buttonStyle(.plain)
                    }
                    .padding(9)
                    .background(BullTheme.emeraldBg)
                    .foregroundColor(BullTheme.emerald800)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.badgeRadius)
                }

                if isLoading {
                    VStack(spacing: 8) {
                        ProgressView()
                        Text("Đang quét nhanh dung lượng gói .app và tệp liên đới trên luồng nền...")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc600)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(filteredApps) { app in
                                appRowCard(app)
                            }
                        }
                        .padding(10)
                    }
                    .background(BullTheme.surfaceWhite)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                    .cornerRadius(BullTheme.cornerRadius)
                }
            }
            .padding(16)

            // Cột 2: Chi tiết ứng dụng & Tệp liên đới (Cho phép tích chọn từng khối tệp sót)
            if let app = selectedApp {
                Divider()
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Chi Tiết Ứng Dụng")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        Spacer()
                        StatusBadgeView("ĐANG CHỌN", style: .emerald)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Text(app.name)
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(BullTheme.emerald800)
                        Text("Bundle ID: \(app.bundleId)")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundColor(BullTheme.textZinc600)
                            .lineLimit(1)
                        Text("Phiên bản: \(app.version)")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc600)
                        Text("Dung lượng gói .app: \(app.formattedSize)")
                            .font(.system(size: 12, weight: .semibold))
                            .monospacedDigit()
                            .foregroundColor(BullTheme.textZinc900)
                        Text("Dung lượng tệp liên đới: \(app.formattedLeftoversSize)")
                            .font(.system(size: 12, weight: .bold))
                            .monospacedDigit()
                            .foregroundColor(BullTheme.emerald700)
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(BullTheme.emeraldBg.opacity(0.5))
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.cornerRadius)

                    HStack {
                        Text("Tệp Liên Đới (\(selectedLeftovers(for: app).count)/\(app.leftovers.count) đã chọn):")
                            .font(.system(size: 12.5, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        Spacer()
                        if !app.leftovers.isEmpty {
                            Button(selectedLeftoverIds.count == app.leftovers.count ? "Bỏ chọn" : "Chọn hết") {
                                if selectedLeftoverIds.count == app.leftovers.count {
                                    selectedLeftoverIds.removeAll()
                                } else {
                                    selectedLeftoverIds = Set(app.leftovers.map { $0.id })
                                }
                            }
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(BullTheme.emerald700)
                            .buttonStyle(.plain)
                        }
                    }

                    if app.leftovers.isEmpty {
                        Text("Không phát hiện tệp rác liên đới nào.")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc400)
                            .padding(.vertical, 10)
                    } else {
                        ScrollView {
                            VStack(spacing: 8) {
                                ForEach(app.leftovers) { leftover in
                                    EvidenceCardView(
                                        item: leftover,
                                        isSelected: selectedLeftoverIds.contains(leftover.id),
                                        onToggleSelect: {
                                            if selectedLeftoverIds.contains(leftover.id) {
                                                selectedLeftoverIds.remove(leftover.id)
                                            } else {
                                                selectedLeftoverIds.insert(leftover.id)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer()

                    #if os(macOS)
                    if let path = app.appPath {
                        Button(action: {
                            NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
                        }) {
                            HStack(spacing: 6) {
                                Image(systemName: "folder")
                                Text("Xem Gói .app Trong Finder")
                            }
                            .font(.system(size: 12, weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(BullTheme.bgZinc100)
                            .foregroundColor(BullTheme.textZinc900)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                            .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)
                    }
                    #endif

                    if app.isSystemApp {
                        HStack {
                            Image(systemName: "lock.shield")
                            Text("Ứng dụng hệ thống được khóa bảo vệ an toàn.")
                        }
                        .font(.system(size: 11, weight: .semibold))
                        .padding(10)
                        .frame(maxWidth: .infinity)
                        .background(BullTheme.bgZinc100)
                        .foregroundColor(BullTheme.textZinc600)
                        .cornerRadius(BullTheme.cornerRadius)
                    } else if !app.leftovers.isEmpty {
                        let targets = selectedLeftovers(for: app)
                        Button(action: { quarantineLeftovers(app: app, items: targets) }) {
                            HStack(spacing: 5) {
                                Image(systemName: "archivebox.fill")
                                Text("Dọn & Cách Ly \(targets.count) Mục Đã Chọn")
                            }
                            .font(.system(size: 12, weight: .bold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(targets.isEmpty ? BullTheme.bgZinc200 : BullTheme.emerald600)
                            .foregroundColor(targets.isEmpty ? BullTheme.textZinc500 : .white)
                            .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)
                        .disabled(targets.isEmpty)
                    }
                }
                .frame(width: 365)
                .padding(16)
                .background(BullTheme.surfaceWhite)
            }
        }
        .background(BullTheme.bgZinc50)
        .onAppear {
            scanApps(force: !AppUninstallerCache.shared.hasLoadedOnce)
        }
    }

    private func appRowCard(_ app: AppEntryInfo) -> some View {
        let isSel = selectedApp?.bundleId == app.bundleId
        let isHov = hoveredBundleId == app.bundleId

        return HStack(spacing: 10) {
            Image(systemName: isSel ? "checkmark.circle.fill" : "app.fill")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald700 : BullTheme.textZinc400))

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(app.name)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(isSel ? BullTheme.emerald800 : BullTheme.textZinc900)
                        .lineLimit(1)

                    if app.isSystemApp {
                        StatusBadgeView("Hệ thống", style: .zinc)
                    }
                    if isSel {
                        StatusBadgeView("ĐANG CHỌN", style: .emerald)
                    }
                }
                Text(app.bundleId)
                    .font(.system(size: 10.5, design: .monospaced))
                    .foregroundColor(BullTheme.textZinc400)
                    .lineLimit(1)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 3) {
                Text(app.formattedSize)
                    .font(.system(size: 12.5, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(isSel ? BullTheme.emerald700 : BullTheme.textZinc900)

                if !app.leftovers.isEmpty {
                    StatusBadgeView("\(app.leftovers.count) tệp sót (\(app.formattedLeftoversSize))", style: .amber)
                }
            }
        }
        .padding(10)
        .background(isSel ? BullTheme.emeraldBg : (isHov ? BullTheme.bgZinc100.opacity(0.8) : BullTheme.surfaceWhite))
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: isSel ? 2.0 : (isHov ? 1.5 : 1.0))
        )
        .cornerRadius(BullTheme.cornerRadius)
        .contentShape(Rectangle())
        .onHover { h in
            withAnimation(.easeOut(duration: 0.12)) {
                hoveredBundleId = h ? app.bundleId : nil
            }
        }
        .onTapGesture {
            withAnimation(.easeOut(duration: 0.12)) {
                selectedApp = app
                selectedLeftoverIds = Set(app.leftovers.map { $0.id })
            }
        }
    }

    private func selectedLeftovers(for app: AppEntryInfo) -> [EvidenceCardModel] {
        app.leftovers.filter { selectedLeftoverIds.contains($0.id) }
    }

    private var filteredApps: [AppEntryInfo] {
        let q = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if q.isEmpty { return apps }
        return apps.filter {
            $0.name.lowercased().contains(q) || $0.bundleId.lowercased().contains(q)
        }
    }

    private func scanApps(force: Bool) {
        if !force && AppUninstallerCache.shared.hasLoadedOnce {
            let cached = AppUninstallerCache.shared.cachedApps
            self.apps = cached
            if self.selectedApp == nil, let first = cached.first {
                self.selectedApp = first
                self.selectedLeftoverIds = Set(first.leftovers.map { $0.id })
            }
            return
        }

        isLoading = true
        actionMessage = nil
        let finder = leftoverFinder

        Task.detached(priority: .utility) {
            var scannedMap: [String: AppEntryInfo] = [:]

            #if os(macOS)
            let appDirs = [
                URL(fileURLWithPath: "/Applications"),
                FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Applications")
            ]
            for dir in appDirs {
                guard let urls = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) else { continue }
                for url in urls.prefix(75) where url.pathExtension == "app" {
                    let name = url.deletingPathExtension().lastPathComponent
                    let bundle = Bundle(url: url)
                    let bundleId = bundle?.bundleIdentifier ?? "app.\(name.lowercased())"
                    let version = bundle?.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
                    let isSystem = bundleId.hasPrefix("com.apple.")
                    let realBundleSize = AppLaunchTracker.calculateBundleSize(at: url)
                    let leftovers = finder.findLeftovers(bundleIdentifier: bundleId, appName: name)

                    scannedMap[bundleId] = AppEntryInfo(
                        bundleId: bundleId,
                        name: name,
                        version: version,
                        appPath: url.path,
                        bundleSize: realBundleSize,
                        isSystemApp: isSystem,
                        leftovers: leftovers
                    )
                }
            }
            #endif

            let scannedList = Array(scannedMap.values).sorted { lhs, rhs in
                if lhs.leftoversSize != rhs.leftoversSize {
                    return lhs.leftoversSize > rhs.leftoversSize
                }
                return lhs.bundleSize > rhs.bundleSize
            }

            AppUninstallerCache.shared.cachedApps = scannedList
            AppUninstallerCache.shared.hasLoadedOnce = true

            await MainActor.run {
                self.apps = scannedList
                if let first = scannedList.first {
                    self.selectedApp = first
                    self.selectedLeftoverIds = Set(first.leftovers.map { $0.id })
                }
                self.isLoading = false
            }
        }
    }

    private func quarantineLeftovers(app: AppEntryInfo, items: [EvidenceCardModel]) {
        guard !items.isEmpty else { return }
        let manager = quarantineManager
        Task.detached(priority: .userInitiated) {
            do {
                let session = try await manager.quarantineItems(items: items, ruleId: "app_leftover")
                AppLeftoverFinder.clearCache()
                await MainActor.run {
                    self.actionMessage = "Đã chuyển \(session.records.count) tệp liên đới của '\(app.name)' vào Kho Cách Ly SHA-256."
                    self.scanApps(force: true)
                }
            } catch {
                await MainActor.run {
                    self.actionMessage = "Lỗi cách ly: \(error.localizedDescription)"
                }
            }
        }
    }
}
