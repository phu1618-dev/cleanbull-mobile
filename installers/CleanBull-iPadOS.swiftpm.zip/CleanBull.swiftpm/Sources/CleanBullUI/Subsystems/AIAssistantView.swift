import SwiftUI
import CleanBullCore

/// Phân hệ 3: Trợ lý AI Dọn dẹp & Khiên Bảo Mật (AIAssistant)
public struct AIAssistantView: View {
    public struct ChatEntry: Identifiable {
        public let id = UUID()
        public let isUser: Bool
        public let text: String
        public let intent: AIScanIntent?
        public let results: [EvidenceCardModel]
    }

    @State private var messages: [ChatEntry] = [
        ChatEntry(
            isUser: false,
            text: "Chào bạn! Tôi là Trợ lý AI của CleanBull. Bạn có thể ra lệnh bằng tiếng Việt tự nhiên (ví dụ: 'Tìm video > 200MB trong Downloads', 'Dọn cache và log ứng dụng', hoặc 'Bật khiên VPN chống theo dõi').",
            intent: nil,
            results: []
        )
    ]
    @State private var inputText: String = ""
    @State private var isProcessing: Bool = false

    private let assistantService = AIAssistantService()

    public init() {}

    public var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Trợ Lý AI Dọn Dẹp & Bảo Mật")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)
                    Text("Bóc tách câu lệnh tiếng Việt cục bộ trên thiết bị — Không gửi dữ liệu ra ngoài")
                        .font(.system(size: 12))
                        .foregroundColor(BullTheme.textZinc600)
                }
                Spacer()
                StatusBadgeView("NLP Nội Bộ", style: .emerald)
            }
            .padding(16)
            .background(BullTheme.surfaceWhite)
            .overlay(Divider(), alignment: .bottom)

            // Message Stream
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 14) {
                        ForEach(messages) { msg in
                            chatBubble(msg)
                        }

                        if isProcessing {
                            HStack(spacing: 6) {
                                ProgressView()
                                    .scaleEffect(0.8)
                                Text("Đang phân tích ý định và quét dữ liệu...")
                                    .font(.system(size: 12))
                                    .foregroundColor(BullTheme.textZinc600)
                            }
                            .padding(10)
                            .background(BullTheme.surfaceWhite)
                            .cornerRadius(BullTheme.cornerRadius)
                        }
                    }
                    .padding(16)
                }
            }

            // Input Bar
            HStack(spacing: 8) {
                TextField("Nhập câu lệnh dọn dẹp hoặc bảo mật mạng...", text: $inputText)
                    .textFieldStyle(.plain)
                    .font(.system(size: 13))
                    .padding(10)
                    .background(BullTheme.surfaceWhite)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                    .cornerRadius(BullTheme.cornerRadius)
                    .onSubmit {
                        submitQuery()
                    }

                Button(action: submitQuery) {
                    Text("Gửi lệnh")
                        .font(.system(size: 13, weight: .medium))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(BullTheme.textZinc900)
                        .foregroundColor(BullTheme.surfaceWhite)
                        .cornerRadius(BullTheme.cornerRadius)
                }
                .buttonStyle(.plain)
                .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isProcessing)
            }
            .padding(12)
            .background(BullTheme.bgZinc100)
            .overlay(Divider(), alignment: .top)
        }
        .background(BullTheme.bgZinc50)
    }

    private func chatBubble(_ msg: ChatEntry) -> some View {
        HStack {
            if msg.isUser { Spacer() }

            VStack(alignment: msg.isUser ? .trailing : .leading, spacing: 8) {
                Text(msg.text)
                    .font(.system(size: 13))
                    .foregroundColor(msg.isUser ? BullTheme.surfaceWhite : BullTheme.textZinc900)
                    .padding(12)
                    .background(msg.isUser ? BullTheme.textZinc900 : BullTheme.surfaceWhite)
                    .overlay(
                        RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                            .stroke(msg.isUser ? BullTheme.textZinc900 : BullTheme.bgZinc200, lineWidth: 1)
                    )
                    .cornerRadius(BullTheme.cornerRadius)

                if let intent = msg.intent {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Ý định đã nhận diện: \(intent.intentDescription)")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(BullTheme.textZinc900)

                        if let vpn = intent.vpnAction {
                            Text("Lệnh VPN: \(String(describing: vpn))")
                                .font(.system(size: 11))
                                .foregroundColor(BullTheme.emeraldText)
                        } else {
                            Text("Mục tiêu: \(intent.targetDirectories.map { $0.lastPathComponent }.joined(separator: ", ")) | Tối thiểu: \(ByteCountFormatter.string(fromByteCount: intent.minSizeBytes, countStyle: .file)) | Độ cũ: >\(intent.minAgeDays) ngày")
                                .font(.system(size: 11))
                                .foregroundColor(BullTheme.textZinc600)
                        }
                    }
                    .padding(10)
                    .background(BullTheme.bgZinc100)
                    .cornerRadius(BullTheme.cornerRadius)
                }

                if !msg.results.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Phát hiện \(msg.results.count) mục phù hợp:")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)

                        ForEach(msg.results.prefix(5)) { card in
                            EvidenceCardView(item: card)
                        }
                    }
                }
            }

            if !msg.isUser { Spacer() }
        }
    }

    private func submitQuery() {
        let q = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }

        inputText = ""
        messages.append(ChatEntry(isUser: true, text: q, intent: nil, results: []))
        isProcessing = true

        Task {
            let intent = assistantService.parseQueryIntent(q)
            var cards: [EvidenceCardModel] = []
            var reply = "Đã phân tích câu lệnh của bạn."

            if let vpn = intent.vpnAction {
                switch vpn {
                case .enable: reply = "Đã kích hoạt Khiên VPN bảo vệ mạng."
                case .disable: reply = "Đã ngắt Khiên VPN."
                case .switchMode(let m): reply = "Đã chuyển sang Chế độ VPN \(m)."
                case .checkDomain(let d): reply = "Đã kiểm tra tên miền '\(d)'."
                }
            } else {
                cards = await assistantService.executeAIScan(intent: intent)
                reply = cards.isEmpty
                    ? "Không tìm thấy tệp nào phù hợp với tiêu chí đã nêu."
                    : "Tìm thấy \(cards.count) mục phù hợp. Bạn có thể kiểm tra Thẻ Bằng Chứng bên dưới."
            }

            await MainActor.run {
                self.messages.append(ChatEntry(
                    isUser: false,
                    text: reply,
                    intent: intent,
                    results: cards
                ))
                self.isProcessing = false
            }
        }
    }
}
