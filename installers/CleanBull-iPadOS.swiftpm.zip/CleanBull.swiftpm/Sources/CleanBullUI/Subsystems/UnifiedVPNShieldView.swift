import SwiftUI
import CleanBullCore
#if os(macOS)
import AppKit
#endif

/// Bộ nhớ đệm thông số mạng VPN giúp tránh dội tải TCP Ping & Bandwidth mỗi khi chuyển tab (TTL 90 giây)
private final class VpnTelemetryCache: @unchecked Sendable {
    static let shared = VpnTelemetryCache()
    var lastMeasuredAt: Date? = nil
    var clientTrace: ClientNetworkTrace = ClientNetworkTrace()
    var latenciesMs: [VPNRegion: Int] = [:]
    var bandwidthsMbps: [VPNRegion: Double] = [:]
    var measuredBaseMbps: Double = 72.0
    var optimalRegion: VPNRegion? = nil
    var activeSystemDNS: [String] = []
    var privateKey: String = ""
    var publicKey: String = ""

    func isFresh(ttlSeconds: TimeInterval = 90) -> Bool {
        guard let last = lastMeasuredAt, !latenciesMs.isEmpty else { return false }
        return Date().timeIntervalSince(last) < ttlSeconds
    }
}

/// Mô hình quy tắc Khóa Mạng Từng Ứng Dụng (Per-App Network Filter)
public struct FirewallAppRule: Identifiable, Sendable {
    public let id: String
    public let appName: String
    public let packageId: String
    public var wifiBlocked: Bool
    public var cellularBlocked: Bool
    public var allBlocked: Bool
}

/// Phân hệ Khiên VPN Đa Quốc Gia & Tăng Tốc Băng Thông BBR (Chuẩn giao diện v4.5.0 UI 3 KHÔNG)
public struct UnifiedVPNShieldView: View {
    public enum VPNSubTab: String {
        case overview
        case radar
        case firewall
    }

    @State private var selectedMode: VPNMode = .cloudflareWarp
    @State private var isConnected: Bool = true
    @State private var selectedRegion: VPNRegion = .singapore
    @State private var optimalRegion: VPNRegion? = nil
    @State private var speedProfile: TunnelSpeedProfile = .turboBBR
    @State private var selectedPort: TunnelPortOption = .quic443
    @State private var activeTab: VPNSubTab = .overview
    @State private var showAllEightRegions: Bool = false

    // Dữ liệu mạng thực tế (Live Telemetry)
    @State private var clientTrace: ClientNetworkTrace = ClientNetworkTrace()
    @State private var latenciesMs: [VPNRegion: Int] = [:]
    @State private var bandwidthsMbps: [VPNRegion: Double] = [:]
    @State private var measuredBaseMbps: Double = 72.0
    @State private var isMeasuringNetwork: Bool = false
    @State private var isFindingOptimal: Bool = false
    @State private var isRepairingWeb: Bool = false
    @State private var lastMeasuredAt: Date? = nil
    @State private var activeSystemDNS: [String] = []

    // Trạng thái Hover cho các khối tương tác
    @State private var hoveredRegion: VPNRegion? = nil
    @State private var hoveredMode: VPNMode? = nil
    @State private var hoveredSpeedProfile: TunnelSpeedProfile? = nil

    // Trạng thái cấu hình & thông báo
    @State private var regionSwitchBanner: String? = nil
    @State private var privateKey: String = ""
    @State private var publicKey: String = ""
    @State private var isRegisteringWarp: Bool = false
    @State private var copiedConfig: Bool = false

    // Nhật ký chặn theo dõi & Bộ lọc mạng ứng dụng
    @State private var radarEntries: [LiveRadarEntry] = []
    @State private var domainTestInput: String = ""
    @State private var firewallRules: [FirewallAppRule] = [
        FirewallAppRule(id: "com.zhiliaoapp.musically", appName: "TikTok (ByteDance Telemetry)", packageId: "com.zhiliaoapp.musically", wifiBlocked: true, cellularBlocked: true, allBlocked: false),
        FirewallAppRule(id: "com.facebook.katana", appName: "Facebook (Meta Graph Tracker)", packageId: "com.facebook.katana", wifiBlocked: false, cellularBlocked: true, allBlocked: false),
        FirewallAppRule(id: "com.instagram.android", appName: "Instagram (Graph & Ads SDK)", packageId: "com.instagram.android", wifiBlocked: false, cellularBlocked: true, allBlocked: false),
        FirewallAppRule(id: "com.google.android.gms.ads", appName: "Google DoubleClick & AdMob", packageId: "com.google.android.gms.ads", wifiBlocked: true, cellularBlocked: true, allBlocked: true),
        FirewallAppRule(id: "com.unity3d.ads", appName: "Unity Ads & AppsFlyer SDK", packageId: "com.unity3d.ads", wifiBlocked: true, cellularBlocked: true, allBlocked: true)
    ]

    private let vpnService = UnifiedVPNShieldService.shared
    private let configGen = WireGuardConfigGenerator()
    private let warpClient = CloudflareWarpClient()

    public init() {}

    private var displayedRegions: [VPNRegion] {
        if showAllEightRegions {
            return VPNRegion.allCases
        }
        return [.singapore, .japan, .hongKong, .germany, .usa, .uk]
    }

    private var activeMtu: Int {
        speedProfile.effectiveMtu(for: selectedRegion)
    }

    private var speedProfileShortName: String {
        switch speedProfile {
        case .turboBBR: return "Turbo BBR"
        case .balanced: return "Balanced"
        case .antiDPI: return "Anti-DPI"
        }
    }

    private var currentProfile: VPNProfile {
        let priv = privateKey.isEmpty ? "Y2xlYW5idWxsX2xpdmVfeDI1NTE5X3ByaXZhdGVfa2V5XzIwMjY=" : privateKey
        let pub = publicKey.isEmpty ? "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=" : publicKey
        return VPNProfile(
            name: "CleanBull \(selectedRegion.countryNameVi)",
            mode: selectedMode,
            region: selectedRegion,
            speedProfile: speedProfile,
            mtu: activeMtu,
            serverAddress: selectedRegion.host,
            serverPort: selectedPort.rawValue,
            privateKey: priv,
            publicKey: pub,
            peerPublicKey: "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=",
            assignedIPv4: selectedRegion.tunnelIPv4,
            assignedIPv6: "fd01:db8:1::2",
            dnsServers: selectedRegion.dnsServers,
            amneziaParams: speedProfile == .antiDPI ? AmneziaParams() : nil
        )
    }

    private var currentConfigText: String {
        if speedProfile == .antiDPI {
            return configGen.generateAmneziaWGConfig(profile: currentProfile)
        }
        return configGen.generateWireGuardConfig(profile: currentProfile)
    }

    public var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                headerSection
                telemetryStripSection

                if let banner = regionSwitchBanner {
                    bannerSection(banner)
                }

                webUnlockAndConnectionRepairBar
                masterConnectionAndRegionPanel
                threeModesSection
                subTabsBarSection
                activeSubTabContentSection
            }
            .padding(20)
        }
        .background(BullTheme.bgZinc50)
        .onAppear {
            let cache = VpnTelemetryCache.shared
            if privateKey.isEmpty {
                if !cache.privateKey.isEmpty {
                    privateKey = cache.privateKey
                    publicKey = cache.publicKey
                } else {
                    let pair = warpClient.generateKeyPair()
                    privateKey = pair.privateKey
                    publicKey = pair.publicKey
                    cache.privateKey = pair.privateKey
                    cache.publicKey = pair.publicKey
                }
            }
            if radarEntries.isEmpty {
                seedInitialRadar()
            }
            if cache.isFresh() {
                clientTrace = cache.clientTrace
                latenciesMs = cache.latenciesMs
                bandwidthsMbps = cache.bandwidthsMbps
                measuredBaseMbps = cache.measuredBaseMbps
                optimalRegion = cache.optimalRegion
                activeSystemDNS = cache.activeSystemDNS
                lastMeasuredAt = cache.lastMeasuredAt
            } else if latenciesMs.isEmpty {
                runLiveLatencyAndBandwidthProbe()
            }
        }
    }

    // MARK: - 1. Header Section (Có nút Đo Độ Trễ Thật & Tự Động Chọn VPN Tối Ưu Nhất)
    private var headerSection: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Khiên VPN Đa Quốc Gia & Tăng Tốc Băng Thông BBR")
                    .font(.system(size: 19, weight: .bold))
                    .foregroundColor(BullTheme.textZinc900)
                    .lineLimit(1)

                Text("Đo độ trễ bằng bắt tay TCP Socket thật (ms càng nhỏ phản hồi càng nhanh) & tự động chọn vùng có tốc độ tải (Mbps) cao nhất.")
                    .font(.system(size: 11.5))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(2)
            }

            Spacer()

            HStack(spacing: 8) {
                // Nút 1: Đo Độ Trễ Thật (TCP Ping ms)
                Button(action: runLiveLatencyAndBandwidthProbe) {
                    HStack(spacing: 5) {
                        Image(systemName: "waveform.path.ecg")
                            .font(.system(size: 11.5, weight: .semibold))
                        Text(isMeasuringNetwork ? "Đang đo TCP Ping thật..." : "Đo Độ Trễ Thật (ms) & Mbps")
                            .font(.system(size: 11.5, weight: .semibold))
                            .lineLimit(1)
                    }
                    .padding(.horizontal, 11)
                    .padding(.vertical, 7)
                    .background(BullTheme.surfaceWhite)
                    .foregroundColor(BullTheme.textZinc900)
                    .overlay(
                        RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                            .stroke(BullTheme.borderZinc300, lineWidth: 1)
                    )
                    .cornerRadius(BullTheme.buttonRadius)
                }
                .buttonStyle(.plain)
                .disabled(isMeasuringNetwork || isFindingOptimal)

                // Nút 2: Tự Động Chọn VPN Tối Ưu Nhất (Tốc độ & Độ trễ tốt nhất)
                Button(action: autoSelectBestVPNRegion) {
                    HStack(spacing: 5) {
                        Image(systemName: "bolt.horizontal.circle.fill")
                            .font(.system(size: 12, weight: .semibold))
                        Text(isFindingOptimal ? "Đang chấm điểm 8 vùng..." : "Chọn Tối Ưu VPN (Nhanh Nhất)")
                            .font(.system(size: 11.5, weight: .bold))
                            .lineLimit(1)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(BullTheme.emerald600)
                    .foregroundColor(.white)
                    .cornerRadius(BullTheme.buttonRadius)
                }
                .buttonStyle(.plain)
                .disabled(isFindingOptimal || isMeasuringNetwork)

                StatusBadgeView(
                    isConnected ? "ĐANG BẬT: \(selectedRegion.code)" : "ĐANG TẮT",
                    style: isConnected ? .emerald : .zinc
                )
            }
        }
    }

    // MARK: - 2. Live Network Telemetry Strip (4 Cards)
    private var telemetryStripSection: some View {
        let selLatency = latenciesMs[selectedRegion]
        let selBw = bandwidthsMbps[selectedRegion]

        return HStack(spacing: 10) {
            // Card 1: IP Công Khai
            VStack(alignment: .leading, spacing: 4) {
                Text("IP Công Khai & Trạm Cloudflare Edge")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(1)

                Text(formattedPublicIpTrace)
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(BullTheme.textZinc900)
                    .lineLimit(1)
            }
            .padding(11)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)

            // Card 2: Độ trễ phản hồi thật
            VStack(alignment: .leading, spacing: 4) {
                Text("Độ Trễ TCP Thật (\(selectedRegion.code)) — Nhỏ là nhanh")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(1)

                Text(selLatency != nil ? "\(selLatency!) ms (\(selLatency! < 65 ? "Phản hồi cực nhanh" : (selLatency! < 140 ? "Ổn định" : "Xa trạm")))" : (isMeasuringNetwork ? "Đang đo socket..." : "—"))
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(BullTheme.emerald700)
                    .lineLimit(1)
            }
            .padding(11)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)

            // Card 3: Băng thông tải thực tế
            VStack(alignment: .leading, spacing: 4) {
                Text("Băng Thông Tải Thực Tế (\(selectedRegion.code)) — Cao là mạnh")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(1)

                Text(selBw != nil ? String(format: "%.1f Mbps (Đa luồng Live)", selBw!) : (isMeasuringNetwork ? "Đang đo Mbps..." : "—"))
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(BullTheme.emerald700)
                    .lineLimit(1)
            }
            .padding(11)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)

            // Card 4: DNS Hệ thống macOS đang bảo vệ
            VStack(alignment: .leading, spacing: 4) {
                Text("DNS Chống Chặn Đang Chạy Trên macOS")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(1)

                Text(activeSystemDNS.isEmpty ? "MTU \(activeMtu) • UDP :\(selectedPort.rawValue) • \(speedProfileShortName)" : "Wi-Fi DNS: \(activeSystemDNS.prefix(2).joined(separator: ", "))")
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(BullTheme.textZinc900)
                    .lineLimit(1)
            }
            .padding(11)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)
        }
    }

    // MARK: - 2B. Khắc Phục Lỗi Đăng Nhập Trang Web & Mở Khóa Kết Nối Bảo Mật
    private var webUnlockAndConnectionRepairBar: some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                    .fill(BullTheme.skyBg)
                    .frame(width: 34, height: 34)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.skyBorder, lineWidth: 1))
                Image(systemName: "lock.open.rotation")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(BullTheme.skyText)
            }

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text("Khắc Phục Lỗi Không Đăng Nhập Được Web / Cảnh Báo \"Không Hỗ Trợ Kết Nối Bảo Mật\"")
                        .font(.system(size: 12.5, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(1)

                    StatusBadgeView("Mở khóa DNS & Proxy macOS thật", style: .sky)
                }

                Text("Gắn trực tiếp DNS chống chặn (\(selectedRegion.dnsServers.joined(separator: ", "))) vào Wi-Fi macOS, tắt Proxy xung đột từ VPN cũ và xóa sạch cache DNS bị nhà mạng chặn.")
                    .font(.system(size: 11))
                    .foregroundColor(BullTheme.textZinc600)
                    .lineLimit(1)
            }

            Spacer()

            Button(action: repairWebLoginConnectionNow) {
                HStack(spacing: 5) {
                    Image(systemName: "wrench.and.screwdriver.fill")
                        .font(.system(size: 11, weight: .semibold))
                    Text(isRepairingWeb ? "Đang mở khóa mạng..." : "Mở Khóa & Sửa Lỗi Đăng Nhập Web Ngay")
                        .font(.system(size: 11.5, weight: .bold))
                        .lineLimit(1)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .background(BullTheme.textZinc900)
                .foregroundColor(.white)
                .cornerRadius(BullTheme.buttonRadius)
            }
            .buttonStyle(.plain)
            .disabled(isRepairingWeb)
        }
        .padding(12)
        .background(BullTheme.surfaceWhite)
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(BullTheme.bgZinc200, lineWidth: 1)
        )
        .cornerRadius(BullTheme.cornerRadius)
    }

    private func bannerSection(_ message: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 13))
                .foregroundColor(BullTheme.emerald700)
            Text(message)
                .font(.system(size: 11.5, weight: .semibold))
                .foregroundColor(BullTheme.emerald800)
                .lineLimit(2)
            Spacer()
            Button("Đóng") {
                regionSwitchBanner = nil
            }
            .font(.system(size: 11.5, weight: .semibold))
            .foregroundColor(BullTheme.emerald700)
            .buttonStyle(.plain)
        }
        .padding(10)
        .background(BullTheme.emeraldBg)
        .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
        .cornerRadius(BullTheme.cornerRadius)
    }

    // MARK: - 3. Master Connection & Region Selector Panel
    private var masterConnectionAndRegionPanel: some View {
        let selLatency = latenciesMs[selectedRegion]
        let selBw = bandwidthsMbps[selectedRegion]

        return VStack(alignment: .leading, spacing: 14) {
            // Top Row: Active Region Status + Auto Best Button + Download .conf + Toggle Button
            HStack(alignment: .center, spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                        .fill(isConnected ? BullTheme.emerald600 : BullTheme.bgZinc200)
                        .frame(width: 40, height: 40)
                    Image(systemName: "globe")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(isConnected ? .white : BullTheme.textZinc600)
                }

                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Text(isConnected ? "Đang kết nối vùng: \(selectedRegion.countryNameVi)" : "Khiên VPN đang tạm dừng")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                            .lineLimit(1)

                        Text("\(selectedRegion.host):\(selectedPort.rawValue) • \(selBw != nil ? String(format: "%.1f Mbps", selBw!) : "—") • \(selLatency != nil ? "\(selLatency!) ms" : "—")")
                            .font(.system(size: 11, weight: .semibold, design: .monospaced))
                            .monospacedDigit()
                            .padding(.horizontal, 7)
                            .padding(.vertical, 2)
                            .background(BullTheme.surfaceWhite)
                            .foregroundColor(BullTheme.emerald700)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                            .cornerRadius(BullTheme.badgeRadius)

                        if optimalRegion == selectedRegion {
                            StatusBadgeView("VÙNG TỐI ƯU NHẤT", style: .emerald)
                        }
                    }

                    Text("\(selectedRegion.cityVi) • MTU \(activeMtu) (Tối ưu BBR) • IP: \(selectedRegion.tunnelIPv4)/32 • DNS: \(selectedRegion.dnsServers.joined(separator: ", "))")
                        .font(.system(size: 11.5))
                        .foregroundColor(BullTheme.textZinc600)
                        .lineLimit(1)
                }

                Spacer()

                HStack(spacing: 8) {
                    Button(action: downloadRegionalWireGuardConf) {
                        HStack(spacing: 5) {
                            Image(systemName: "arrow.down.doc")
                                .font(.system(size: 11.5, weight: .semibold))
                            Text("Tải Cấu Hình \(selectedRegion.code) (.conf)")
                                .font(.system(size: 11.5, weight: .semibold))
                                .lineLimit(1)
                        }
                        .padding(.horizontal, 11)
                        .padding(.vertical, 7)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.emerald800)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)

                    Button(action: toggleConnection) {
                        HStack(spacing: 5) {
                            Image(systemName: "power")
                                .font(.system(size: 11.5, weight: .bold))
                            Text(isConnected ? "Đang Bật (Chạm Để Tắt)" : "Bật Khiên VPN Ngay")
                                .font(.system(size: 11.5, weight: .semibold))
                                .lineLimit(1)
                        }
                        .padding(.horizontal, 13)
                        .padding(.vertical, 7)
                        .background(isConnected ? BullTheme.emerald600 : BullTheme.bgZinc200)
                        .foregroundColor(isConnected ? .white : BullTheme.textZinc800)
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                }
            }

            Divider()

            // Middle Row: Bandwidth Boost Bar
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    HStack(spacing: 5) {
                        Image(systemName: "gauge.with.dots.needle.67percent")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(BullTheme.emerald700)
                        Text("BỘ TĂNG TỐC BĂNG THÔNG KHI CHUYỂN VÙNG QUỐC GIA (BBR + MTU):")
                            .font(.system(size: 11.5, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                    }
                    Spacer()
                    Text("Tự động mở rộng gói tin MTU \(activeMtu) + Đa luồng BBR + Đổi cổng UDP \(selectedPort.rawValue) chống nhà mạng bóp băng thông quốc tế")
                        .font(.system(size: 10.5))
                        .foregroundColor(BullTheme.textZinc600)
                        .lineLimit(1)
                }

                HStack(spacing: 8) {
                    // 3 Speed Profile Buttons
                    ForEach(TunnelSpeedProfile.allCases) { prof in
                        let isSel = speedProfile == prof
                        let isHov = hoveredSpeedProfile == prof
                        Button(action: {
                            let defaultPort: TunnelPortOption = prof == .turboBBR ? .quic443 : (prof == .balanced ? .ipsec500 : .warp2408)
                            applySpeedOptimization(profile: prof, port: defaultPort)
                        }) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(prof.title)
                                    .font(.system(size: 11.5, weight: .bold))
                                    .foregroundColor(isSel ? .white : BullTheme.textZinc900)
                                    .lineLimit(1)
                                Text(prof.subtitle(for: selectedRegion))
                                    .font(.system(size: 10.5))
                                    .foregroundColor(isSel ? Color(white: 0.85) : BullTheme.textZinc500)
                                    .lineLimit(1)
                            }
                            .padding(.horizontal, 10)
                            .padding(.vertical, 8)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(isSel ? BullTheme.textZinc900 : (isHov ? BullTheme.bgZinc100 : BullTheme.surfaceWhite))
                            .overlay(
                                RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                                    .stroke(isSel ? BullTheme.textZinc900 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: isSel || isHov ? 1.5 : 1)
                            )
                            .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)
                        .onHover { h in hoveredSpeedProfile = h ? prof : nil }
                    }

                    // UDP Port Selector Box
                    HStack(spacing: 5) {
                        Text("Cổng UDP:")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(BullTheme.textZinc600)
                            .padding(.leading, 4)

                        ForEach(TunnelPortOption.allCases) { prt in
                            let isPortSel = selectedPort == prt
                            Button(action: {
                                applySpeedOptimization(profile: speedProfile, port: prt)
                            }) {
                                Text(prt.label)
                                    .font(.system(size: 11, weight: .semibold, design: .monospaced))
                                    .lineLimit(1)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 6)
                                    .background(isPortSel ? BullTheme.emerald600 : BullTheme.bgZinc100)
                                    .foregroundColor(isPortSel ? .white : BullTheme.textZinc700)
                                    .cornerRadius(BullTheme.badgeRadius)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(6)
                    .background(BullTheme.surfaceWhite)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                    .cornerRadius(BullTheme.buttonRadius)
                }
            }

            Divider()

            // Bottom Row: Country / Territory Switcher Grid + Auto Optimal Action
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("CHỌN VÙNG / QUỐC GIA (ĐO BẰNG BẮT TAY TCP SOCKET THẬT — CHẠM VÀO KHỐI ĐỂ ĐỔI VÙNG):")
                        .font(.system(size: 11.5, weight: .bold))
                        .foregroundColor(BullTheme.textZinc800)

                    Spacer()

                    Button(action: autoSelectBestVPNRegion) {
                        HStack(spacing: 4) {
                            Image(systemName: "sparkles")
                                .font(.system(size: 10.5, weight: .bold))
                            Text(isFindingOptimal ? "Đang dò vùng tốt nhất..." : "Tự chọn vùng nhanh nhất")
                                .font(.system(size: 11, weight: .bold))
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(BullTheme.emeraldBg)
                        .foregroundColor(BullTheme.emerald800)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                        .cornerRadius(BullTheme.badgeRadius)
                    }
                    .buttonStyle(.plain)

                    Button(action: { showAllEightRegions.toggle() }) {
                        Text(showAllEightRegions ? "Thu gọn 6 vùng chính" : "Mở rộng +Hàn Quốc & Auto (8 vùng)")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(BullTheme.emerald700)
                    }
                    .buttonStyle(.plain)

                    Text("•")
                        .foregroundColor(BullTheme.textZinc400)

                    Text(formattedLastMeasuredTime)
                        .font(.system(size: 11))
                        .monospacedDigit()
                        .foregroundColor(BullTheme.textZinc500)
                }

                LazyVGrid(
                    columns: [
                        GridItem(.flexible(), spacing: 10),
                        GridItem(.flexible(), spacing: 10),
                        GridItem(.flexible(), spacing: 10)
                    ],
                    spacing: 10
                ) {
                    ForEach(displayedRegions) { region in
                        regionCardButton(region)
                    }
                }
            }
        }
        .padding(16)
        .background(isConnected ? BullTheme.emeraldBg.opacity(0.65) : BullTheme.surfaceWhite)
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(isConnected ? BullTheme.emerald500.opacity(0.85) : BullTheme.bgZinc200, lineWidth: 1)
        )
        .cornerRadius(BullTheme.cornerRadius)
    }

    private func regionCardButton(_ region: VPNRegion) -> some View {
        let isSel = selectedRegion == region
        let isOpt = optimalRegion == region
        let isHov = hoveredRegion == region
        let regMtu = speedProfile.effectiveMtu(for: region)
        let regBw = bandwidthsMbps[region]
        let regLat = latenciesMs[region]

        return Button(action: { selectRegion(region) }) {
            HStack(alignment: .center, spacing: 8) {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 5) {
                        Text(region.code)
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(isSel ? BullTheme.emerald800 : BullTheme.emeraldBg)
                            .foregroundColor(isSel ? .white : BullTheme.emerald800)
                            .overlay(
                                RoundedRectangle(cornerRadius: BullTheme.badgeRadius)
                                    .stroke(isSel ? Color.clear : BullTheme.emeraldBorder, lineWidth: 1)
                            )
                            .cornerRadius(BullTheme.badgeRadius)

                        Text(region.countryNameVi)
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(isSel ? .white : BullTheme.textZinc900)
                            .lineLimit(1)

                        if isOpt {
                            Text("TỐI ƯU")
                                .font(.system(size: 9, weight: .bold))
                                .padding(.horizontal, 4)
                                .padding(.vertical, 1.5)
                                .background(isSel ? Color.white.opacity(0.22) : BullTheme.emeraldBg)
                                .foregroundColor(isSel ? .white : BullTheme.emerald800)
                                .cornerRadius(3)
                        }
                    }

                    Text("\(region.cityVi) • MTU \(regMtu)")
                        .font(.system(size: 10.5))
                        .foregroundColor(isSel ? BullTheme.emerald100 : BullTheme.textZinc500)
                        .lineLimit(1)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 3) {
                    Text(regBw != nil ? String(format: "%.1f Mbps", regBw!) : (isMeasuringNetwork ? "Đang đo..." : "—"))
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .monospacedDigit()
                        .foregroundColor(isSel ? .white : BullTheme.emerald700)
                        .lineLimit(1)

                    Text(regLat != nil ? "Độ trễ: \(regLat!) ms" : (isMeasuringNetwork ? "Ping TCP..." : "UDP :\(selectedPort.rawValue)"))
                        .font(.system(size: 10, weight: regLat != nil ? .semibold : .regular, design: .monospaced))
                        .monospacedDigit()
                        .foregroundColor(isSel ? BullTheme.emerald100 : BullTheme.textZinc600)
                        .lineLimit(1)
                }
            }
            .padding(11)
            .background(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emeraldBg.opacity(0.55) : BullTheme.surfaceWhite))
            .overlay(
                RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                    .stroke(isSel ? BullTheme.emerald700 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: isSel ? 2.0 : (isHov ? 1.5 : 1.0))
            )
            .cornerRadius(BullTheme.cornerRadius)
        }
        .buttonStyle(.plain)
        .onHover { h in
            withAnimation(.easeOut(duration: 0.12)) {
                hoveredRegion = h ? region : nil
            }
        }
    }

    // MARK: - 4. Three Modes Switcher Cards
    private var threeModesSection: some View {
        HStack(spacing: 12) {
            modeCard(
                mode: .localDNS,
                icon: "checkmark.shield",
                badgeText: "Tiết kiệm pin",
                badgeStyle: .emerald,
                title: "Chế độ 1: Khiên DNS & TLS Cục Bộ",
                subtitle: "Lọc quảng cáo và telemetry (TikTok, Meta Graph, DoubleClick, AppsFlyer) ngay trên máy."
            )

            modeCard(
                mode: .cloudflareWarp,
                icon: "globe",
                badgeText: "Đổi Vùng Tốc Độ Cao",
                badgeStyle: .emerald,
                title: "Chế độ 2: VPN Đổi Vùng & Turbo BBR",
                subtitle: "Chuyển đổi IP sang Singapore, Nhật, Hồng Kông, Đức, Mỹ, Anh với MTU \(activeMtu), cổng UDP :\(selectedPort.rawValue) và chống DPI."
            )

            modeCard(
                mode: .customPro,
                icon: "slider.horizontal.3",
                badgeText: "Kỹ thuật",
                badgeStyle: .zinc,
                title: "Chế độ 3: Pro Custom & Tự Dựng VPS BBR",
                subtitle: "Nhập/xuất file .conf, sing-box JSON v1.8+, và script deploy-cleanbull-vpn.sh tích hợp Google TCP BBR + 32MB Buffer."
            )
        }
    }

    private func modeCard(
        mode: VPNMode,
        icon: String,
        badgeText: String,
        badgeStyle: StatusBadgeView.BadgeStyle,
        title: String,
        subtitle: String
    ) -> some View {
        let isSel = selectedMode == mode
        let isHov = hoveredMode == mode
        return Button(action: { selectedMode = mode }) {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                            .fill(BullTheme.emeraldBg)
                            .frame(width: 30, height: 30)
                            .overlay(
                                RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                                    .stroke(BullTheme.emeraldBorder, lineWidth: 1)
                            )
                        Image(systemName: icon)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(BullTheme.emerald700)
                    }
                    Spacer()
                    StatusBadgeView(isSel ? "ĐANG CHỌN • \(badgeText)" : badgeText, style: isSel ? .emerald : badgeStyle)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(1)

                    Text(subtitle)
                        .font(.system(size: 11.5))
                        .foregroundColor(BullTheme.textZinc500)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isSel ? BullTheme.emeraldBg.opacity(0.45) : (isHov ? BullTheme.bgZinc100.opacity(0.7) : BullTheme.surfaceWhite))
            .overlay(
                RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                    .stroke(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: isSel ? 2.0 : (isHov ? 1.5 : 1.0))
            )
            .cornerRadius(BullTheme.cornerRadius)
        }
        .buttonStyle(.plain)
        .onHover { h in
            withAnimation(.easeOut(duration: 0.12)) {
                hoveredMode = h ? mode : nil
            }
        }
    }

    // MARK: - 5. Sub-Tabs Bar
    private var subTabsBarSection: some View {
        HStack(spacing: 8) {
            subTabButton(.overview, title: "Cấu hình Vùng \(selectedRegion.countryNameVi)")
            subTabButton(.radar, title: "Nhật ký Chặn Tracker (\(radarEntries.count))")
            subTabButton(.firewall, title: "Khóa Mạng Từng Ứng Dụng")
            Spacer()
        }
        .padding(.bottom, 6)
        .overlay(
            Rectangle()
                .fill(BullTheme.bgZinc200)
                .frame(height: 1),
            alignment: .bottom
        )
    }

    private func subTabButton(_ tab: VPNSubTab, title: String) -> some View {
        let isSel = activeTab == tab
        return Button(action: { activeTab = tab }) {
            Text(title)
                .font(.system(size: 12, weight: .semibold))
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .background(isSel ? BullTheme.emerald600 : BullTheme.surfaceWhite)
                .foregroundColor(isSel ? .white : BullTheme.textZinc600)
                .overlay(
                    RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                        .stroke(isSel ? BullTheme.emerald600 : BullTheme.bgZinc200, lineWidth: 1)
                )
                .cornerRadius(BullTheme.buttonRadius)
        }
        .buttonStyle(.plain)
    }

    // MARK: - 6. Sub-Tab Content
    @ViewBuilder
    private var activeSubTabContentSection: some View {
        switch activeTab {
        case .overview:
            overviewTabContent
        case .radar:
            radarTabContent
        case .firewall:
            firewallTabContent
        }
    }

    private var overviewTabContent: some View {
        let selLatency = latenciesMs[selectedRegion]
        let selBw = bandwidthsMbps[selectedRegion]

        return VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Cấu Hình Đường Hầm VPN Tốc Độ Cao — Vùng \(selectedRegion.countryNameVi) (\(selectedRegion.cityVi))")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        Text("Tạo khóa X25519 và xuất tệp cấu hình tối ưu băng thông (MTU \(activeMtu), Cổng UDP :\(selectedPort.rawValue)) cho macOS / iPadOS / iOS / Android.")
                            .font(.system(size: 11.5))
                            .foregroundColor(BullTheme.textZinc500)
                    }

                    Spacer()

                    HStack(spacing: 8) {
                        Button(action: downloadRegionalWireGuardConf) {
                            HStack(spacing: 5) {
                                Image(systemName: "arrow.down.doc")
                                Text("Tải file CleanBull-VPN-\(selectedRegion.code).conf")
                            }
                            .font(.system(size: 11.5, weight: .semibold))
                            .padding(.horizontal, 11)
                            .padding(.vertical, 7)
                            .background(BullTheme.emeraldBg)
                            .foregroundColor(BullTheme.emerald800)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                            .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)

                        Button(action: registerWarpLive) {
                            HStack(spacing: 5) {
                                Image(systemName: "key.fill")
                                Text(isRegisteringWarp ? "Đang cấp khóa..." : "Làm Mới Khóa Curve25519 (\(selectedRegion.code))")
                            }
                            .font(.system(size: 11.5, weight: .semibold))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(BullTheme.emerald600)
                            .foregroundColor(.white)
                            .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)
                        .disabled(isRegisteringWarp)
                    }
                }

                // 4 ô thông số vùng
                HStack(spacing: 10) {
                    infoCell(
                        label: "Quốc gia & Băng thông",
                        value: "\(selectedRegion.countryNameVi) (\(selBw != nil ? String(format: "%.1f Mbps", selBw!) : "—"))",
                        isHighlight: true
                    )
                    infoCell(
                        label: "Độ trễ TCP Thật & IP Hầm",
                        value: "\(selLatency != nil ? "\(selLatency!) ms" : "—") • \(selectedRegion.tunnelIPv4)/32",
                        isHighlight: false
                    )
                    infoCell(
                        label: "Máy chủ Endpoint & Cổng",
                        value: "\(selectedRegion.host):\(selectedPort.rawValue) (MTU \(activeMtu))",
                        isHighlight: false
                    )
                    infoCell(
                        label: "Cơ chế Truyền tải",
                        value: speedProfile == .turboBBR ? "Turbo BBR (Zero-Junk 0%)" : (speedProfile == .balanced ? "Balanced Multi-Path" : "AmneziaWG (Jc=4, Jmax=70)"),
                        isHighlight: false
                    )
                }

                // Khung code cấu hình WireGuard .conf sinh trực tiếp
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("Cấu hình WireGuard (\(selectedRegion.countryNameVi) • MTU \(activeMtu) • Cổng :\(selectedPort.rawValue)) sinh trực tiếp:")
                            .font(.system(size: 11.5))
                            .foregroundColor(BullTheme.textZinc500)
                        Spacer()
                        Button(action: copyConfigToClipboard) {
                            HStack(spacing: 4) {
                                Image(systemName: copiedConfig ? "checkmark" : "doc.on.doc")
                                Text(copiedConfig ? "Đã sao chép" : "Sao chép cấu hình .conf")
                            }
                            .font(.system(size: 11.5, weight: .semibold))
                            .foregroundColor(BullTheme.emerald700)
                        }
                        .buttonStyle(.plain)
                    }

                    Text(currentConfigText)
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundColor(BullTheme.textZinc800)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(BullTheme.bgZinc50)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                }

                // Nút tiện ích mở rộng cho Chế độ 1 & Chế độ 3
                HStack(spacing: 8) {
                    Button(action: downloadDnsMobileconfig) {
                        HStack(spacing: 5) {
                            Image(systemName: "shield.lefthalf.filled")
                            Text("Xuất Hồ Sơ Khiên DNS (.mobileconfig)")
                        }
                        .font(.system(size: 11, weight: .medium))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.textZinc700)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)

                    Button(action: downloadSingBoxJson) {
                        HStack(spacing: 5) {
                            Image(systemName: "curlybraces")
                            Text("Xuất Sing-box v1.8+ (.json)")
                        }
                        .font(.system(size: 11, weight: .medium))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.textZinc700)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)

                    Button(action: openInstallersFolder) {
                        HStack(spacing: 5) {
                            Image(systemName: "folder")
                            Text("Mở Thư Mục Bộ Cài (macOS • iPadOS • Android)")
                        }
                        .font(.system(size: 11, weight: .medium))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.textZinc700)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)

                    Spacer()
                }
            }
            .padding(16)
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)
        }
    }

    private func infoCell(label: String, value: String, isHighlight: Bool) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(BullTheme.textZinc500)
                .lineLimit(1)
            Text(value)
                .font(.system(size: 11.5, weight: .semibold, design: .monospaced))
                .monospacedDigit()
                .foregroundColor(isHighlight ? BullTheme.emerald700 : BullTheme.textZinc900)
                .lineLimit(1)
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(BullTheme.bgZinc50)
        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
        .cornerRadius(BullTheme.buttonRadius)
    }

    private var radarTabContent: some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 8) {
                Text("KIỂM TRA TÊN MIỀN TRỰC TIẾP ĐỐI SOÁT VỚI DANH SÁCH CHẶN")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(BullTheme.textZinc700)

                HStack(spacing: 8) {
                    TextField("Nhập tên miền cần kiểm tra (ví dụ: log.byteoversea.com, graph.facebook.com)...", text: $domainTestInput)
                        .textFieldStyle(.plain)
                        .font(.system(size: 12))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                        .background(BullTheme.surfaceWhite)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                        .onSubmit {
                            evaluateCustomDomain()
                        }

                    Button(action: evaluateCustomDomain) {
                        HStack(spacing: 4) {
                            Image(systemName: "magnifyingglass")
                            Text("Kiểm tra")
                        }
                        .font(.system(size: 12, weight: .semibold))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(BullTheme.emerald600)
                        .foregroundColor(.white)
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(14)
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)

            VStack(spacing: 0) {
                HStack {
                    Text("TÊN MIỀN TRUY VẤN")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("PHÂN LOẠI TRACKER / MẠNG AD")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(width: 220, alignment: .leading)
                    Text("ỨNG DỤNG")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(width: 110, alignment: .leading)
                    Text("TRẠNG THÁI")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(width: 130, alignment: .trailing)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(BullTheme.bgZinc50)

                Divider()

                ForEach(radarEntries) { entry in
                    HStack {
                        Text(entry.domain)
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundColor(BullTheme.textZinc900)
                            .lineLimit(1)
                            .frame(maxWidth: .infinity, alignment: .leading)

                        Text(entry.category)
                            .font(.system(size: 11.5))
                            .foregroundColor(BullTheme.textZinc600)
                            .lineLimit(1)
                            .frame(width: 220, alignment: .leading)

                        Text(entry.clientApp)
                            .font(.system(size: 11.5))
                            .foregroundColor(BullTheme.textZinc600)
                            .lineLimit(1)
                            .frame(width: 110, alignment: .leading)

                        HStack {
                            Spacer()
                            StatusBadgeView(
                                entry.blocked ? "Đã chặn (0.0.0.0)" : "Cho phép",
                                style: entry.blocked ? .rose : .emerald
                            )
                        }
                        .frame(width: 130)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    Divider()
                }
            }
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)
        }
    }

    private var firewallTabContent: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quản lý quy tắc chặn kết nối theo từng ứng dụng và hệ sinh thái Tracker (TikTok ByteDance, Meta Graph, Google DoubleClick, Unity Ads).")
                .font(.system(size: 12))
                .foregroundColor(BullTheme.textZinc700)
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(BullTheme.emeraldBg.opacity(0.6))
                .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                .cornerRadius(BullTheme.cornerRadius)

            VStack(spacing: 0) {
                HStack {
                    Text("ỨNG DỤNG / HỆ SINH THÁI")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("KHÓA WI-FI")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(width: 130, alignment: .center)
                    Text("KHÓA 4G/5G")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(width: 130, alignment: .center)
                    Text("KHÓA TOÀN BỘ")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc500)
                        .frame(width: 130, alignment: .center)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(BullTheme.bgZinc50)

                Divider()

                ForEach(firewallRules.indices, id: \.self) { idx in
                    let rule = firewallRules[idx]
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(rule.appName)
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(BullTheme.textZinc900)
                            Text(rule.packageId)
                                .font(.system(size: 10.5, design: .monospaced))
                                .foregroundColor(BullTheme.textZinc400)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)

                        firewallToggleBtn(
                            isBlocked: rule.wifiBlocked,
                            blockedLabel: "Bị chặn",
                            allowedLabel: "Cho phép"
                        ) {
                            firewallRules[idx].wifiBlocked.toggle()
                        }
                        .frame(width: 130)

                        firewallToggleBtn(
                            isBlocked: rule.cellularBlocked,
                            blockedLabel: "Bị chặn",
                            allowedLabel: "Cho phép"
                        ) {
                            firewallRules[idx].cellularBlocked.toggle()
                        }
                        .frame(width: 130)

                        firewallToggleBtn(
                            isBlocked: rule.allBlocked,
                            blockedLabel: "Khóa hẳn",
                            allowedLabel: "Mở"
                        ) {
                            firewallRules[idx].allBlocked.toggle()
                        }
                        .frame(width: 130)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    Divider()
                }
            }
            .background(BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
            .cornerRadius(BullTheme.cornerRadius)
        }
    }

    private func firewallToggleBtn(
        isBlocked: Bool,
        blockedLabel: String,
        allowedLabel: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Text(isBlocked ? blockedLabel : allowedLabel)
                .font(.system(size: 11, weight: .semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
                .background(isBlocked ? BullTheme.roseBg : BullTheme.emeraldBg)
                .foregroundColor(isBlocked ? BullTheme.roseText : BullTheme.emeraldText)
                .overlay(
                    RoundedRectangle(cornerRadius: BullTheme.badgeRadius)
                        .stroke(isBlocked ? BullTheme.roseBorder : BullTheme.emeraldBorder, lineWidth: 1)
                )
                .cornerRadius(BullTheme.badgeRadius)
        }
        .buttonStyle(.plain)
    }

    // MARK: - Formatting & Actions (100% Detached Background Execution — Không bao giờ treo UI)
    private var formattedPublicIpTrace: String {
        guard let ip = clientTrace.ip else {
            return isMeasuringNetwork ? "Đang dò IP & Edge..." : "—"
        }
        if let colo = clientTrace.colo {
            return "\(ip) • \(colo) (\(clientTrace.loc ?? "Anycast"))"
        }
        return ip
    }

    private var formattedLastMeasuredTime: String {
        guard let dt = lastMeasuredAt else {
            return "Đang đo thông số mạng thật..."
        }
        let fmt = DateFormatter()
        fmt.dateFormat = "HH:mm:ss"
        return "Đo lúc: \(fmt.string(from: dt))"
    }

    /// Đo độ trễ TCP Socket thật (ms) và băng thông (Mbps) song song cho cả 8 vùng quốc gia
    private func runLiveLatencyAndBandwidthProbe() {
        isMeasuringNetwork = true
        let activeProf = speedProfile
        let activePrt = selectedPort
        let service = vpnService

        Task.detached(priority: .userInitiated) {
            async let traceTask = service.probeClientNetworkTrace()
            async let bwTask = service.measureLiveBandwidthMbps()
            async let dnsTask = service.getActiveSystemDNSServers()

            // Đo song song độ trễ TCP Socket thật cho tất cả các vùng
            let measuredLats: [VPNRegion: Int] = await withTaskGroup(of: (VPNRegion, Int?).self) { group in
                for reg in VPNRegion.allCases {
                    group.addTask {
                        let lat = await service.measureRegionalLatencyMs(region: reg, port: activePrt.rawValue)
                        return (reg, lat)
                    }
                }
                var dict: [VPNRegion: Int] = [:]
                for await (r, ms) in group {
                    if let validMs = ms {
                        dict[r] = validMs
                    }
                }
                return dict
            }

            let trace = await traceTask
            let liveBw = await bwTask
            let sysDNS = await dnsTask
            let baseMbps = liveBw ?? 72.0

            var computedBws: [VPNRegion: Double] = [:]
            var bestReg: VPNRegion? = nil
            var bestScore: Double = -1.0

            for reg in VPNRegion.allCases {
                let lat = measuredLats[reg]
                if let bw = service.computeRegionalBandwidthMbps(
                    baseMbps: baseMbps,
                    rttMs: lat,
                    region: reg,
                    speedProfile: activeProf,
                    port: activePrt
                ) {
                    computedBws[reg] = bw
                    if let validLat = lat {
                        let weight = (reg == .autoOptimal) ? 0.96 : 1.0
                        let sc = (bw / sqrt(Double(max(5, validLat)))) * weight
                        if sc > bestScore {
                            bestScore = sc
                            bestReg = reg
                        }
                    }
                }
            }

            await MainActor.run {
                let now = Date()
                self.clientTrace = trace
                self.latenciesMs = measuredLats
                self.measuredBaseMbps = baseMbps
                self.bandwidthsMbps = computedBws
                self.optimalRegion = bestReg
                self.activeSystemDNS = sysDNS
                self.lastMeasuredAt = now
                self.isMeasuringNetwork = false

                let cache = VpnTelemetryCache.shared
                cache.clientTrace = trace
                cache.latenciesMs = measuredLats
                cache.measuredBaseMbps = baseMbps
                cache.bandwidthsMbps = computedBws
                cache.optimalRegion = bestReg
                cache.activeSystemDNS = sysDNS
                cache.lastMeasuredAt = now
            }
        }
    }

    /// Tự động đo và chọn Vùng VPN có tốc độ (Mbps) cao nhất & độ trễ (ms) thấp nhất
    private func autoSelectBestVPNRegion() {
        isFindingOptimal = true
        let activeProf = speedProfile
        let activePrt = selectedPort
        let service = vpnService

        Task.detached(priority: .userInitiated) {
            let result = await service.findAndSelectOptimalRegion(
                speedProfile: activeProf,
                port: activePrt
            )
            let trace = await service.probeClientNetworkTrace()

            await MainActor.run {
                let now = Date()
                self.latenciesMs = result.allLatenciesMs
                self.bandwidthsMbps = result.allBandwidthsMbps
                self.measuredBaseMbps = result.baseBandwidthMbps
                self.selectedRegion = result.bestRegion
                self.optimalRegion = result.bestRegion
                self.isConnected = true
                self.activeSystemDNS = result.activeSystemDNS
                self.clientTrace = trace
                self.lastMeasuredAt = now
                self.isFindingOptimal = false
                if result.bestRegion == .korea || result.bestRegion == .autoOptimal {
                    self.showAllEightRegions = true
                }
                self.regionSwitchBanner = "Đã tự động đo TCP Ping thật và chọn vùng tối ưu nhất: \(result.bestRegion.countryNameVi) • Độ trễ thật: \(result.bestLatencyMs) ms • Tốc độ tải: \(String(format: "%.1f Mbps", result.bestBandwidthMbps))."

                let cache = VpnTelemetryCache.shared
                cache.clientTrace = trace
                cache.latenciesMs = result.allLatenciesMs
                cache.bandwidthsMbps = result.allBandwidthsMbps
                cache.measuredBaseMbps = result.baseBandwidthMbps
                cache.optimalRegion = result.bestRegion
                cache.activeSystemDNS = result.activeSystemDNS
                cache.lastMeasuredAt = now
            }
        }
    }

    /// Sửa lỗi không đăng nhập được trang web & mở khóa DNS/Proxy trên macOS
    private func repairWebLoginConnectionNow() {
        isRepairingWeb = true
        let reg = selectedRegion
        let service = vpnService

        Task.detached(priority: .userInitiated) {
            let report = await service.repairWebConnectionAndUnlockLogin(for: reg)
            let trace = await service.probeClientNetworkTrace()

            await MainActor.run {
                self.activeSystemDNS = report.verifiedSystemDNS
                self.clientTrace = trace
                self.isConnected = true
                self.isRepairingWeb = false
                self.regionSwitchBanner = report.summaryMessage
            }
        }
    }

    private func selectRegion(_ region: VPNRegion) {
        selectedRegion = region
        isConnected = true
        selectedMode = .cloudflareWarp
        let mtu = speedProfile.effectiveMtu(for: region)
        let bwStr = bandwidthsMbps[region] != nil ? String(format: "%.1f Mbps", bandwidthsMbps[region]!) : "BBR Turbo"
        let latStr = latenciesMs[region] != nil ? "\(latenciesMs[region]!) ms" : "Đang đo"
        let prof = speedProfile
        let prt = selectedPort
        let service = vpnService

        regionSwitchBanner = "Đã chuyển vùng VPN sang \(region.countryNameVi) — \(region.cityVi) • Băng thông: \(bwStr) • Độ trễ thật: \(latStr) • MTU \(mtu) (UDP :\(prt.rawValue))"

        Task.detached(priority: .userInitiated) {
            _ = await service.selectRegion(region, speedProfile: prof, port: prt)
            let sysDNS = await service.getActiveSystemDNSServers()
            await MainActor.run {
                self.activeSystemDNS = sysDNS
            }
        }
    }

    private func applySpeedOptimization(profile: TunnelSpeedProfile, port: TunnelPortOption) {
        speedProfile = profile
        selectedPort = port
        isConnected = true
        let reg = selectedRegion
        let mtu = profile.effectiveMtu(for: reg)
        let base = measuredBaseMbps
        let currentLats = latenciesMs
        let service = vpnService

        var updatedBws: [VPNRegion: Double] = [:]
        for r in VPNRegion.allCases {
            if let bw = service.computeRegionalBandwidthMbps(
                baseMbps: base,
                rttMs: currentLats[r],
                region: r,
                speedProfile: profile,
                port: port
            ) {
                updatedBws[r] = bw
            }
        }
        bandwidthsMbps = updatedBws
        regionSwitchBanner = "Đã kích hoạt cấu hình tăng băng thông: \(profile.title) (MTU \(mtu) • Cổng UDP :\(port.rawValue)) cho vùng \(reg.countryNameVi)."

        Task.detached(priority: .userInitiated) {
            _ = await service.selectRegion(reg, speedProfile: profile, port: port)
        }
    }

    private func toggleConnection() {
        isConnected.toggle()
        let nowConnected = isConnected
        let reg = selectedRegion
        let service = vpnService

        if nowConnected {
            regionSwitchBanner = "Đã bật Khiên VPN & DNS chống chặn vùng \(reg.countryNameVi) trên macOS."
        } else {
            regionSwitchBanner = "Đã tắt Khiên VPN và khôi phục DNS mặc định của mạng Wi-Fi."
        }

        Task.detached(priority: .userInitiated) {
            if nowConnected {
                await service.connect()
            } else {
                await service.disconnect()
            }
            let sysDNS = await service.getActiveSystemDNSServers()
            await MainActor.run {
                self.activeSystemDNS = sysDNS
            }
        }
    }

    private func registerWarpLive() {
        isRegisteringWarp = true
        let reg = selectedRegion
        let prt = selectedPort
        let mtu = activeMtu
        let client = warpClient

        Task.detached(priority: .userInitiated) {
            do {
                let profile = try await client.registerWarpAccount()
                await MainActor.run {
                    self.privateKey = profile.privateKey
                    self.publicKey = profile.publicKey
                    self.isRegisteringWarp = false
                    self.isConnected = true
                    self.regionSwitchBanner = "Đã cấp khóa Curve25519 thật từ Cloudflare WARP và tối ưu đường hầm vùng \(reg.countryNameVi) (\(reg.host):\(prt.rawValue) • MTU \(mtu))."
                }
            } catch {
                let pair = client.generateKeyPair()
                await MainActor.run {
                    self.privateKey = pair.privateKey
                    self.publicKey = pair.publicKey
                    self.isRegisteringWarp = false
                    self.regionSwitchBanner = "Đã sinh khóa Curve25519 cục bộ mới cho vùng \(reg.countryNameVi) (\(reg.host):\(prt.rawValue) • MTU \(mtu))."
                }
            }
        }
    }

    private func downloadRegionalWireGuardConf() {
        let reg = selectedRegion
        let filename = "CleanBull-VPN-\(reg.code).conf"
        let dest = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Downloads")
            .appendingPathComponent(filename)
        do {
            try currentConfigText.write(to: dest, atomically: true, encoding: String.Encoding.utf8)
            regionSwitchBanner = "Đã xuất tệp cấu hình vùng \(reg.countryNameVi) tại: ~/Downloads/\(filename)"
            #if os(macOS)
            NSWorkspace.shared.activateFileViewerSelecting([dest])
            #endif
        } catch {
            regionSwitchBanner = "Không thể lưu file cấu hình: \(error.localizedDescription)"
        }
    }

    private func downloadSingBoxJson() {
        let reg = selectedRegion
        let jsonStr = configGen.generateSingBoxConfig(profile: currentProfile)
        let dest = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Downloads/CleanBull-SingBox-\(reg.code).json")
        try? jsonStr.write(to: dest, atomically: true, encoding: String.Encoding.utf8)
        regionSwitchBanner = "Đã xuất cấu hình Sing-box v1.8+ tại: ~/Downloads/CleanBull-SingBox-\(reg.code).json"
    }

    private func downloadDnsMobileconfig() {
        let reg = selectedRegion
        let xml = configGen.generateDnsShieldMobileConfig(region: reg)
        let dest = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Downloads/CleanBull-DNS-Shield-\(reg.code).mobileconfig")
        try? xml.write(to: dest, atomically: true, encoding: String.Encoding.utf8)
        regionSwitchBanner = "Đã xuất hồ sơ DNS Shield tại: ~/Downloads/CleanBull-DNS-Shield-\(reg.code).mobileconfig"
    }

    private func copyConfigToClipboard() {
        #if os(macOS)
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(currentConfigText, forType: .string)
        copiedConfig = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            copiedConfig = false
        }
        #endif
    }

    private func openInstallersFolder() {
        #if os(macOS)
        let distPath = "/Users/phambaophu/Downloads/CLEANBULL/dist-installers"
        let url = URL(fileURLWithPath: distPath)
        if FileManager.default.fileExists(atPath: distPath) {
            NSWorkspace.shared.open(url)
        } else {
            NSWorkspace.shared.open(FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads"))
        }
        #endif
    }

    private func evaluateCustomDomain() {
        let dom = domainTestInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !dom.isEmpty else { return }
        domainTestInput = ""
        let service = vpnService
        Task.detached(priority: .userInitiated) {
            let (_, entry) = await service.evaluateDomain(dom, clientApp: "Kiểm thử trực tiếp")
            await MainActor.run {
                self.radarEntries.insert(entry, at: 0)
            }
        }
    }

    private func seedInitialRadar() {
        radarEntries = [
            LiveRadarEntry(domain: "log.byteoversea.com", blocked: true, category: "ByteDance / TikTok Telemetry", clientApp: "TikTok"),
            LiveRadarEntry(domain: "graph.facebook.com", blocked: true, category: "Meta Graph Telemetry", clientApp: "Facebook"),
            LiveRadarEntry(domain: "apple.com", blocked: false, category: "Lưu lượng thông thường", clientApp: "Safari"),
            LiveRadarEntry(domain: "adservice.google.com", blocked: true, category: "Google Ad & Telemetry", clientApp: "Browser"),
            LiveRadarEntry(domain: "app.appsflyer.com", blocked: true, category: "Mobile Attribution Tracker", clientApp: "App")
        ]
    }
}
