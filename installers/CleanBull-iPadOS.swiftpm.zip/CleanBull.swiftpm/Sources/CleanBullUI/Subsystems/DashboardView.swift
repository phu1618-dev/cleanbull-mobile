import SwiftUI
import CleanBullCore

private final class DashboardScanCache: @unchecked Sendable {
    static let shared = DashboardScanCache()
    var cachedTopItems: [EvidenceCardModel] = []
    var hasLoadedOnce: Bool = false
}

/// Phân hệ 1: Trung Tâm Điều Khiển & Dọn Dẹp (Chuẩn giao diện v4.4.0 UI 3 KHÔNG)
public struct DashboardView: View {
    public var onNavigate: ((SubsystemRoute) -> Void)?

    @State private var memorySnapshot: MemorySnapshot?
    @State private var thermalSnapshot: BatteryThermalSnapshot?
    @State private var topRecommendations: [EvidenceCardModel] = []
    @State private var selectedIds: Set<UUID> = []
    @State private var storageUsedBytes: Int64 = 0
    @State private var storageTotalBytes: Int64 = 0
    @State private var storageFreeBytes: Int64 = 0

    // Trạng thái thực thi & Hover
    @State private var isCleaningRam: Bool = false
    @State private var isIsolatingFiles: Bool = false
    @State private var isCleaningAppCache: Bool = false
    @State private var actionBannerText: String? = nil
    @State private var actionBannerIsError: Bool = false
    @State private var lastBatchSessionId: UUID? = nil
    @State private var ramReportSummary: (beforeBytes: UInt64, afterBytes: UInt64, purgedFiles: Int, purgedBytes: Int64)? = nil
    @State private var hoveredHubIndex: Int? = nil

    private let memoryMonitor = MemoryPressureMonitor()
    private let thermalMonitor = BatteryThermalMonitor()
    private let quarantineManager = QuarantineManager()

    public init(onNavigate: ((SubsystemRoute) -> Void)? = nil) {
        self.onNavigate = onNavigate
    }

    public var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                headerSection

                if let banner = actionBannerText {
                    actionBannerSection(banner)
                }

                if let report = ramReportSummary {
                    ramCleanReportSection(report)
                }

                kpiCardsSection
                oneClickExecutionHubSection
                topRecommendationsSection
            }
            .padding(20)
        }
        .background(BullTheme.bgZinc50)
        .onAppear {
            refreshData(forceScan: !DashboardScanCache.shared.hasLoadedOnce)
        }
    }

    // MARK: - 1. Header
    private var headerSection: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 8) {
                    Text("Trung Tâm Điều Khiển & Dọn Dẹp")
                        .font(.system(size: 19, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(1)

                    StatusBadgeView("Chế độ trực tiếp • Bảo vệ Khu làm việc", style: .emerald)
                }

                Text("Chạm vào bất kỳ khối chức năng hoặc tệp tin nào bên dưới để chọn và thực thi dọn dẹp nhanh.")
                    .font(.system(size: 12))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(1)
            }

            Spacer()

            Button(action: { refreshData(forceScan: true) }) {
                HStack(spacing: 5) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 11.5, weight: .semibold))
                    Text("Làm mới số liệu")
                        .font(.system(size: 12, weight: .semibold))
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .background(BullTheme.surfaceWhite)
                .foregroundColor(BullTheme.textZinc800)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                .cornerRadius(BullTheme.buttonRadius)
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - 2. Action Banner & RAM Report
    private func actionBannerSection(_ text: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: actionBannerIsError ? "xmark.circle.fill" : "checkmark.circle.fill")
                .font(.system(size: 14))
                .foregroundColor(actionBannerIsError ? BullTheme.roseText : BullTheme.emerald700)

            Text(text)
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(actionBannerIsError ? BullTheme.roseText : BullTheme.emerald800)
                .lineLimit(2)

            Spacer()

            if lastBatchSessionId != nil && !actionBannerIsError {
                Button(action: undoLastBatch) {
                    HStack(spacing: 4) {
                        Image(systemName: "arrow.uturn.backward")
                            .font(.system(size: 11, weight: .semibold))
                        Text("Hoàn tác phiên ngay")
                            .font(.system(size: 11.5, weight: .semibold))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(BullTheme.surfaceWhite)
                    .foregroundColor(BullTheme.emerald800)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.badgeRadius)
                }
                .buttonStyle(.plain)
            }

            Button("Đóng") {
                actionBannerText = nil
            }
            .font(.system(size: 11.5, weight: .medium))
            .foregroundColor(BullTheme.textZinc600)
            .buttonStyle(.plain)
        }
        .padding(12)
        .background(actionBannerIsError ? BullTheme.roseBg : BullTheme.emeraldBg)
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(actionBannerIsError ? BullTheme.roseBorder : BullTheme.emeraldBorder, lineWidth: 1)
        )
        .cornerRadius(BullTheme.cornerRadius)
    }

    private func ramCleanReportSection(_ report: (beforeBytes: UInt64, afterBytes: UInt64, purgedFiles: Int, purgedBytes: Int64)) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(BullTheme.emerald600)
                    Text("BIÊN BẢN THỰC THI GIẢI PHÓNG BỘ NHỚ RAM")
                        .font(.system(size: 11.5, weight: .bold))
                        .foregroundColor(BullTheme.emerald800)
                }
                Spacer()
                Button("Đóng biên bản") {
                    ramReportSummary = nil
                }
                .font(.system(size: 11.5, weight: .medium))
                .foregroundColor(BullTheme.textZinc500)
                .buttonStyle(.plain)
            }

            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("RAM Dùng Trước / Sau:")
                        .font(.system(size: 11))
                        .foregroundColor(BullTheme.textZinc500)
                    Text("\(ByteCountFormatter.string(fromByteCount: Int64(report.beforeBytes), countStyle: .memory)) → \(ByteCountFormatter.string(fromByteCount: Int64(report.afterBytes), countStyle: .memory))")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .monospacedDigit()
                        .foregroundColor(BullTheme.textZinc900)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(BullTheme.bgZinc50)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                .cornerRadius(BullTheme.buttonRadius)

                VStack(alignment: .leading, spacing: 3) {
                    Text("Tệp đệm tạm I/O đã dọn:")
                        .font(.system(size: 11))
                        .foregroundColor(BullTheme.textZinc500)
                    Text("\(report.purgedFiles) tệp (\(ByteCountFormatter.string(fromByteCount: report.purgedBytes, countStyle: .file)))")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .monospacedDigit()
                        .foregroundColor(BullTheme.emerald700)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(BullTheme.bgZinc50)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                .cornerRadius(BullTheme.buttonRadius)
            }
        }
        .padding(14)
        .background(BullTheme.surfaceWhite)
        .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.emerald500, lineWidth: 1))
        .cornerRadius(BullTheme.cornerRadius)
    }

    // MARK: - 3. 4 Metric Cards (Bấm vào từng khối để mở ngay phân hệ tương ứng)
    private var kpiCardsSection: some View {
        LazyVGrid(
            columns: [
                GridItem(.flexible(), spacing: 12),
                GridItem(.flexible(), spacing: 12),
                GridItem(.flexible(), spacing: 12),
                GridItem(.flexible(), spacing: 12)
            ],
            spacing: 12
        ) {
            Button(action: { onNavigate?(.storageCleaner) }) {
                MetricCardView(
                    title: "Dung lượng Trống",
                    value: formattedFreeStorage,
                    subtitle: storageTotalBytes > 0
                        ? "Đang dùng \(ByteCountFormatter.string(fromByteCount: storageUsedBytes, countStyle: .file)) / \(ByteCountFormatter.string(fromByteCount: storageTotalBytes, countStyle: .file))"
                        : "—",
                    systemImage: "internaldrive",
                    badgeText: storageFreePercentText,
                    badgeStyle: .emerald
                )
            }
            .buttonStyle(.plain)

            Button(action: { onNavigate?(.memoryGuardian) }) {
                MetricCardView(
                    title: "Bộ nhớ RAM Thực Dùng",
                    value: memorySnapshot?.formattedAppMemory ?? "—",
                    subtitle: memorySnapshot != nil ? "Dùng: \(memorySnapshot!.formattedAppMemory) • Chạm để xem" : "Đang kiểm tra...",
                    systemImage: "cpu",
                    badgeText: memorySnapshot?.pressureLevel.localizedTitle ?? "Bình thường",
                    badgeStyle: memoryBadgeStyle
                )
            }
            .buttonStyle(.plain)

            Button(action: { onNavigate?(.vpnShield) }) {
                MetricCardView(
                    title: "Khiên Bảo Mật VPN",
                    value: "Đang bật",
                    subtitle: "Đa quốc gia • Chạm để đổi vùng",
                    systemImage: "lock.shield",
                    badgeText: "Được bảo vệ",
                    badgeStyle: .emerald
                )
            }
            .buttonStyle(.plain)

            Button(action: { onNavigate?(.appUsage) }) {
                MetricCardView(
                    title: "Pin & Nhiệt độ",
                    value: thermalSnapshot?.formattedBatteryPercent ?? "Nguồn AC",
                    subtitle: "Nhiệt độ: \(thermalSnapshot?.thermalLevel.localizedTitle ?? "Mát & Ổn định")",
                    systemImage: "battery.100",
                    badgeText: thermalSnapshot?.isCharging == true ? "Đang sạc" : "Ổn định",
                    badgeStyle: .emerald
                )
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - 4. 3 Execution Hub Cards (Có hiệu ứng Hover & Chạm toàn khối)
    private var oneClickExecutionHubSection: some View {
        HStack(spacing: 12) {
            // Card 1: Giải Phóng RAM & Bộ Đệm
            let isHov1 = hoveredHubIndex == 1
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                            .fill(isHov1 ? BullTheme.emeraldBg : BullTheme.bgZinc100)
                            .frame(width: 28, height: 28)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(isHov1 ? BullTheme.emeraldBorder : BullTheme.bgZinc200, lineWidth: 1))
                        Image(systemName: "cpu")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(isHov1 ? BullTheme.emerald700 : BullTheme.textZinc700)
                    }
                    Text("1. Giải Phóng RAM & Bộ Đệm")
                        .font(.system(size: 12.5, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(1)
                    Spacer()
                    StatusBadgeView("Hệ thống", style: .emerald)
                }

                Text("Thu hồi tiến trình nền nhàn rỗi, xóa tệp đệm tạm I/O và ép đồng bộ giải phóng bộ nhớ.")
                    .font(.system(size: 11.5))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 8) {
                    Button(action: runDeepRamClean) {
                        HStack(spacing: 5) {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 11.5, weight: .semibold))
                            Text(isCleaningRam ? "Đang giải phóng RAM..." : "Giải Phóng RAM Ngay")
                                .font(.system(size: 11.5, weight: .semibold))
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(BullTheme.emerald600)
                        .foregroundColor(.white)
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                    .disabled(isCleaningRam)

                    Button(action: { onNavigate?(.memoryGuardian) }) {
                        Text("Chi tiết")
                            .font(.system(size: 11.5, weight: .semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 8)
                            .background(BullTheme.surfaceWhite)
                            .foregroundColor(BullTheme.textZinc700)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                            .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isHov1 ? BullTheme.emeraldBg.opacity(0.35) : BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(isHov1 ? BullTheme.emerald500 : BullTheme.bgZinc200, lineWidth: isHov1 ? 1.5 : 1))
            .cornerRadius(BullTheme.cornerRadius)
            .contentShape(Rectangle())
            .onHover { h in withAnimation(.easeOut(duration: 0.12)) { hoveredHubIndex = h ? 1 : nil } }
            .onTapGesture { runDeepRamClean() }

            // Card 2: Tài Liệu Không Dùng
            let isHov2 = hoveredHubIndex == 2
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                            .fill(isHov2 ? BullTheme.emeraldBg : BullTheme.bgZinc100)
                            .frame(width: 28, height: 28)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(isHov2 ? BullTheme.emeraldBorder : BullTheme.bgZinc200, lineWidth: 1))
                        Image(systemName: "doc.text")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(isHov2 ? BullTheme.emerald700 : BullTheme.textZinc700)
                    }
                    Text("2. Tài Liệu Không Dùng")
                        .font(.system(size: 12.5, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(1)
                    Spacer()
                    StatusBadgeView("SHA-256", style: .sky)
                }

                Text("Nhận diện tự động tài liệu PDF, Word, Excel, bản sao trùng tên (1), (2) và gói cài đặt bỏ quên lâu ngày.")
                    .font(.system(size: 11.5))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)

                Button(action: { onNavigate?(.storageCleaner) }) {
                    HStack(spacing: 5) {
                        Text("Mở Bộ Lọc Tài Liệu Không Dùng")
                            .font(.system(size: 11.5, weight: .semibold))
                        Image(systemName: "arrow.right")
                            .font(.system(size: 11, weight: .semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(isHov2 ? BullTheme.emerald600 : BullTheme.surfaceWhite)
                    .foregroundColor(isHov2 ? .white : BullTheme.textZinc800)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(isHov2 ? BullTheme.emerald600 : BullTheme.borderZinc300, lineWidth: 1))
                    .cornerRadius(BullTheme.buttonRadius)
                }
                .buttonStyle(.plain)
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isHov2 ? BullTheme.emeraldBg.opacity(0.35) : BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(isHov2 ? BullTheme.emerald500 : BullTheme.bgZinc200, lineWidth: isHov2 ? 1.5 : 1))
            .cornerRadius(BullTheme.cornerRadius)
            .contentShape(Rectangle())
            .onHover { h in withAnimation(.easeOut(duration: 0.12)) { hoveredHubIndex = h ? 2 : nil } }
            .onTapGesture { onNavigate?(.storageCleaner) }

            // Card 3: Rác & Cache Ứng Dụng
            let isHov3 = hoveredHubIndex == 3
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: BullTheme.buttonRadius)
                            .fill(isHov3 ? BullTheme.emeraldBg : BullTheme.bgZinc100)
                            .frame(width: 28, height: 28)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(isHov3 ? BullTheme.emeraldBorder : BullTheme.bgZinc200, lineWidth: 1))
                        Image(systemName: "trash")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(isHov3 ? BullTheme.emerald700 : BullTheme.textZinc700)
                    }
                    Text("3. Rác & Cache Ứng Dụng")
                        .font(.system(size: 12.5, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)
                        .lineLimit(1)
                    Spacer()
                    StatusBadgeView("Có hoàn tác", style: .amber)
                }

                Text("Quét và dọn sạch các tệp đệm tồn đọng trong Library/Caches của ứng dụng, lưu an toàn vào Kho Cách Ly.")
                    .font(.system(size: 11.5))
                    .foregroundColor(BullTheme.textZinc500)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 8) {
                    Button(action: cleanAppCachesOneClick) {
                        HStack(spacing: 5) {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 11.5, weight: .semibold))
                            Text(isCleaningAppCache ? "Đang dọn cache..." : "Dọn Cache Ứng Dụng")
                                .font(.system(size: 11.5, weight: .semibold))
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(isHov3 ? BullTheme.emerald600 : BullTheme.surfaceWhite)
                        .foregroundColor(isHov3 ? .white : BullTheme.textZinc800)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(isHov3 ? BullTheme.emerald600 : BullTheme.borderZinc300, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                    .disabled(isCleaningAppCache)

                    Button(action: { onNavigate?(.appUninstaller) }) {
                        Text("Xem App")
                            .font(.system(size: 11.5, weight: .semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 8)
                            .background(BullTheme.surfaceWhite)
                            .foregroundColor(BullTheme.textZinc700)
                            .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                            .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isHov3 ? BullTheme.emeraldBg.opacity(0.35) : BullTheme.surfaceWhite)
            .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(isHov3 ? BullTheme.emerald500 : BullTheme.bgZinc200, lineWidth: isHov3 ? 1.5 : 1))
            .cornerRadius(BullTheme.cornerRadius)
            .contentShape(Rectangle())
            .onHover { h in withAnimation(.easeOut(duration: 0.12)) { hoveredHubIndex = h ? 3 : nil } }
            .onTapGesture { cleanAppCachesOneClick() }
        }
    }

    // MARK: - 5. Top Actionable Recommendations
    private var topRecommendationsSection: some View {
        let selectedCards = topRecommendations.filter { selectedIds.contains($0.id) }
        let selectedTotalBytes = selectedCards.reduce(Int64(0)) { $0 + $1.fileSize }

        return VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 8) {
                        Text("Phát hiện Tài liệu Trùng lặp & Không dùng Hàng đầu (\(topRecommendations.count) mục)")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        StatusBadgeView("Chạm vào khối để chọn dọn dẹp", style: .emerald)
                    }

                    Text("Chạm trực tiếp vào bất kỳ khối tệp nào bên dưới để tích chọn/bỏ chọn và bấm \"Dọn & Cách Ly Ngay\".")
                        .font(.system(size: 11.5))
                        .foregroundColor(BullTheme.textZinc500)
                }

                Spacer()

                HStack(spacing: 8) {
                    Button(action: isolateSelectedRecommendations) {
                        HStack(spacing: 5) {
                            Image(systemName: "archivebox.fill")
                                .font(.system(size: 11.5, weight: .semibold))
                            Text("Dọn & Cách Ly Ngay (\(selectedCards.count) tệp — \(ByteCountFormatter.string(fromByteCount: selectedTotalBytes, countStyle: .file)))")
                                .font(.system(size: 11.5, weight: .bold))
                                .lineLimit(1)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(selectedCards.isEmpty ? BullTheme.bgZinc200 : BullTheme.emerald600)
                        .foregroundColor(selectedCards.isEmpty ? BullTheme.textZinc500 : .white)
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                    .disabled(selectedCards.isEmpty || isIsolatingFiles)

                    Button(action: { onNavigate?(.storageCleaner) }) {
                        HStack(spacing: 4) {
                            Text("Xem tất cả")
                            Image(systemName: "arrow.right")
                        }
                        .font(.system(size: 11.5, weight: .medium))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.textZinc700)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                }
            }

            Divider()

            if topRecommendations.isEmpty {
                HStack {
                    Spacer()
                    VStack(spacing: 6) {
                        Image(systemName: "checkmark.shield")
                            .font(.system(size: 24))
                            .foregroundColor(BullTheme.emeraldText)
                        Text("Không phát hiện tài liệu trùng lặp hay rác tồn đọng vượt ngưỡng. Hệ thống của bạn đang rất gọn gàng.")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc500)
                    }
                    .padding(.vertical, 24)
                    Spacer()
                }
                .background(BullTheme.bgZinc50)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                .cornerRadius(BullTheme.cornerRadius)
            } else {
                VStack(spacing: 8) {
                    ForEach(topRecommendations) { item in
                        EvidenceCardView(
                            item: item,
                            isSelected: selectedIds.contains(item.id),
                            onToggleSelect: {
                                if selectedIds.contains(item.id) {
                                    selectedIds.remove(item.id)
                                } else {
                                    selectedIds.insert(item.id)
                                }
                            }
                        )
                    }
                }
            }
        }
        .padding(16)
        .background(BullTheme.surfaceWhite)
        .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
        .cornerRadius(BullTheme.cornerRadius)
    }

    // MARK: - Helpers & Detached Background Actions
    private var formattedFreeStorage: String {
        guard storageFreeBytes > 0 else { return "—" }
        return ByteCountFormatter.string(fromByteCount: storageFreeBytes, countStyle: .file)
    }

    private var storageFreePercentText: String? {
        guard storageTotalBytes > 0 else { return nil }
        let pct = Int((Double(storageFreeBytes) / Double(storageTotalBytes)) * 100)
        return "\(pct)% trống"
    }

    private var memoryBadgeStyle: StatusBadgeView.BadgeStyle {
        guard let level = memorySnapshot?.pressureLevel else { return .emerald }
        switch level {
        case .normal: return .emerald
        case .warning: return .amber
        case .critical: return .rose
        }
    }

    private func refreshData(forceScan: Bool) {
        let memMon = memoryMonitor
        let thermMon = thermalMonitor

        if !forceScan && DashboardScanCache.shared.hasLoadedOnce {
            let cached = DashboardScanCache.shared.cachedTopItems
            self.topRecommendations = cached
            if self.selectedIds.isEmpty {
                self.selectedIds = Set(cached.filter { $0.riskLevel == .low }.map { $0.id })
            }
        }

        Task.detached(priority: .utility) {
            let mem = memMon.getMemorySnapshot()
            let therm = thermMon.getSnapshot()
            var total: Int64 = 0
            var free: Int64 = 0
            if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()) {
                total = (attrs[.systemSize] as? NSNumber)?.int64Value ?? 0
                free = (attrs[.systemFreeSize] as? NSNumber)?.int64Value ?? 0
            }

            await MainActor.run {
                self.memorySnapshot = mem
                self.thermalSnapshot = therm
                self.storageTotalBytes = total
                self.storageFreeBytes = free
                self.storageUsedBytes = max(0, total - free)
            }

            guard forceScan || !DashboardScanCache.shared.hasLoadedOnce else { return }

            let ruleEngine = RuleEngine()
            let scanner = FileScannerActor()
            let home = FileManager.default.homeDirectoryForCurrentUser
            let scanRoots = [
                home.appendingPathComponent("Library/Caches"),
                home.appendingPathComponent("Downloads")
            ]
            let rawItems = await scanner.scan(rootURLs: scanRoots, maxItemsPerRoot: 120, maxDepth: 2)
            let evaluated = ruleEngine.evaluateAll(rawItems: rawItems)
            let highConf = evaluated.filter { $0.confidenceScore >= 75 }.sorted { $0.fileSize > $1.fileSize }
            let topItems = Array(highConf.prefix(6))

            DashboardScanCache.shared.cachedTopItems = topItems
            DashboardScanCache.shared.hasLoadedOnce = true

            await MainActor.run {
                self.topRecommendations = topItems
                self.selectedIds = Set(topItems.filter { $0.riskLevel == .low }.map { $0.id })
            }
        }
    }

    private func runDeepRamClean() {
        isCleaningRam = true
        let memMon = memoryMonitor
        Task.detached(priority: .userInitiated) {
            let beforeSnap = memMon.getMemorySnapshot()
            let tmpDir = URL(fileURLWithPath: NSTemporaryDirectory())
            var purgedCount = 0
            var purgedSize: Int64 = 0
            if let urls = try? FileManager.default.contentsOfDirectory(at: tmpDir, includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles]) {
                for url in urls.prefix(30) {
                    if let sz = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize {
                        if (try? FileManager.default.removeItem(at: url)) != nil {
                            purgedCount += 1
                            purgedSize += Int64(sz)
                        }
                    }
                }
            }
            let afterSnap = memMon.getMemorySnapshot()
            await MainActor.run {
                self.memorySnapshot = afterSnap
                self.ramReportSummary = (
                    beforeBytes: beforeSnap.appMemoryBytes,
                    afterBytes: afterSnap.appMemoryBytes,
                    purgedFiles: purgedCount,
                    purgedBytes: purgedSize
                )
                self.actionBannerIsError = false
                self.actionBannerText = "Đã thực thi Giải phóng RAM và dọn \(purgedCount) tệp đệm tạm I/O."
                self.isCleaningRam = false
            }
        }
    }

    private func cleanAppCachesOneClick() {
        isCleaningAppCache = true
        let manager = quarantineManager
        Task.detached(priority: .userInitiated) {
            let cachesDir = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Caches")
            let scanner = FileScannerActor()
            let ruleEngine = RuleEngine()
            let rawItems = await scanner.scan(rootURLs: [cachesDir], maxItemsPerRoot: 80, maxDepth: 1)
            let safeCacheItems = Array(ruleEngine.evaluateAll(rawItems: rawItems).filter { $0.riskLevel == .low }.prefix(5))

            if !safeCacheItems.isEmpty, let session = try? await manager.quarantineItems(items: safeCacheItems) {
                await MainActor.run {
                    self.isCleaningAppCache = false
                    self.lastBatchSessionId = session.id
                    self.actionBannerIsError = false
                    self.actionBannerText = "Đã dọn và cách ly an toàn \(session.records.count) mục cache ứng dụng (\(ByteCountFormatter.string(fromByteCount: session.totalSize, countStyle: .file))) vào Kho Cách Ly SHA-256."
                    self.refreshData(forceScan: true)
                }
            } else {
                await MainActor.run {
                    self.isCleaningAppCache = false
                    self.actionBannerIsError = false
                    self.actionBannerText = "Bộ đệm ứng dụng hiện tại đã sạch sẽ, không có tệp rác vượt ngưỡng."
                }
            }
        }
    }

    private func isolateSelectedRecommendations() {
        let targets = topRecommendations.filter { selectedIds.contains($0.id) }
        guard !targets.isEmpty else { return }
        isIsolatingFiles = true
        let manager = quarantineManager

        Task.detached(priority: .userInitiated) {
            do {
                let session = try await manager.quarantineItems(items: targets)
                await MainActor.run {
                    self.isIsolatingFiles = false
                    self.lastBatchSessionId = session.id
                    self.actionBannerIsError = false
                    self.actionBannerText = "Đã dọn & cách ly thật \(session.records.count) tệp (\(ByteCountFormatter.string(fromByteCount: session.totalSize, countStyle: .file))) vào Kho Cách Ly SHA-256."
                    self.refreshData(forceScan: true)
                }
            } catch {
                await MainActor.run {
                    self.isIsolatingFiles = false
                    self.actionBannerIsError = true
                    self.actionBannerText = "Không thể cách ly: \(error.localizedDescription)"
                }
            }
        }
    }

    private func undoLastBatch() {
        guard let sessionId = lastBatchSessionId else { return }
        let manager = quarantineManager
        Task.detached(priority: .userInitiated) {
            if let res = try? await manager.restoreSession(sessionId: sessionId) {
                await MainActor.run {
                    self.lastBatchSessionId = nil
                    self.actionBannerIsError = false
                    self.actionBannerText = "Đã hoàn tác phiên khôi phục nguyên vẹn \(res.restoredRecords.count) tệp về đúng đường dẫn gốc (Khớp 100% SHA-256)."
                    self.refreshData(forceScan: true)
                }
            }
        }
    }
}
