import SwiftUI
import CleanBullCore

private final class MemoryGuardianCache: @unchecked Sendable {
    static let shared = MemoryGuardianCache()
    var cachedProcesses: [ProcessDetailModel] = []
    var cachedSnapshot: MemorySnapshot? = nil
    var hasLoadedOnce: Bool = false
}

/// Phân hệ 2: Kiểm soát RAM, Pin & Tiến trình Ẩn (MemoryGuardian)
/// Chạy trên Task.detached(.utility) kèm hiệu ứng Hover & Chọn khối rõ nét chuẩn UI 3 KHÔNG.
public struct MemoryGuardianView: View {
    @State private var snapshot: MemorySnapshot?
    @State private var processes: [ProcessDetailModel] = []
    @State private var selectedProcess: ProcessDetailModel?
    @State private var hoveredPid: Int32? = nil
    @State private var filterCategory: ProcessRiskCategory? = nil
    @State private var actionMessage: String?

    private let memoryMonitor = MemoryPressureMonitor()
    private let processService = ProcessInspectionService()

    public init() {}

    public var body: some View {
        HStack(spacing: 0) {
            // Danh sách tiến trình & Thống kê
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 8) {
                            Text("Kiểm Soát Bộ Nhớ & Tiến Trình")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(BullTheme.textZinc900)
                            StatusBadgeView("Chạm vào khối để thanh tra", style: .emerald)
                        }
                        Text("Số liệu Mach VM Darwin thật 100% — Không dọn RAM ảo, tự động bảo vệ các khu làm việc (IDE)")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc600)
                    }
                    Spacer()
                    Button(action: { refresh(force: true) }) {
                        HStack(spacing: 5) {
                            Image(systemName: "arrow.clockwise")
                            Text("Làm mới RAM")
                        }
                        .font(.system(size: 12, weight: .semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.textZinc800)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                }

                // Grid 4 chỉ số RAM chi tiết
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    MetricCardView(
                        title: "RAM Hoạt động (Active)",
                        value: snapshot?.formattedAppMemory ?? "—",
                        subtitle: "Nén: \(snapshot?.formattedCompressed ?? "—")",
                        systemImage: "memorychip"
                    )
                    MetricCardView(
                        title: "RAM Cố định (Wired)",
                        value: snapshot?.formattedWired ?? "—",
                        subtitle: "Hạt nhân giữ cố định",
                        systemImage: "lock"
                    )
                    MetricCardView(
                        title: "Bộ đệm tệp (Inactive)",
                        value: snapshot?.formattedInactive ?? "—",
                        subtitle: "Tăng tốc mở app",
                        systemImage: "archivebox"
                    )
                    MetricCardView(
                        title: "Hoán đổi ổ đĩa (Swap)",
                        value: snapshot?.formattedSwapUsed ?? "—",
                        subtitle: "Tổng: \(snapshot?.formattedSwapTotal ?? "—")",
                        systemImage: "arrow.triangle.2.circlepath"
                    )
                }

                // Bộ lọc 5 nhóm Rogue Heuristics
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        filterButton(title: "Tất cả (\(processes.count))", category: nil)
                        ForEach(ProcessRiskCategory.allCases, id: \.self) { cat in
                            let count = processes.filter { $0.riskCategory == cat }.count
                            filterButton(title: "\(cat.rawValue) (\(count))", category: cat)
                        }
                    }
                }

                if let msg = actionMessage {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(BullTheme.emerald700)
                        Text(msg)
                            .font(.system(size: 11.5, weight: .semibold))
                        Spacer()
                        Button("Đóng") { actionMessage = nil }
                            .font(.system(size: 11))
                            .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(BullTheme.emeraldBg)
                    .foregroundColor(BullTheme.emerald800)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.badgeRadius)
                }

                // Danh sách tiến trình với khối tương tác rõ nét
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(filteredProcesses) { proc in
                            processRowCard(proc)
                        }
                    }
                    .padding(10)
                }
                .background(BullTheme.surfaceWhite)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                .cornerRadius(BullTheme.cornerRadius)
            }
            .padding(16)

            // Thanh tra chi tiết tiến trình (Cột phải)
            if let p = selectedProcess {
                Divider()
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text("Thanh Tra Tiến Trình")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        Spacer()
                        StatusBadgeView("ĐANG CHỌN", style: .emerald)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        detailRow(label: "Tên tiến trình:", value: p.name)
                        detailRow(label: "Mã PID:", value: "\(p.pid)")
                        detailRow(label: "Tiến trình cha (PPID):", value: "\(p.parentPid)")
                        detailRow(label: "Bộ nhớ Resident:", value: p.memoryFormatted)
                        detailRow(label: "Mức tải CPU:", value: String(format: "%.1f%%", p.cpuPercent))
                        detailRow(label: "Phân loại:", value: p.riskCategory.rawValue)
                    }
                    .padding(12)
                    .background(BullTheme.emeraldBg.opacity(0.5))
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.cornerRadius)

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Đánh giá nguy cơ:")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(BullTheme.textZinc600)
                        Text(p.explanation)
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc900)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Khuyến nghị:")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(BullTheme.textZinc600)
                        Text(p.recommendation)
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc900)
                    }

                    Spacer()

                    if p.isSystemProcess {
                        HStack {
                            Image(systemName: "lock.shield")
                            Text("Tiến trình Hệ thống / Khu làm việc — Đã khóa bảo vệ")
                        }
                        .font(.system(size: 11, weight: .semibold))
                        .padding(10)
                        .frame(maxWidth: .infinity)
                        .background(BullTheme.emeraldBg)
                        .foregroundColor(BullTheme.emerald800)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                        .cornerRadius(BullTheme.cornerRadius)
                    } else {
                        VStack(spacing: 8) {
                            Button(action: { terminate(proc: p, force: false) }) {
                                Text("Đóng nhẹ nhàng (SIGTERM)")
                                    .font(.system(size: 12, weight: .semibold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 8)
                                    .background(BullTheme.emerald600)
                                    .foregroundColor(.white)
                                    .cornerRadius(BullTheme.buttonRadius)
                            }
                            .buttonStyle(.plain)

                            Button(action: { terminate(proc: p, force: true) }) {
                                Text("Buộc dừng (SIGKILL)")
                                    .font(.system(size: 12, weight: .semibold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 8)
                                    .background(BullTheme.roseBg)
                                    .foregroundColor(BullTheme.roseText)
                                    .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.roseBorder, lineWidth: 1))
                                    .cornerRadius(BullTheme.buttonRadius)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .frame(width: 295)
                .padding(16)
                .background(BullTheme.surfaceWhite)
            }
        }
        .background(BullTheme.bgZinc50)
        .onAppear {
            refresh(force: !MemoryGuardianCache.shared.hasLoadedOnce)
        }
    }

    private func processRowCard(_ proc: ProcessDetailModel) -> some View {
        let isSel = selectedProcess?.pid == proc.pid
        let isHov = hoveredPid == proc.pid

        return HStack(spacing: 10) {
            Image(systemName: isSel ? "checkmark.circle.fill" : (proc.isSystemProcess ? "lock.shield" : "app.badge"))
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald700 : BullTheme.textZinc400))

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(proc.name)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(isSel ? BullTheme.emerald800 : BullTheme.textZinc900)
                        .lineLimit(1)

                    Text("PID: \(proc.pid)")
                        .font(.system(size: 11, design: .monospaced))
                        .monospacedDigit()
                        .foregroundColor(BullTheme.textZinc500)

                    if isSel {
                        StatusBadgeView("ĐANG CHỌN", style: .emerald)
                    }
                }
                Text(proc.executablePath)
                    .font(.system(size: 10.5, design: .monospaced))
                    .foregroundColor(BullTheme.textZinc400)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 3) {
                Text(proc.memoryFormatted)
                    .font(.system(size: 12.5, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(isSel ? BullTheme.emerald700 : BullTheme.textZinc900)

                StatusBadgeView(proc.riskCategory.rawValue, style: badgeStyle(for: proc.riskCategory))
            }
        }
        .padding(10)
        .background(isSel ? BullTheme.emeraldBg : (isHov ? BullTheme.bgZinc100.opacity(0.8) : BullTheme.surfaceWhite))
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: isSel ? 2.0 : (isHov ? 1.5 : 1.0))
        )
        .cornerRadius(BullTheme.cornerRadius)
        .contentShape(Rectangle())
        .onHover { h in
            withAnimation(.easeOut(duration: 0.12)) {
                hoveredPid = h ? proc.pid : nil
            }
        }
        .onTapGesture {
            withAnimation(.easeOut(duration: 0.12)) {
                selectedProcess = proc
            }
        }
    }

    private var filteredProcesses: [ProcessDetailModel] {
        if let cat = filterCategory {
            return processes.filter { $0.riskCategory == cat }
        }
        return processes
    }

    private func filterButton(title: String, category: ProcessRiskCategory?) -> some View {
        let isSelected = filterCategory == category
        return Button(action: {
            withAnimation(.easeOut(duration: 0.12)) {
                filterCategory = category
            }
        }) {
            Text(title)
                .font(.system(size: 11.5, weight: .semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(isSelected ? BullTheme.emerald600 : BullTheme.surfaceWhite)
                .foregroundColor(isSelected ? .white : BullTheme.textZinc700)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(isSelected ? BullTheme.emerald600 : BullTheme.bgZinc200, lineWidth: 1))
                .cornerRadius(BullTheme.buttonRadius)
        }
        .buttonStyle(.plain)
    }

    private func detailRow(label: String, value: String) -> some View {
        HStack {
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(BullTheme.textZinc600)
            Spacer()
            Text(value)
                .font(.system(size: 11, weight: .bold))
                .monospacedDigit()
                .foregroundColor(BullTheme.textZinc900)
        }
    }

    private func badgeStyle(for cat: ProcessRiskCategory) -> StatusBadgeView.BadgeStyle {
        switch cat {
        case .orphan: return .rose
        case .headlessHog: return .amber
        case .launchAgent: return .sky
        case .normalApp: return .zinc
        case .protectedSystem: return .emerald
        }
    }

    private func refresh(force: Bool) {
        if !force && MemoryGuardianCache.shared.hasLoadedOnce {
            self.snapshot = MemoryGuardianCache.shared.cachedSnapshot
            self.processes = MemoryGuardianCache.shared.cachedProcesses
            if self.selectedProcess == nil {
                self.selectedProcess = self.processes.first
            }
            return
        }

        let memMon = memoryMonitor
        let procSvc = processService

        Task.detached(priority: .utility) {
            let snap = memMon.getMemorySnapshot()
            let list = await procSvc.inspectAllProcesses()
            MemoryGuardianCache.shared.cachedSnapshot = snap
            MemoryGuardianCache.shared.cachedProcesses = list
            MemoryGuardianCache.shared.hasLoadedOnce = true

            await MainActor.run {
                self.snapshot = snap
                self.processes = list
                if self.selectedProcess == nil, let first = list.first {
                    self.selectedProcess = first
                }
            }
        }
    }

    private func terminate(proc: ProcessDetailModel, force: Bool) {
        let procSvc = processService
        Task.detached(priority: .userInitiated) {
            let (_, message) = await procSvc.terminateProcess(pid: proc.pid, force: force)
            await MainActor.run {
                self.actionMessage = message
                self.refresh(force: true)
            }
        }
    }
}
