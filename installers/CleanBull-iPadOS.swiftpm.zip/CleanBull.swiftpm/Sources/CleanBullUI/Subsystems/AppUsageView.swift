import SwiftUI
import CleanBullCore
#if os(macOS)
import AppKit
#endif

/// Thông tin sử dụng ứng dụng
public struct AppUsageStat: Identifiable, Sendable {
    public var id: String { bundleId }
    public let appName: String
    public let bundleId: String
    public let appPath: String?
    public let launchCount: Int
    public let totalForegroundSeconds: Int
    public let lastOpenedDate: Date?
    public let sizeBytes: Int64

    public var isUnused: Bool {
        guard let last = lastOpenedDate else { return true }
        let days = Calendar.current.dateComponents([.day], from: last, to: Date()).day ?? 0
        return days >= 60
    }

    public var formattedDuration: String {
        let hours = totalForegroundSeconds / 3600
        let minutes = (totalForegroundSeconds % 3600) / 60
        let seconds = totalForegroundSeconds % 60
        if hours > 0 {
            return "\(hours) giờ \(minutes) phút"
        }
        if minutes > 0 {
            return "\(minutes) phút"
        }
        return "\(seconds) giây"
    }

    public var formattedLastOpened: String {
        guard let d = lastOpenedDate else { return "Chưa ghi nhận" }
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        formatter.locale = Locale(identifier: "vi_VN")
        return formatter.string(from: d)
    }

    public var formattedSize: String {
        guard sizeBytes > 0 else { return "—" }
        return ByteCountFormatter.string(fromByteCount: sizeBytes, countStyle: .file)
    }
}

private final class AppUsageViewCache: @unchecked Sendable {
    static let shared = AppUsageViewCache()
    var cachedStats: [AppUsageStat] = []
    var hasLoadedOnce: Bool = false
}

/// Phân hệ 6: Ứng dụng Ít Dùng (AppUsage)
/// Chạy hoàn toàn trên Task.detached(.utility) kèm bộ nhớ đệm 0ms và hiệu ứng chạm/chọn khối rõ nét.
public struct AppUsageView: View {
    @State private var usageStats: [AppUsageStat] = []
    @State private var selectedBundleId: String? = nil
    @State private var hoveredBundleId: String? = nil
    @State private var filterUnusedOnly: Bool = false
    @State private var searchQuery: String = ""
    @State private var isLoading: Bool = false

    public init() {}

    public var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 8) {
                        Text("Tần Suất Sử Dụng Ứng Dụng")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        StatusBadgeView("Chạm vào khối để chọn", style: .emerald)
                    }
                    Text("Ghi nhận số lần mở, thời gian chạy thật (NSWorkspace & Spotlight) và phát hiện app bỏ hoang >60 ngày")
                        .font(.system(size: 12))
                        .foregroundColor(BullTheme.textZinc600)
                }
                Spacer()
                Toggle("Chỉ hiện app ít dùng (>60 ngày)", isOn: $filterUnusedOnly)
                    .font(.system(size: 12))
                    .toggleStyle(SwitchToggleStyle(tint: BullTheme.emerald600))

                Button(action: { loadUsage(force: true) }) {
                    HStack(spacing: 4) {
                        Image(systemName: "arrow.clockwise")
                        Text("Làm mới")
                    }
                    .font(.system(size: 12, weight: .semibold))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(BullTheme.surfaceWhite)
                    .foregroundColor(BullTheme.textZinc900)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                    .cornerRadius(BullTheme.buttonRadius)
                }
                .buttonStyle(.plain)
            }
            .padding(16)
            .background(BullTheme.surfaceWhite)
            .overlay(Divider(), alignment: .bottom)

            // Thanh tìm kiếm & Thống kê nhanh
            HStack(spacing: 12) {
                HStack(spacing: 6) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 12))
                        .foregroundColor(BullTheme.textZinc400)
                    TextField("Tìm ứng dụng theo tên hoặc Bundle ID...", text: $searchQuery)
                        .textFieldStyle(.plain)
                        .font(.system(size: 12))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(BullTheme.surfaceWhite)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                .cornerRadius(BullTheme.buttonRadius)

                Spacer()

                Text("Tổng cộng: \(displayedStats.count) ứng dụng • Ít dùng: \(usageStats.filter { $0.isUnused }.count) mục")
                    .font(.system(size: 11.5, weight: .semibold))
                    .monospacedDigit()
                    .foregroundColor(BullTheme.textZinc600)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(BullTheme.bgZinc50)
            .overlay(Divider(), alignment: .bottom)

            // Danh sách thống kê
            if isLoading {
                VStack(spacing: 8) {
                    ProgressView()
                    Text("Đang tổng hợp nhật ký sử dụng ứng dụng trên luồng nền...")
                        .font(.system(size: 12))
                        .foregroundColor(BullTheme.textZinc600)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if displayedStats.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "clock.badge.checkmark")
                        .font(.system(size: 28))
                        .foregroundColor(BullTheme.textZinc400)
                    Text("Không có ứng dụng nào khớp với bộ lọc hiện tại.")
                        .font(.system(size: 12))
                        .foregroundColor(BullTheme.textZinc600)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(displayedStats) { item in
                            usageRowCard(item)
                        }
                    }
                    .padding(16)
                }
            }
        }
        .background(BullTheme.bgZinc50)
        .onAppear {
            loadUsage(force: !AppUsageViewCache.shared.hasLoadedOnce)
        }
    }

    private func usageRowCard(_ item: AppUsageStat) -> some View {
        let isSel = selectedBundleId == item.bundleId
        let isHov = hoveredBundleId == item.bundleId

        return HStack(spacing: 12) {
            Image(systemName: isSel ? "checkmark.circle.fill" : "clock.arrow.circlepath")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald700 : BullTheme.textZinc400))

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(item.appName)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(isSel ? BullTheme.emerald800 : BullTheme.textZinc900)
                        .lineLimit(1)
                    if item.isUnused {
                        StatusBadgeView("Ít dùng (>60 ngày)", style: .amber)
                    } else {
                        StatusBadgeView("Đang dùng", style: .emerald)
                    }
                    if isSel {
                        StatusBadgeView("ĐANG CHỌN", style: .emerald)
                    }
                }
                Text("\(item.bundleId) • Mở lần cuối: \(item.formattedLastOpened)")
                    .font(.system(size: 11))
                    .foregroundColor(BullTheme.textZinc600)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 2) {
                Text(item.formattedSize)
                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(isSel ? BullTheme.emerald700 : BullTheme.textZinc900)

                HStack(spacing: 8) {
                    Text("\(item.launchCount) lần mở")
                        .font(.system(size: 11, weight: .medium))
                        .monospacedDigit()
                        .foregroundColor(BullTheme.textZinc600)
                    Text("•")
                        .font(.system(size: 11))
                        .foregroundColor(BullTheme.textZinc400)
                    Text(item.formattedDuration)
                        .font(.system(size: 11, weight: .medium))
                        .monospacedDigit()
                        .foregroundColor(BullTheme.textZinc600)
                }
            }

            #if os(macOS)
            if let path = item.appPath {
                Button(action: {
                    NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
                }) {
                    HStack(spacing: 4) {
                        Image(systemName: "folder")
                        Text("Finder")
                    }
                    .font(.system(size: 11, weight: .semibold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(BullTheme.bgZinc100)
                    .foregroundColor(BullTheme.textZinc900)
                    .cornerRadius(BullTheme.badgeRadius)
                }
                .buttonStyle(.plain)
            }
            #endif
        }
        .padding(12)
        .background(isSel ? BullTheme.emeraldBg : (isHov ? BullTheme.bgZinc100.opacity(0.8) : BullTheme.surfaceWhite))
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: isSel ? 2.0 : (isHov ? 1.5 : 1.0))
        )
        .cornerRadius(BullTheme.cornerRadius)
        .contentShape(Rectangle())
        .onHover { h in
            withAnimation(.easeOut(duration: 0.12)) {
                hoveredBundleId = h ? item.bundleId : nil
            }
        }
        .onTapGesture {
            withAnimation(.easeOut(duration: 0.12)) {
                selectedBundleId = (selectedBundleId == item.bundleId) ? nil : item.bundleId
            }
        }
    }

    private var displayedStats: [AppUsageStat] {
        var result = usageStats
        if filterUnusedOnly {
            result = result.filter { $0.isUnused }
        }
        let q = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if !q.isEmpty {
            result = result.filter {
                $0.appName.lowercased().contains(q) || $0.bundleId.lowercased().contains(q)
            }
        }
        return result
    }

    private func loadUsage(force: Bool) {
        if !force && AppUsageViewCache.shared.hasLoadedOnce {
            self.usageStats = AppUsageViewCache.shared.cachedStats
            return
        }

        isLoading = true
        Task.detached(priority: .utility) {
            var statsByBundle: [String: AppUsageStat] = [:]
            let trackedRecords = AppLaunchTracker.shared.getAllUsageRecords()
            var recordMap: [String: AppUsageRecord] = [:]
            for rec in trackedRecords {
                recordMap[rec.bundleIdentifier] = rec
            }

            #if os(macOS)
            let appDirs = [
                URL(fileURLWithPath: "/Applications"),
                FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Applications")
            ]

            for dir in appDirs {
                guard let urls = try? FileManager.default.contentsOfDirectory(
                    at: dir,
                    includingPropertiesForKeys: [.contentAccessDateKey, .contentModificationDateKey],
                    options: [.skipsHiddenFiles]
                ) else { continue }

                for url in urls.prefix(75) where url.pathExtension == "app" {
                    let name = url.deletingPathExtension().lastPathComponent
                    let bundle = Bundle(url: url)
                    let bundleId = bundle?.bundleIdentifier ?? "app.\(name.lowercased())"
                    let size = AppLaunchTracker.calculateBundleSize(at: url)
                    let resourceVals = try? url.resourceValues(forKeys: [.contentAccessDateKey, .contentModificationDateKey])
                    let fsLastDate = resourceVals?.contentAccessDate ?? resourceVals?.contentModificationDate

                    if let tracked = recordMap.removeValue(forKey: bundleId) {
                        statsByBundle[bundleId] = AppUsageStat(
                            appName: tracked.appName,
                            bundleId: bundleId,
                            appPath: url.path,
                            launchCount: tracked.launchCount,
                            totalForegroundSeconds: Int(tracked.totalForegroundSeconds),
                            lastOpenedDate: tracked.lastLaunchedDate,
                            sizeBytes: size
                        )
                    } else {
                        statsByBundle[bundleId] = AppUsageStat(
                            appName: name,
                            bundleId: bundleId,
                            appPath: url.path,
                            launchCount: fsLastDate != nil ? 1 : 0,
                            totalForegroundSeconds: 0,
                            lastOpenedDate: fsLastDate,
                            sizeBytes: size
                        )
                    }
                }
            }

            for (bundleId, tracked) in recordMap {
                statsByBundle[bundleId] = AppUsageStat(
                    appName: tracked.appName,
                    bundleId: bundleId,
                    appPath: nil,
                    launchCount: tracked.launchCount,
                    totalForegroundSeconds: Int(tracked.totalForegroundSeconds),
                    lastOpenedDate: tracked.lastLaunchedDate,
                    sizeBytes: 0
                )
            }
            #else
            for tracked in trackedRecords {
                statsByBundle[tracked.bundleIdentifier] = AppUsageStat(
                    appName: tracked.appName,
                    bundleId: tracked.bundleIdentifier,
                    appPath: nil,
                    launchCount: tracked.launchCount,
                    totalForegroundSeconds: Int(tracked.totalForegroundSeconds),
                    lastOpenedDate: tracked.lastLaunchedDate,
                    sizeBytes: 0
                )
            }
            #endif

            let sorted = Array(statsByBundle.values).sorted { lhs, rhs in
                if lhs.launchCount != rhs.launchCount {
                    return lhs.launchCount > rhs.launchCount
                }
                return lhs.sizeBytes > rhs.sizeBytes
            }

            AppUsageViewCache.shared.cachedStats = sorted
            AppUsageViewCache.shared.hasLoadedOnce = true

            await MainActor.run {
                self.usageStats = sorted
                self.isLoading = false
            }
        }
    }
}
