import SwiftUI
import CleanBullCore

/// Phân hệ 7: Trung tâm An toàn, Kho Cách Ly SHA-256 & Hoàn tác Phiên (SafetyCenter)
/// Chạy trên Task.detached(.utility) kèm hiệu ứng chạm/chọn khối phiên cách ly rõ nét.
public struct SafetyCenterView: View {
    @State private var sessions: [QuarantineSession] = []
    @State private var selectedSession: QuarantineSession?
    @State private var hoveredSessionId: UUID? = nil
    @State private var isRestoring: Bool = false
    @State private var actionMessage: String?

    private let quarantineManager = QuarantineManager()

    public init() {}

    public var body: some View {
        HStack(spacing: 0) {
            // Cột 1: Danh sách các phiên cách ly & Vùng bảo vệ
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 8) {
                            Text("Trung Tâm An Toàn & Kho Cách Ly")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(BullTheme.textZinc900)
                            StatusBadgeView("Chạm vào khối phiên để hoàn tác", style: .emerald)
                        }
                        Text("Bảo vệ 12 vùng cấm, 13 thư mục cá nhân, mọi Khu làm việc (Workspaces) & Hoàn tác Phiên SHA-256")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc600)
                    }
                    Spacer()
                    Button(action: refreshSessions) {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.clockwise")
                            Text("Làm mới")
                        }
                        .font(.system(size: 12, weight: .semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(BullTheme.surfaceWhite)
                        .foregroundColor(BullTheme.textZinc900)
                        .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.borderZinc300, lineWidth: 1))
                        .cornerRadius(BullTheme.buttonRadius)
                    }
                    .buttonStyle(.plain)
                }

                // Thẻ tóm tắt chính sách bảo vệ
                VStack(alignment: .leading, spacing: 6) {
                    Text("Chính sách ProtectedPaths & Workspace Guard nghiêm ngặt:")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(BullTheme.textZinc900)

                    HStack(spacing: 8) {
                        policyBadge("12 Thư mục gốc OS", style: .rose)
                        policyBadge("13 Thư mục User (.ssh, Keychains)", style: .amber)
                        policyBadge("Mọi Khu làm việc (Git/Swift/Node)", style: .emerald)
                        policyBadge("21+ Tên file nhạy cảm", style: .sky)
                    }
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(BullTheme.surfaceWhite)
                .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                .cornerRadius(BullTheme.cornerRadius)

                if let msg = actionMessage {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(BullTheme.emerald700)
                        Text(msg)
                            .font(.system(size: 11.5, weight: .semibold))
                        Spacer()
                        Button("Đóng") { actionMessage = nil }
                            .font(.system(size: 11))
                            .buttonStyle(.plain)
                    }
                    .padding(9)
                    .background(BullTheme.emeraldBg)
                    .foregroundColor(BullTheme.emerald800)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.badgeRadius)
                }

                // Danh sách Phiên cách ly
                Text("Các Phiên Cách Ly Trong Kho (\(sessions.count) phiên):")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(BullTheme.textZinc900)

                if sessions.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "shield.lefthalf.filled")
                            .font(.system(size: 28))
                            .foregroundColor(BullTheme.textZinc400)
                        Text("Kho cách ly hiện đang trống.")
                            .font(.system(size: 12))
                            .foregroundColor(BullTheme.textZinc600)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(sessions) { session in
                                sessionRowCard(session)
                            }
                        }
                        .padding(10)
                    }
                    .background(BullTheme.surfaceWhite)
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                    .cornerRadius(BullTheme.cornerRadius)
                }
            }
            .padding(16)

            // Cột 2: Chi tiết phiên cách ly & Hoàn tác Phiên
            if let s = selectedSession {
                Divider()
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text("Chi Tiết Phiên Cách Ly")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(BullTheme.textZinc900)
                        Spacer()
                        StatusBadgeView("ĐANG CHỌN", style: .emerald)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Mã phiên: \(s.id.uuidString)")
                            .font(.system(size: 11, design: .monospaced))
                            .monospacedDigit()
                            .foregroundColor(BullTheme.textZinc600)
                            .lineLimit(1)
                            .truncationMode(.middle)
                        Text("Thời gian: \(formatDate(s.dateCreated))")
                            .font(.system(size: 11))
                            .foregroundColor(BullTheme.textZinc600)
                        Text("Tổng dung lượng: \(ByteCountFormatter.string(fromByteCount: s.totalSize, countStyle: .file))")
                            .font(.system(size: 11.5, weight: .bold))
                            .foregroundColor(BullTheme.emerald800)
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(BullTheme.emeraldBg.opacity(0.5))
                    .overlay(RoundedRectangle(cornerRadius: BullTheme.cornerRadius).stroke(BullTheme.emeraldBorder, lineWidth: 1))
                    .cornerRadius(BullTheme.cornerRadius)

                    Text("Danh mục tệp (`manifest.json`):")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(BullTheme.textZinc900)

                    ScrollView {
                        VStack(spacing: 6) {
                            ForEach(s.records) { rec in
                                VStack(alignment: .leading, spacing: 2) {
                                    HStack {
                                        Text((rec.originalPath as NSString).lastPathComponent)
                                            .font(.system(size: 12, weight: .semibold))
                                            .foregroundColor(BullTheme.textZinc900)
                                            .lineLimit(1)
                                        Spacer()
                                        Text(ByteCountFormatter.string(fromByteCount: rec.fileSize, countStyle: .file))
                                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                                            .monospacedDigit()
                                            .foregroundColor(BullTheme.textZinc700)
                                    }
                                    Text("Gốc: \(rec.originalPath)")
                                        .font(.system(size: 10))
                                        .foregroundColor(BullTheme.textZinc400)
                                        .lineLimit(1)
                                        .truncationMode(.middle)
                                    Text("SHA-256: \(rec.sha256Checksum.prefix(16))...")
                                        .font(.system(size: 9, design: .monospaced))
                                        .monospacedDigit()
                                        .foregroundColor(BullTheme.textZinc400)
                                }
                                .padding(8)
                                .background(BullTheme.surfaceWhite)
                                .overlay(RoundedRectangle(cornerRadius: BullTheme.badgeRadius).stroke(BullTheme.bgZinc200, lineWidth: 1))
                                .cornerRadius(BullTheme.badgeRadius)
                            }
                        }
                    }

                    Spacer()

                    // Các nút thao tác
                    VStack(spacing: 8) {
                        Button(action: { restoreSession(s) }) {
                            HStack(spacing: 6) {
                                Image(systemName: "arrow.uturn.backward.circle.fill")
                                Text(isRestoring ? "Đang đối soát SHA-256..." : "Hoàn tác Phiên (Đối soát SHA-256)")
                            }
                            .font(.system(size: 12, weight: .bold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(BullTheme.emerald600)
                            .foregroundColor(.white)
                            .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)
                        .disabled(isRestoring || s.status == .restored)

                        Button(action: { purgeSession(s) }) {
                            Text("Xóa vĩnh viễn phiên này")
                                .font(.system(size: 11.5, weight: .semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(BullTheme.roseBg)
                                .foregroundColor(BullTheme.roseText)
                                .overlay(RoundedRectangle(cornerRadius: BullTheme.buttonRadius).stroke(BullTheme.roseBorder, lineWidth: 1))
                                .cornerRadius(BullTheme.buttonRadius)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .frame(width: 335)
                .padding(16)
                .background(BullTheme.surfaceWhite)
            }
        }
        .background(BullTheme.bgZinc50)
        .onAppear {
            refreshSessions()
        }
    }

    private func sessionRowCard(_ session: QuarantineSession) -> some View {
        let isSel = selectedSession?.id == session.id
        let isHov = hoveredSessionId == session.id

        return HStack(spacing: 10) {
            Image(systemName: isSel ? "checkmark.circle.fill" : "archivebox.fill")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald700 : BullTheme.textZinc400))

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text("Phiên \(session.id.uuidString.prefix(8))")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(isSel ? BullTheme.emerald800 : BullTheme.textZinc900)
                    StatusBadgeView(session.status.localizedTitle, style: badgeStyle(for: session.status))
                    if isSel {
                        StatusBadgeView("ĐANG CHỌN", style: .emerald)
                    }
                }
                Text(formatDate(session.dateCreated))
                    .font(.system(size: 11))
                    .foregroundColor(BullTheme.textZinc500)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 2) {
                Text(ByteCountFormatter.string(fromByteCount: session.totalSize, countStyle: .file))
                    .font(.system(size: 12.5, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundColor(isSel ? BullTheme.emerald700 : BullTheme.textZinc900)
                Text("\(session.records.count) tệp tin")
                    .font(.system(size: 11))
                    .foregroundColor(BullTheme.textZinc600)
            }
        }
        .padding(10)
        .background(isSel ? BullTheme.emeraldBg : (isHov ? BullTheme.bgZinc100.opacity(0.8) : BullTheme.surfaceWhite))
        .overlay(
            RoundedRectangle(cornerRadius: BullTheme.cornerRadius)
                .stroke(isSel ? BullTheme.emerald600 : (isHov ? BullTheme.emerald500 : BullTheme.bgZinc200), lineWidth: isSel ? 2.0 : (isHov ? 1.5 : 1.0))
        )
        .cornerRadius(BullTheme.cornerRadius)
        .contentShape(Rectangle())
        .onHover { h in
            withAnimation(.easeOut(duration: 0.12)) {
                hoveredSessionId = h ? session.id : nil
            }
        }
        .onTapGesture {
            withAnimation(.easeOut(duration: 0.12)) {
                selectedSession = session
            }
        }
    }

    private func policyBadge(_ text: String, style: StatusBadgeView.BadgeStyle) -> some View {
        StatusBadgeView(text, style: style)
    }

    private func badgeStyle(for status: QuarantineSessionStatus) -> StatusBadgeView.BadgeStyle {
        switch status {
        case .quarantined: return .amber
        case .restored: return .emerald
        case .partiallyRestored: return .sky
        case .purged: return .zinc
        }
    }

    private func formatDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateStyle = .short
        f.timeStyle = .short
        f.locale = Locale(identifier: "vi_VN")
        return f.string(from: date)
    }

    private func refreshSessions() {
        let manager = quarantineManager
        Task.detached(priority: .utility) {
            let list = (try? await manager.listSessions()) ?? []
            await MainActor.run {
                self.sessions = list
                if self.selectedSession == nil {
                    self.selectedSession = list.first
                }
            }
        }
    }

    private func restoreSession(_ s: QuarantineSession) {
        isRestoring = true
        let manager = quarantineManager
        Task.detached(priority: .userInitiated) {
            do {
                let res = try await manager.restoreSession(sessionId: s.id)
                await MainActor.run {
                    self.actionMessage = res.summaryMessage
                    self.isRestoring = false
                    self.refreshSessions()
                }
            } catch {
                await MainActor.run {
                    self.actionMessage = "Lỗi hoàn tác: \(error.localizedDescription)"
                    self.isRestoring = false
                }
            }
        }
    }

    private func purgeSession(_ s: QuarantineSession) {
        let manager = quarantineManager
        Task.detached(priority: .userInitiated) {
            do {
                try await manager.purgeSessionPermanently(sessionId: s.id)
                await MainActor.run {
                    self.actionMessage = "Đã xóa vĩnh viễn phiên cách ly."
                    self.selectedSession = nil
                    self.refreshSessions()
                }
            } catch {
                await MainActor.run {
                    self.actionMessage = "Lỗi xóa: \(error.localizedDescription)"
                }
            }
        }
    }
}
