import SwiftUI

/// Hệ màu và chuẩn thiết kế "UI 3 KHÔNG" dành cho CleanBull Mobile iPadOS
public struct BullTheme {
    // 90% Zinc Palette (Không Indigo, Không Tím, Không Gradient)
    public static let bgZinc50 = Color(white: 0.98)
    public static let bgZinc100 = Color(white: 0.95)
    public static let bgZinc200 = Color(white: 0.88)
    public static let borderZinc300 = Color(white: 0.82)
    public static let textZinc400 = Color(red: 161/255, green: 161/255, blue: 170/255)
    public static let textZinc500 = Color(red: 113/255, green: 113/255, blue: 122/255)
    public static let textZinc600 = Color(red: 82/255, green: 82/255, blue: 91/255)
    public static let textZinc700 = Color(red: 63/255, green: 63/255, blue: 70/255)
    public static let textZinc800 = Color(red: 39/255, green: 39/255, blue: 42/255)
    public static let textZinc900 = Color(red: 24/255, green: 24/255, blue: 27/255)
    public static let surfaceWhite = Color.white

    // Primary Brand & Active State (Emerald 600/700/800 matching simulator-web v4.4.0)
    public static let emerald500 = Color(red: 16/255, green: 185/255, blue: 129/255)
    public static let emerald600 = Color(red: 5/255, green: 150/255, blue: 105/255)
    public static let emerald700 = Color(red: 4/255, green: 120/255, blue: 87/255)
    public static let emerald800 = Color(red: 6/255, green: 95/255, blue: 70/255)
    public static let emerald100 = Color(red: 209/255, green: 250/255, blue: 229/255)

    // 7% Semantic Badges (Nền 50 + Viền 200 + Chữ 700)
    public static let emeraldBg = Color(red: 236/255, green: 253/255, blue: 245/255)
    public static let emeraldBorder = Color(red: 167/255, green: 243/255, blue: 208/255)
    public static let emeraldText = Color(red: 4/255, green: 120/255, blue: 87/255)

    public static let amberBg = Color(red: 255/255, green: 251/255, blue: 235/255)
    public static let amberBorder = Color(red: 253/255, green: 230/255, blue: 138/255)
    public static let amberText = Color(red: 180/255, green: 83/255, blue: 9/255)

    public static let roseBg = Color(red: 255/255, green: 241/255, blue: 242/255)
    public static let roseBorder = Color(red: 254/255, green: 205/255, blue: 211/255)
    public static let roseText = Color(red: 190/255, green: 18/255, blue: 60/255)

    public static let skyBg = Color(red: 240/255, green: 249/255, blue: 255/255)
    public static let skyBorder = Color(red: 186/255, green: 230/255, blue: 253/255)
    public static let skyText = Color(red: 3/255, green: 105/255, blue: 161/255)

    // Bo góc chuẩn HIG & 3 KHÔNG: 8px (Không dùng rounded-2xl hay rounded-3xl)
    public static let cornerRadius: CGFloat = 8.0
    public static let buttonRadius: CGFloat = 6.0
    public static let badgeRadius: CGFloat = 4.0
}
